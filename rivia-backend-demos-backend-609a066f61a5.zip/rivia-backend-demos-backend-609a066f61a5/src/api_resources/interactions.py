from src.funcs import general
from src.components import logging, constants, interactions, structured_data, unstructured_data, configs
from flask import make_response, request
import os


class Ops:

    @staticmethod
    def create(account_id, user_id):
        try:
            if Utils.Validator.is_for_mobile_version():
                return Ops.create_for_mobile(account_id=account_id, user_id=user_id)
            Utils.Validator.validate_create_interaction_request()
            interaction = interactions.FactoryFuncs.create(
                account_id=account_id, user_id=user_id, demo_id=request.json.get("demo_id"),
                step_id=request.json.get("step_id"), default_edit_state=request.json.get("edit_state"),
                interaction_type=request.json.get("interaction_type"),
                height_image=request.json.get('height_image'), width_image=request.json.get('width_image'))

        except AssertionError as ase:
            logging.Funcs.create_error_log(ase, account_id=account_id, user_id=user_id)
            return general.APIResponse.Error.get_response(ase, 401)
        except Exception as e:
            logging.Funcs.create_error_log(e, account_id=account_id, user_id=user_id)
            return general.APIResponse.Error.get_response(constants.APIResponse.Messages.BUSINESS_ERROR, 500)
        else:
            return make_response({
                constants.APIResponse.Fields.STATUS: constants.APIResponse.Statuses.SUCCESS,
                constants.APIResponse.Fields.MESSAGE: "interaction created",
                "interaction": {
                    **interaction.as_json(),
                    "edit_state": {**interaction.edit_state, "video_url": unstructured_data.Database.generate_cdn_url(
                        interaction.path_video) if interaction.interaction_type == constants.Interactions.RECORDING else None,
                                   "events_url": unstructured_data.Database.generate_cdn_url(
                                       interaction.path_events) if interaction.interaction_type == constants.Interactions.RECORDING else None,
                                   "image_url": unstructured_data.Database.generate_cdn_url(
                                       interaction.path_image) if interaction.interaction_type == constants.Interactions.IMAGE_MODAL else None}
                },
                "upload_video_url": unstructured_data.Database.generate_upload_url(
                    interaction.path_video,
                    bucket_name=configs.AWS.S3_BUCKET
                ) if interaction.interaction_type == constants.Interactions.RECORDING else None,
                "upload_events_url": unstructured_data.Database.generate_upload_url(
                    interaction.path_events,
                    bucket_name=configs.AWS.S3_BUCKET
                ) if interaction.interaction_type == constants.Interactions.RECORDING else None,
                "upload_image_url": unstructured_data.Database.generate_upload_url(
                    interaction.path_image,
                    bucket_name=configs.AWS.S3_BUCKET
                ) if interaction.interaction_type == constants.Interactions.IMAGE_MODAL else None
            }, 200)

    @staticmethod
    @logging.Funcs.log_func_call("creating interaction for mobile version")
    def create_for_mobile(account_id, user_id):
        try:
            Utils.Validator.validate_create_interaction_for_mobile_version_request()
            structured_data.Database.update_or_add_single(structured_data.Database.published_interactions,
                                                          {"interaction_id": request.json.get("interaction_id"),
                                                           "type": constants.Previews.MOBILE},
                                                          {**structured_data.Database.find_single(
                                                              structured_data.Database.interactions,
                                                              {"interaction_id": request.json.get("interaction_id")},
                                                              {"_id": 0}),
                                                           "position": request.json.get("position"),
                                                           "type": constants.Previews.MOBILE})
        except AssertionError as ase:
            logging.Funcs.create_error_log(ase, account_id=account_id, user_id=user_id,
                                           component_id=request.json.get("interaction_id"))
            return general.APIResponse.Error.get_response(ase, 401)
        except Exception as e:
            logging.Funcs.create_error_log(e, account_id=account_id, user_id=user_id,
                                           component_id=request.json.get("interaction_id"))
            return general.APIResponse.Error.get_response(constants.APIResponse.Messages.BUSINESS_ERROR, 500)
        else:
            return make_response({
                constants.APIResponse.Fields.STATUS: constants.APIResponse.Statuses.SUCCESS,
                constants.APIResponse.Fields.MESSAGE: "interaction created"
            }, 200)

    @staticmethod
    def update(account_id, user_id, interaction_id):
        try:
            Utils.Validator.validate_update_interaction_request()
            interaction_details = structured_data.Database.find_single(structured_data.Database.interactions,
                                                                       {"interaction_id": interaction_id},
                                                                       {"_id": 0})
            assert interaction_details, "interaction_id not found"
            if request.args.get("update_image") == "true":
                image_id = general.Identifiers.generate_image_id()
                structured_data.Database.update_single(structured_data.Database.interactions,
                                                       {"interaction_id": interaction_id},
                                                       {"$set": {
                                                           "path_image": os.path.join(account_id,
                                                                                      interaction_details['demo_id'],
                                                                                      interaction_details['step_id'],
                                                                                      interaction_id,
                                                                                      image_id),
                                                           "height_image": request.json.get('height_image'),
                                                           'width_image': request.json.get('width_image')
                                                       }})
            if request.args.get("delete_image") == "true":
                structured_data.Database.update_single(structured_data.Database.interactions,
                                                       {"interaction_id": interaction_id},
                                                       {"$set": {"path_image": None, 'height_image': None,
                                                                 'width_image': None}})
            if request.json.get("edit_state"):
                structured_data.Database.update_single(structured_data.Database.interactions,
                                                       {"interaction_id": interaction_id},
                                                       {"$set": {"edit_state": dict(request.json.get("edit_state"))}})
            interaction = structured_data.Database.find_single(structured_data.Database.interactions,
                                                               {"interaction_id": interaction_id}, {"_id": 0})
        except AssertionError as ase:
            logging.Funcs.create_error_log(ase, account_id=account_id, user_id=user_id, component_id=interaction_id)
            return general.APIResponse.Error.get_response(ase, 401)
        except Exception as e:
            logging.Funcs.create_error_log(e, account_id=account_id, user_id=user_id, component_id=interaction_id)
            return general.APIResponse.Error.get_response(constants.APIResponse.Messages.BUSINESS_ERROR, 500)
        else:
            return make_response({
                constants.APIResponse.Fields.STATUS: constants.APIResponse.Statuses.SUCCESS,
                constants.APIResponse.Fields.MESSAGE: "updated",
                "interaction": {
                    **interaction,
                    "edit_state": {**interaction['edit_state'],
                                   "video_url": unstructured_data.Database.generate_cdn_url(
                                       interaction['path_video']) if interaction[
                                                                         'interaction_type'] == constants.Interactions.RECORDING else None,
                                   "events_url": unstructured_data.Database.generate_cdn_url(
                                       interaction['path_events']) if interaction[
                                                                          'interaction_type'] == constants.Interactions.RECORDING else None,
                                   "image_url": unstructured_data.Database.generate_cdn_url(
                                       interaction['path_image']) if interaction[
                                                                         'interaction_type'] == constants.Interactions.IMAGE_MODAL else None}
                },
                "upload_image_url": unstructured_data.Database.generate_upload_url(
                    interaction['path_image'],
                    bucket_name=configs.AWS.S3_BUCKET
                ) if interaction['interaction_type'] == constants.Interactions.IMAGE_MODAL and request.args.get(
                    'update_image') else None
            }, 200)

    @staticmethod
    def delete(account_id, user_id, interaction_id):
        try:
            structured_data.Database.delete_single(structured_data.Database.interactions,
                                                   {"interaction_id": interaction_id})
        except Exception as e:
            logging.Funcs.create_error_log(e, account_id=account_id, user_id=user_id, component_id=interaction_id)
            return general.APIResponse.Error.get_response(constants.APIResponse.Messages.BUSINESS_ERROR, 500)
        else:
            return make_response({
                constants.APIResponse.Fields.STATUS: constants.APIResponse.Statuses.SUCCESS,
                constants.APIResponse.Fields.MESSAGE: "deleted"
            }, 200)


class Utils:
    class Validator:
        @staticmethod
        def validate_create_interaction_request():
            assert request.json.get("step_id"), "step_id missing from request body"
            assert request.json.get("demo_id"), "demo_id missing from request body"
            assert request.json.get("interaction_type"), "interaction_type missing from request body"
            assert request.json.get("interaction_type") in {constants.Interactions.MODAL,
                                                            constants.Interactions.TOOLTIP,
                                                            constants.Interactions.FORM,
                                                            constants.Interactions.IFRAME,
                                                            constants.Interactions.RECORDING,
                                                            constants.Interactions.IMAGE_MODAL}, \
                "invalid value for interaction type added"
            assert request.json.get("edit_state"), "edit_state missing from request body"

        @staticmethod
        def validate_update_interaction_request():
            # assert len(request.json) == 1 and request.json.get("edit_state"), "edit_state missing from request body"
            assert len(
                set(list(request.json.keys())) - {"edit_state", "height_image",
                                                  "width_image"}) == 0, "invalid update field in request body"

        @staticmethod
        def validate_create_interaction_for_mobile_version_request():
            assert request.json.get("interaction_id"), "interaction_id missing from request body"
            assert request.json.get("position"), "position missing from request body"
            assert set(list(request.json.get("position").keys())).issubset(
                {"x", "y", "width", "height"}), "invalid position format"

        @staticmethod
        def is_for_mobile_version():
            return request.args.get("type", None) == constants.Previews.MOBILE
