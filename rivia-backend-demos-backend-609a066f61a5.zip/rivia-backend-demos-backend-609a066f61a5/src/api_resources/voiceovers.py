from src.funcs import general
from src.components import logging, voiceovers, constants, structured_data, tts, unstructured_data, cdn, configs
from flask import request, make_response
import io


class Ops:

    @staticmethod
    @logging.Funcs.log_func_call("creating voiceover")
    def create(account_id, user_id):
        try:
            Utils.Validator.create()
            step_details = structured_data.Database.find_single(structured_data.Database.steps,
                                                                {"step_id": request.json.get("step_id")},
                                                                {"_id": 0, "voiceover_text": 1})
            assert step_details, "invalid step_id"
            assert step_details.get("voiceover_text"), "voiceover_text missing in step"
            speaker_details = structured_data.Database.find_single(structured_data.Database.speakers,
                                                                   {"speaker_id": request.json.get("speaker_id")},
                                                                   {"_id": 0})
            assert speaker_details, "invalid speaker_id"
            audio = tts.TTSClient.convert(speaker_id=speaker_details["external_speaker_id"],
                                          text=step_details["voiceover_text"])
            voiceover = voiceovers.FactoryFuncs.create(account_id=account_id, user_id=user_id,
                                                       demo_id=request.json.get("demo_id"),
                                                       step_id=request.json.get("step_id"),
                                                       speaker_id=request.json.get("speaker_id"),
                                                       audio_type=constants.Audios.AudioTypes.MP3)
            unstructured_data.Database.upload(voiceover.path_audio, file_content=io.BytesIO(audio.content),
                                              extra_args={'ContentType': 'audio/mpeg'})
            return make_response({
                constants.APIResponse.Fields.STATUS: constants.APIResponse.Statuses.SUCCESS,
                constants.APIResponse.Fields.MESSAGE: "voiceover created",
                "voiceover": {
                    **voiceover.as_json(),
                    "audio_url": unstructured_data.Database.generate_download_url(voiceover.path_audio)
                }})
        except AssertionError as ase:
            logging.Funcs.create_error_log(ase, account_id=account_id, user_id=user_id,
                                           component_id=request.json.get("step_id"))
            return general.APIResponse.Error.get_response(ase, 401)
        except Exception as e:
            logging.Funcs.create_error_log(e, account_id=account_id, user_id=user_id,
                                           component_id=request.json.get("step_id"))
            return general.APIResponse.Error.get_response(constants.APIResponse.Messages.BUSINESS_ERROR, 500)

    @staticmethod
    @logging.Funcs.log_func_call("create uploaded voiceover")
    def create_uploaded(account_id, user_id):
        try:
            Utils.Validator.create_uploaded()
            structured_data.Database.delete_many(structured_data.Database.voiceovers,
                                                 {"step_id": request.json.get("step_id"),
                                                  "speaker_id": "UPLOADED"})
            voiceover = voiceovers.FactoryFuncs.create(account_id=account_id, user_id=user_id,
                                                       demo_id=request.json.get("demo_id"),
                                                       step_id=request.json.get("step_id"),
                                                       speaker_id="UPLOADED",
                                                       audio_type=request.args.get("audio_type"))
            return make_response({
                constants.APIResponse.Fields.STATUS: constants.APIResponse.Statuses.SUCCESS,
                constants.APIResponse.Fields.MESSAGE: "voiceover created",
                "voiceover": {
                    **voiceover.as_json(),
                    "upload_url": unstructured_data.Database.generate_upload_url(voiceover.path_audio,
                                                                                 bucket_name=configs.AWS.S3_BUCKET),
                    "audio_url": unstructured_data.Database.generate_download_url(voiceover.path_audio)
                }})
        except AssertionError as ase:
            logging.Funcs.create_error_log(ase, account_id=account_id, user_id=user_id,
                                           component_id=request.json.get("step_id"))
            return general.APIResponse.Error.get_response(ase, 401)
        except Exception as e:
            logging.Funcs.create_error_log(e, account_id=account_id, user_id=user_id,
                                           component_id=request.json.get("step_id"))
            return general.APIResponse.Error.get_response(constants.APIResponse.Messages.BUSINESS_ERROR, 500)

    @staticmethod
    @logging.Funcs.log_func_call("updating voiceover")
    def update(account_id, user_id, voiceover_id):
        try:
            voiceover_details = structured_data.Database.find_single(structured_data.Database.voiceovers,
                                                                     {"voiceover_id": voiceover_id},
                                                                     {"_id": 0})
            assert voiceover_details, "invalid voiceover_id"
            step_details = structured_data.Database.find_single(structured_data.Database.steps,
                                                                {"step_id": voiceover_details['step_id']},
                                                                {"_id": 0, "voiceover_text": 1})
            assert step_details, "invalid step_id"
            assert step_details.get("voiceover_text"), "voiceover_text missing in step"
            speaker_details = structured_data.Database.find_single(structured_data.Database.speakers,
                                                                   {"speaker_id": voiceover_details['speaker_id']},
                                                                   {"_id": 0})
            assert speaker_details, "invalid speaker_id"
            audio = tts.TTSClient.convert(speaker_id=speaker_details["external_speaker_id"],
                                          text=step_details["voiceover_text"])
            unstructured_data.Database.upload(voiceover_details["path_audio"], file_content=io.BytesIO(audio.content),
                                              extra_args={'ContentType': 'audio/mpeg'})
            invalidation = cdn.CDN.invalidate_cache(paths=[voiceover_details["path_audio"]])
            return make_response({
                constants.APIResponse.Fields.STATUS: constants.APIResponse.Statuses.SUCCESS,
                constants.APIResponse.Fields.MESSAGE: "voiceover updated",
                "voiceover": {
                    **voiceover_details,
                    "audio_url": unstructured_data.Database.generate_download_url(voiceover_details["path_audio"])
                }})
        except AssertionError as ase:
            logging.Funcs.create_error_log(ase, account_id=account_id, user_id=user_id,
                                           component_id=voiceover_id)
            return general.APIResponse.Error.get_response(ase, 401)
        except Exception as e:
            logging.Funcs.create_error_log(e, account_id=account_id, user_id=user_id,
                                           component_id=voiceover_id)
            return general.APIResponse.Error.get_response(constants.APIResponse.Messages.BUSINESS_ERROR, 500)

    @staticmethod
    @logging.Funcs.log_func_call("fetching voiceovers for a step")
    def fetch_all(account_id, user_id):
        try:
            Utils.Validator.fetch_all()
            voiceover_details = list(structured_data.Database.find_bulk(structured_data.Database.voiceovers,
                                                                        {"step_id": request.args.get("step_id")},
                                                                        {"_id": 0}))
            return make_response({
                constants.APIResponse.Fields.STATUS: constants.APIResponse.Statuses.SUCCESS,
                constants.APIResponse.Fields.MESSAGE: f"{len(voiceover_details)} voiceover fetched",
                "voiceovers": [
                    {**_, "audio_url": unstructured_data.Database.generate_download_url(_["path_audio"])} for _ in
                    voiceover_details]})
        except AssertionError as ase:
            logging.Funcs.create_error_log(ase, account_id=account_id, user_id=user_id,
                                           component_id=request.args.get("step_id"))
            return general.APIResponse.Error.get_response(ase, 401)
        except Exception as e:
            logging.Funcs.create_error_log(e, account_id=account_id, user_id=user_id,
                                           component_id=request.args.get("step_id"))
            return general.APIResponse.Error.get_response(constants.APIResponse.Messages.BUSINESS_ERROR, 500)


class Utils:
    class Validator:

        @staticmethod
        def create():
            assert request.json.get("demo_id"), "demo_id missing from request body"
            assert request.json.get("step_id"), "step_id missing from request body"
            assert request.json.get("speaker_id"), "speaker_id missing from request body"
            assert not structured_data.Database.find_single(structured_data.Database.voiceovers,
                                                            {"speaker_id": request.json.get("speaker_id"),
                                                             "step_id": request.json.get("step_id")},
                                                            {"_id": 0}), "voiceover for the given speaker and step " \
                                                                         "already exists. update " \
                                                                         "the voiceover"

        @staticmethod
        def create_uploaded():
            assert request.json.get("demo_id"), "demo_id missing from request body"
            assert request.json.get("step_id"), "step_id missing from request body"
            assert request.args.get("audio_type"), "audio_type missing from request body"
            assert request.args.get("audio_type") in constants.Audios.AudioTypes.all(), "invalid audio_type"

        @staticmethod
        def fetch_all():
            assert request.args.get("step_id"), "step_id missing from request parameters"
