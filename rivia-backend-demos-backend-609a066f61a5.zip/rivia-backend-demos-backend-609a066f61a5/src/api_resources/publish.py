from src.funcs import general, search
from src.components import structured_data, constants, logging, alerts
from flask import request, make_response


class Ops:

    @staticmethod
    @logging.Funcs.log_func_call("fetching published demos")
    def fetch(account_id, user_id):
        try:
            results = search.Ops.fetch(structured_data.Database.published_demos,
                                       account_id=account_id,
                                       page_number=int(request.args.get("page_number", 0)),
                                       date_start=request.args.get("date_start"),
                                       date_end=request.args.get("date_end"),
                                       text_query=request.args.get("text_query"),
                                       num_results=20,
                                       extra_constraints={"type": constants.Previews.WEB})
            count = search.Ops.count(structured_data.Database.published_demos,
                                     account_id=account_id,
                                     date_start=request.args.get("date_start"),
                                     date_end=request.args.get("date_end"),
                                     text_query=request.args.get("text_query"),
                                     extra_constraints={"type": constants.Previews.WEB})
        except AssertionError as ase:
            logging.Funcs.create_error_log(ase, account_id=account_id, user_id=user_id)
            return general.APIResponse.Error.get_response(ase, 401)
        except Exception as e:
            logging.Funcs.create_error_log(e, account_id=account_id, user_id=user_id)
            return general.APIResponse.Error.get_response(constants.APIResponse.Messages.BUSINESS_ERROR, 500)
        else:
            return make_response({
                constants.APIResponse.Fields.STATUS: constants.APIResponse.Statuses.SUCCESS,
                constants.APIResponse.Fields.MESSAGE: f"{len(results)} out of {count} demos retrieved",
                "results": results,
                "count": count
            }, 200)

    @staticmethod
    def create(account_id, user_id):
        try:
            Utils.Validator.validate_create_publish_request()
            # delete all the existing published data
            structured_data.Database.delete_single(structured_data.Database.published_demos,
                                                   {"demo_id": request.json.get("demo_id"),
                                                    "type": request.args.get("type")})
            structured_data.Database.delete_many(structured_data.Database.published_captures,
                                                 {"demo_id": request.json.get("demo_id"),
                                                  "type": request.args.get("type")})
            structured_data.Database.delete_many(structured_data.Database.published_steps,
                                                 {"demo_id": request.json.get("demo_id"),
                                                  "type": request.args.get("type")})
            structured_data.Database.delete_many(structured_data.Database.published_interactions,
                                                 {"demo_id": request.json.get("demo_id"),
                                                  "type": request.args.get("type")})
            structured_data.Database.delete_single(structured_data.Database.published_menus,
                                                   {"demo_id": request.json.get("demo_id"),
                                                    "type": request.args.get("type")})
            structured_data.Database.delete_many(structured_data.Database.published_menu_options,
                                                 {"demo_id": request.json.get("demo_id"),
                                                  "type": request.args.get("type")})
            structured_data.Database.delete_many(structured_data.Database.published_flows,
                                                 {"demo_id": request.json.get("demo_id"),
                                                  "type": request.args.get("type")})
            structured_data.Database.delete_many(structured_data.Database.published_connections,
                                                 {"demo_id": request.json.get("demo_id"),
                                                  "type": request.args.get("type")})
            structured_data.Database.delete_many(structured_data.Database.published_voiceovers,
                                                 {"demo_id": request.json.get("demo_id"),
                                                  "type": request.args.get("type")})
            structured_data.Database.delete_many(structured_data.Database.published_redirects,
                                                 {"demo_id": request.json.get("demo_id"),
                                                  "type": request.args.get("type")})

            # add the latest data back to the published tables
            structured_data.Database.add_single(structured_data.Database.published_demos,
                                                {**structured_data.Database.find_single(structured_data.Database.demos,
                                                                                        {"demo_id": request.json.get(
                                                                                            "demo_id")}, {"_id": 0}),
                                                 "type": request.args.get("type"),
                                                 "updated_at": general.Time.get_current_time(),
                                                 "max_screen_width": request.json.get("max_screen_width", None)})
            structured_data.Database.add_bulk(structured_data.Database.published_captures,
                                              [{**document, "type": request.args.get("type")} for document in
                                               structured_data.Database.find_bulk(structured_data.Database.captures,
                                                                                  {"demo_id": request.json.get(
                                                                                      "demo_id")},
                                                                                  {"_id": 0})])

            structured_data.Database.add_bulk(structured_data.Database.published_redirects,
                                              [{**document, "type": request.args.get("type")} for document in
                                               structured_data.Database.find_bulk(structured_data.Database.redirects,
                                                                                  {"demo_id": request.json.get(
                                                                                      "demo_id")},
                                                                                  {"_id": 0})])

            # adding voiceover data here. no variation between the mobile and web views
            steps = list(structured_data.Database.find_bulk(structured_data.Database.steps,
                                                            {"demo_id": request.json.get("demo_id")}, {"_id": 0}))
            structured_data.Database.add_bulk(structured_data.Database.published_voiceovers,
                                              [{**document, "type": request.args.get("type")} for document in
                                               structured_data.Database.find_bulk(
                                                   structured_data.Database.voiceovers,
                                                   {"voiceover_id": {"$in": [_['voiceover_id'] for _ in steps if
                                                                             _.get('voiceover_id')]}}, {"_id": 0})])
            if structured_data.Database.count(structured_data.Database.menus, {"demo_id": request.json.get("demo_id")}):
                structured_data.Database.add_single(structured_data.Database.published_menus,
                                                    {**structured_data.Database.find_single(
                                                        structured_data.Database.menus,
                                                        {"demo_id": request.json.get(
                                                            "demo_id")}, {"_id": 0}),
                                                     "type": request.args.get("type")})
            structured_data.Database.add_bulk(structured_data.Database.published_menu_options,
                                              [{**document, "type": request.args.get("type")} for document in
                                               structured_data.Database.find_bulk(structured_data.Database.menu_options,
                                                                                  {"demo_id": request.json.get(
                                                                                      "demo_id")}, {"_id": 0})])
            structured_data.Database.add_bulk(structured_data.Database.published_flows,
                                              [{**document, "type": request.args.get("type")} for document in
                                               structured_data.Database.find_bulk(
                                                   structured_data.Database.flows,
                                                   {"demo_id": request.json.get("demo_id")},
                                                   {"_id": 0})])
            if request.args.get("type") == constants.Previews.PLAYGROUND:
                structured_data.Database.add_bulk(structured_data.Database.published_connections,
                                                  [{**document, "type": request.args.get("type")} for document in
                                                   structured_data.Database.find_bulk(
                                                       structured_data.Database.connections,
                                                       {"demo_id": request.json.get(
                                                           "demo_id")},
                                                       {"_id": 0})])
            if request.args.get("type") == constants.Previews.WEB:
                # the following steps for the mobile version will be added later via frontend
                structured_data.Database.add_bulk(structured_data.Database.published_steps,
                                                  [{**document, "type": request.args.get("type")} for document in
                                                   steps])
                structured_data.Database.add_bulk(structured_data.Database.published_interactions,
                                                  [{**document, "type": request.args.get("type")} for document in
                                                   structured_data.Database.find_bulk(
                                                       structured_data.Database.interactions,
                                                       {"demo_id": request.json.get(
                                                           "demo_id")},
                                                       {"_id": 0})])
        except AssertionError as ase:
            logging.Funcs.create_error_log(ase, account_id=account_id, user_id=user_id,
                                           component_id=request.json.get("demo_id"))
            return general.APIResponse.Error.get_response(ase, 401)
        except Exception as e:
            logging.Funcs.create_error_log(e, account_id=account_id, user_id=user_id,
                                           component_id=request.json.get("demo_id"))
            return general.APIResponse.Error.get_response(constants.APIResponse.Messages.BUSINESS_ERROR, 500)
        else:
            alerts.SlackAlert.demo_published(account_id, user_id, request.json.get("demo_id"), request.args.get("type"))
            return make_response({constants.APIResponse.Fields.STATUS: constants.APIResponse.Statuses.SUCCESS,
                                  constants.APIResponse.Fields.MESSAGE: "published"}, 200)


class Utils:
    class Validator:
        @staticmethod
        def validate_create_publish_request():
            assert request.json.get("demo_id"), "demo_id missing from request body"
            assert request.args.get("type"), "type missing from request body"
            assert request.args.get("type") in constants.Previews.all(), "invalid type value"
            if request.args.get("type") == constants.Previews.MOBILE:
                assert request.json.get("max_screen_width"), "max_screen_width missing from request body"
            if request.args.get("type") == constants.Previews.PLAYGROUND:
                assert structured_data.Database.find_single(structured_data.Database.demos,
                                                            {"demo_id": request.json.get("demo_id")},
                                                            {"master_capture_id": 1}).get(
                    "master_capture_id"), "demo cannot be published as playground with master_capture_id"
