from src.funcs import general
from flask import request, make_response
from src.components import logging, constants, structured_data, lambdas, configs
from collections import namedtuple

personalised_demo = namedtuple("personalised_demo", ["new_demo_id", "demo_id", "seller_webpage",
                                                     "seller_name", "buyer_webpage", "buyer_name",
                                                     "buyer_prospect_name",
                                                     "buyer_profile", "demo_summary",
                                                     "created_at", "updated_at", "status"])


class Ops:

    @staticmethod
    @logging.Funcs.log_func_call("creating personalised demo")
    def create(account_id, user_id):
        try:
            Utils.RequestValidator.validate_create()
            personalised_demo_obj = personalised_demo(general.Identifiers.generate_personalised_demo_id(),
                                                      request.json.get("demo_id"),
                                                      request.json.get("seller_webpage"),
                                                      request.json.get("seller_name"),
                                                      request.json.get("buyer_webpage"),
                                                      request.json.get("buyer_name"),
                                                      request.json.get("buyer_prospect_name"),
                                                      request.json.get("buyer_profile"),
                                                      request.json.get("demo_summary"),
                                                      general.Time.get_current_time(),
                                                      general.Time.get_current_time(),
                                                      constants.PersonalisedDemos.Statuses.PENDING)
            structured_data.Database.add_single(structured_data.Database.personalised_demos,
                                                personalised_demo_obj._asdict())
            lambdas.LambdaExecutor.add_job(configs.AWS.PERSONALISE_DEMO_LAMBDA,
                                           personalised_demo_obj._asdict())
        except AssertionError as ase:
            logging.Funcs.create_error_log(ase, account_id=account_id, user_id=user_id,
                                           component_id=request.json.get("demo_id"))
            return general.APIResponse.Error.get_response(ase, 401)
        except Exception as e:
            logging.Funcs.create_error_log(e, account_id=account_id, user_id=user_id,
                                           component_id=request.json.get("demo_id"))
            return general.APIResponse.Error.get_response(constants.APIResponse.Messages.BUSINESS_ERROR, 500)
        else:
            return make_response({constants.APIResponse.Fields.STATUS: constants.APIResponse.Statuses.SUCCESS,
                                  constants.APIResponse.Fields.MESSAGE: "personalised demo created"},
                                 200)


class Utils:
    class RequestValidator:
        @staticmethod
        def validate_create():
            assert request.json.get("demo_id"), "demo_id is required"
            assert request.json.get("seller_webpage"), "seller_webpage is required"
            assert request.json.get("seller_name"), "seller_name is required"
            assert request.json.get("buyer_webpage"), "buyer_webpage is required"
            assert request.json.get("buyer_name"), "buyer_name is required"
            assert request.json.get("buyer_prospect_name"), "buyer_prospect_name is required"
            assert request.json.get("buyer_profile"), "buyer_profile is required"
            assert request.json.get("demo_summary"), "demo_summary is required"
