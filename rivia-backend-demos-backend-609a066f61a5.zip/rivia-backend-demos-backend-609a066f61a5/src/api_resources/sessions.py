from src.components import sessions, structured_data, logging, constants, airtable
from src.funcs import general, search
from flask import request, make_response
from datetime import datetime
import re


class Ops:

    @staticmethod
    def create_log():
        try:
            Utils.validate_create_session_log_request()
            session_log = sessions.SessionLog(session_id=request.json.get("session_id"),
                                              session_log=request.json.get("log"))
            structured_data.Database.update_single(structured_data.Database.sessions,
                                                   {"session_id": session_log.session_id},
                                                   {"$push": {"log": session_log.as_json()}})
            structured_data.Database.update_single(structured_data.Database.sessions,
                                                   {"session_id": session_log.session_id, "email": None},
                                                   [{"$set": {"is_session": {
                                                       "$switch": {"branches": [
                                                           {"case": {"$gte": [{"$size": "$log"}, 3]}, "then": True}],
                                                           "default": False}}}}])
            # if general.Components.Accounts.get_details_by_account_id(request.json.get("account_id")):
            #     if general.Components.Accounts.get_details_by_account_id(
            #             request.json.get("account_id")).get("airtable_base_id"):
            #         airtable.Airtable.create_record(base_id=general.Components.Accounts.get_details_by_account_id(
            #             request.json.get("account_id")).get("airtable_base_id"),
            #                                         table_id=general.Components.Accounts.get_details_by_account_id(
            #                                             request.json.get("account_id")).get("airtable_logs_table_id"),
            #                                         payload=session_log.as_airtable_record())
        except AssertionError as ase:
            logging.Funcs.create_error_log(ase, component_id=request.json.get("session_id"))
            return general.APIResponse.Error.get_response(ase, 400)
        except Exception as e:
            logging.Funcs.create_error_log(e, component_id=request.json.get("session_id"))
            return general.APIResponse.Error.get_response(constants.APIResponse.Messages.BUSINESS_ERROR, 500)
        else:
            return make_response({constants.APIResponse.Fields.STATUS: constants.APIResponse.Statuses.SUCCESS,
                                  constants.APIResponse.Fields.MESSAGE: "log created"}, 200)

    @staticmethod
    def fetch_single(account_id, user_id, session_id):
        try:
            session_details = structured_data.Database.find_single(structured_data.Database.sessions,
                                                                   {"session_id": session_id}, {"_id": 0})
            assert session_details, "invalid session id"
        except AssertionError as ase:
            logging.Funcs.create_error_log(ase, account_id=account_id, user_id=user_id, component_id=session_id)
            return general.APIResponse.Error.get_response(ase, 400)
        except Exception as e:
            logging.Funcs.create_error_log(e, account_id=account_id, user_id=user_id, component_id=session_id)
            return general.APIResponse.Error.get_response(constants.APIResponse.Messages.BUSINESS_ERROR, 500)
        else:
            return make_response({constants.APIResponse.Fields.STATUS: constants.APIResponse.Statuses.SUCCESS,
                                  constants.APIResponse.Fields.MESSAGE: "session retrieved",
                                  "session": session_details}, 200)

    @staticmethod
    def fetch(account_id, user_id):
        try:
            assert request.args.get("demo_id"), "demo_id missing in the request parameters"
            demo_details = structured_data.Database.find_single(structured_data.Database.demos,
                                                                {"demo_id": request.args.get("demo_id")}, {"_id": 0})
            assert demo_details, "demo does not exist"
            total_steps = structured_data.Database.count(structured_data.Database.steps,
                                                         {"demo_id": request.args.get("demo_id")})
            results = Utils.update_locations_in_sessions(
                Utils.add_stats_to_sessions(search.Ops.fetch(structured_data.Database.sessions,
                                                             account_id=account_id,
                                                             page_number=int(request.args.get("page_number", 0)),
                                                             date_start=request.args.get("date_start"),
                                                             date_end=request.args.get("date_end"),
                                                             text_query=request.args.get("text_query"),
                                                             num_results=24,
                                                             projection={"_id": 0},
                                                             extra_constraints={
                                                                 **{"demo_id": request.args.get("demo_id"),
                                                                    "is_session": True},
                                                                 **(lambda x: {"email": {
                                                                     "$nin": [None]}} if x == "true" else {})(
                                                                     request.args.get("has_email"))
                                                             },
                                                             sort_by="created_at"),
                                            total_steps_in_demo=total_steps))
            links_data = list(structured_data.Database.find_bulk(structured_data.Database.links,
                                                                 {"demo_id": request.args.get("demo_id")}, {"_id": 0}))
            count = search.Ops.count(structured_data.Database.sessions,
                                     account_id=account_id,
                                     date_start=request.args.get("date_start"),
                                     date_end=request.args.get("date_end"),
                                     text_query=request.args.get("text_query"),
                                     extra_constraints={
                                         **{"demo_id": request.args.get("demo_id"),
                                            "is_session": True},
                                         **(lambda x: {"email": {
                                             "$nin": [None]}} if x == "true" else {})(
                                             request.args.get("has_email"))
                                     })
            for _ in results:
                del _["log"]
        except AssertionError as ase:
            logging.Funcs.create_error_log(ase, account_id=account_id, user_id=user_id)
            return general.APIResponse.Error.get_response(ase, 400)
        except Exception as e:
            logging.Funcs.create_error_log(e, account_id=account_id, user_id=user_id)
            return general.APIResponse.Error.get_response(constants.APIResponse.Messages.BUSINESS_ERROR, 500)
        else:
            return make_response({constants.APIResponse.Fields.STATUS: constants.APIResponse.Statuses.SUCCESS,
                                  constants.APIResponse.Fields.MESSAGE: "sessions retrieved",
                                  "sessions": results,
                                  "links": links_data,
                                  "num_views": demo_details.get("num_views", 0),
                                  "total_num_sessions": count,
                                  "average_completion_percent": demo_details.get("average_percentage_completion", 0),
                                  "total_time_spent": demo_details.get("total_time_spent", 0),
                                  "average_time_spent": demo_details.get("total_time_spent", 0) / max(1,
                                                                                                      demo_details.get(
                                                                                                          "num_views",
                                                                                                          0))}, 200)


class Utils:

    @staticmethod
    def validate_create_session_log_request():
        assert request.json.get("session_id"), 'session_id missing from request body'
        assert request.json.get("account_id"), "account_id missing from request body"
        assert request.json.get("log"), "log missing from request body"

    @staticmethod
    def update_locations_in_sessions(results):
        return [{**_, "ip_address": Utils.__update_empty_location(Utils.__process_location(_.get("ip_address")))}
                for _ in results]

    @staticmethod
    def __process_location(location):
        return re.sub(r'(\(?(\d{1,3}\.\d{1,3}\.\d{1,3}\.\d{1,3})\)?)', '', location).strip().replace("()", "").replace(
            ", ,", "")

    @staticmethod
    def __update_empty_location(location):
        return "Unidentified" if not location else location

    @staticmethod
    def add_stats_to_sessions(results, total_steps_in_demo):
        return [{**_,
                 "time_spent": Utils.__compute_time_spent_in_session(_),
                 "percentage_completion": Utils.__compute_percentage_completion(_, total_steps_in_demo),
                 "flows": Utils.__compute_flow_wise_completion(_)} for _ in results]

    @staticmethod
    def __compute_time_spent_in_session(session_details):
        if len(session_details["log"]) < 2:
            return 0
        return (datetime.fromisoformat(session_details["log"][-1]["created_at"]) - datetime.fromisoformat(
            session_details["log"][0]["created_at"])).total_seconds()

    @staticmethod
    def __compute_flow_wise_completion(session_details):
        if len(session_details["log"]) < 2:
            return 0
        flow_activities = {}
        for idx, session_activity in enumerate(session_details["log"]):
            if idx == len(session_details["log"]) - 1:
                session_details["log"][idx]["time_spent"] = 0
            else:
                session_details["log"][idx]["time_spent"] = (datetime.fromisoformat(
                    session_details["log"][idx + 1]["created_at"]) - datetime.fromisoformat(
                    session_details["log"][idx]["created_at"])).total_seconds()

        for session_activity in session_details["log"]:
            if session_activity["log"]["flow_id"] in flow_activities:
                existing_flow = flow_activities[session_activity["log"]["flow_id"]]
                flow_activities[session_activity["log"]["flow_id"]] = {
                    "steps_covered": max(session_activity["log"]["step"], existing_flow["steps_covered"]),
                    "total_steps": max(session_activity["log"]["total_steps"], existing_flow["total_steps"]),
                    "time_spent": session_activity["time_spent"] + existing_flow["time_spent"]
                }
            else:
                flow_activities[session_activity["log"]["flow_id"]] = {
                    "steps_covered": session_activity["log"]["step"],
                    "total_steps": session_activity["log"]["total_steps"],
                    "time_spent": session_activity["time_spent"]
                }
        return flow_activities

    @staticmethod
    def __compute_percentage_completion(session_details, total_steps_in_demos):
        if len(session_details["log"]) < 2:
            return 0
        flow_activities = {}
        for session_activity in session_details["log"]:
            if session_activity["log"]["flow_id"] in flow_activities:
                existing_flow = flow_activities[session_activity["log"]["flow_id"]]
                flow_activities[session_activity["log"]["flow_id"]] = {
                    "steps_covered": max(session_activity["log"]["step"], existing_flow["steps_covered"]),
                    "total_steps": max(session_activity["log"]["total_steps"], existing_flow["total_steps"]),
                }
            else:
                flow_activities[session_activity["log"]["flow_id"]] = {
                    "steps_covered": session_activity["log"]["step"],
                    "total_steps": session_activity["log"]["total_steps"],
                }
        # return round(sum([_["steps_covered"] for _ in list(flow_activities.values())]) * 100 / sum(
        #     [_["total_steps"] for _ in list(flow_activities.values())]), 2)

        return round(
            sum([_["steps_covered"] for _ in list(flow_activities.values())]) * 100 / max(1, total_steps_in_demos))
