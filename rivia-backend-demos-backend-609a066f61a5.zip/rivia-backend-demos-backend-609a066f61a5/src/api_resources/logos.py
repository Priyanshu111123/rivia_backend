from src.funcs import general
from src.components import logging, constants, configs, captures, unstructured_data
import requests
from flask import make_response, request
import io


class Ops:

    @staticmethod
    @logging.Funcs.log_func_call("fetching logo")
    def fetch(account_id, user_id, domain):
        try:
            assert request.args.get("demo_id"), "demo_id not found in request url"
            response = requests.get(f"{configs.Clearbit.URL}/{domain}")
            assert response.status_code == 200, "logo not found"
            static_capture = captures.FactoryFuncs.create_static_content(account_id, request.args.get("demo_id"))
            unstructured_data.Database.upload(static_capture.path_storage, file_content=io.BytesIO(response.content),
                                              extra_args={'ContentType': 'image/png'},
                                              bucket_name=configs.AWS.STATIC_CONTENT_BUCKET)
            # return Utils.convert_to_flask_response(response)
        except AssertionError as ase:
            logging.Funcs.create_error_log(ase, account_id=account_id, user_id=user_id)
            return general.APIResponse.Error.get_response(ase, 401)
        except Exception as e:
            logging.Funcs.create_error_log(e, account_id=account_id, user_id=user_id)
            return general.APIResponse.Error.get_response(constants.APIResponse.Messages.BUSINESS_ERROR, 500)
        else:
            return make_response({
                constants.APIResponse.Fields.STATUS: constants.APIResponse.Statuses.SUCCESS,
                constants.APIResponse.Fields.MESSAGE: "created",
                "capture": {
                    **static_capture.as_json()
                }
            }, 200)

# class Utils:
#
#     @staticmethod
#     def convert_to_flask_response(requests_response):
#         flask_response = make_response(requests_response.content)
#         flask_response.status_code = requests_response.status_code
#         flask_response.headers = {'Content-Type': requests_response.headers.get('Content-Type')}
#         return flask_response
