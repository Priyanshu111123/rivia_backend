import io
import json
from src.components import logging, constants, demos, structured_data, unstructured_data, lambdas, configs, alerts
from src.components import flows, cloners
from flask import request, make_response
from src.funcs import general, search
from itertools import groupby
from operator import itemgetter
import os


class Ops:

    @staticmethod
    @logging.Funcs.log_func_call("creating demo")
    def create(account_id, user_id):
        try:
            demo = demos.FactoryFuncs.create_demo(account_id=account_id, user_id=user_id,
                                                  title=request.json.get("title", None),
                                                  demo_type=request.json.get("demo_type",
                                                                             constants.Demos.DemoTypes.LINEAR),
                                                  has_htmls=request.json.get("has_htmls", True),
                                                  has_images=request.json.get("has_images", False))
            flows.FactoryFuncs.create(account_id=account_id, user_id=user_id, demo_id=demo.demo_id,
                                      title="Default Flow", is_default=True, position=0)
        except AssertionError as ase:
            logging.Funcs.create_error_log(ase, account_id=account_id, user_id=user_id)
            return general.APIResponse.Error.get_response(ase, 401)
        except Exception as e:
            logging.Funcs.create_error_log(e, account_id=account_id, user_id=user_id)
            return general.APIResponse.Error.get_response(constants.APIResponse.Messages.BUSINESS_ERROR, 500)
        else:
            alerts.SlackAlert.demo_created(account_id, user_id, demo.demo_id)
            return make_response({
                constants.APIResponse.Fields.STATUS: constants.APIResponse.Statuses.SUCCESS,
                constants.APIResponse.Fields.MESSAGE: "demo created successfully",
                "demo": {
                    **demo.as_json()
                }
            }, 200)

    @staticmethod
    @logging.Funcs.log_func_call("duplicate demo")
    def duplicate(account_id, user_id, demo_id):
        try:
            cloner = cloners.DemoCloner(account_id=account_id, user_id=user_id, source_demo_id=demo_id)
            cloner.set_source()
            cloner.update_ids()
            cloner.modify_demo()
            cloner.modify_menu()
            cloner.modify_menu_options()
            cloner.modify_flows()
            cloner.modify_steps()
            cloner.modify_captures()
            cloner.modify_interactions()
            cloner.modify_connections()
            cloner.modify_redirects()
            cloner.add_to_database()
            lambdas.LambdaExecutor.add_job(function_name=configs.AWS.CLONE_FILES_LAMBDA,
                                           message_body={"ops": cloner.copy_ops},
                                           sync=False)
            del cloner.source["demo"]["_id"]
        except AssertionError as ase:
            logging.Funcs.create_error_log(ase, account_id=account_id, user_id=user_id)
            return general.APIResponse.Error.get_response(ase, 401)
        except Exception as e:
            logging.Funcs.create_error_log(e, account_id=account_id, user_id=user_id)
            return general.APIResponse.Error.get_response(constants.APIResponse.Messages.BUSINESS_ERROR, 500)
        else:
            alerts.SlackAlert.demo_created(account_id, user_id, cloner.demo_id)
            return make_response({
                constants.APIResponse.Fields.STATUS: constants.APIResponse.Statuses.SUCCESS,
                constants.APIResponse.Fields.MESSAGE: "demo duplicated successfully",
                "demo": {
                    **cloner.source["demo"]
                }
            }, 200)

    @staticmethod
    @logging.Funcs.log_func_call("deleting demo")
    def delete(account_id, user_id, demo_id):
        try:
            structured_data.Database.delete_single(structured_data.Database.demos, {"demo_id": demo_id})
            structured_data.Database.delete_many(structured_data.Database.steps, {"demo_id": demo_id})
            structured_data.Database.delete_many(structured_data.Database.captures, {"demo_id": demo_id})
            structured_data.Database.delete_many(structured_data.Database.interactions, {"demo_id": demo_id})
            structured_data.Database.delete_many(structured_data.Database.flows, {"demo_id": demo_id})
        except AssertionError as ase:
            logging.Funcs.create_error_log(ase, account_id=account_id, user_id=user_id, component_id=demo_id)
            return general.APIResponse.Error.get_response(ase, 401)
        except Exception as e:
            logging.Funcs.create_error_log(e, account_id=account_id, user_id=user_id, component_id=demo_id)
            return general.APIResponse.Error.get_response(constants.APIResponse.Messages.BUSINESS_ERROR, 500)
        else:
            return make_response({
                constants.APIResponse.Fields.STATUS: constants.APIResponse.Statuses.SUCCESS,
                constants.APIResponse.Fields.MESSAGE: "demo deleted"
            }, 200)

    @staticmethod
    @logging.Funcs.log_func_call("fetch single demo")
    def fetch_single(account_id, user_id, demo_id):
        try:
            if request.args.get("type") == constants.Previews.PLAYGROUND:
                return Ops.__create_unpublished_playground_payload(demo_id)
            else:
                return Ops.__create_unpublished_demo_payload(demo_id)

        except AssertionError as ase:
            logging.Funcs.create_error_log(ase, account_id=account_id, user_id=user_id, component_id=demo_id)
            return general.APIResponse.Error.get_response(ase, 401)
        except Exception as e:
            logging.Funcs.create_error_log(e, account_id=account_id, user_id=user_id, component_id=demo_id)
            return general.APIResponse.Error.get_response(constants.APIResponse.Messages.BUSINESS_ERROR, 500)

    @staticmethod
    @logging.Funcs.log_func_call("creating payload for unpublished playground view")
    def __create_unpublished_playground_payload(demo_id):
        demo_details = structured_data.Database.find_single(structured_data.Database.demos,
                                                            {"demo_id": demo_id}, {"_id": 0})
        assert demo_details, "invalid demo id"
        captures = structured_data.Database.find_bulk(structured_data.Database.captures,
                                                      {"demo_id": demo_id}, {"_id": 0}).sort([("position", 1)])
        connections = list(structured_data.Database.find_bulk(structured_data.Database.connections,
                                                              {"demo_id": demo_id}, {"_id": 0}))
        redirects = list(structured_data.Database.find_bulk(structured_data.Database.redirects,
                                                            {"demo_id": demo_id}, {"_id": 0}))
        published_versions = {_["type"]: _ for _ in
                              structured_data.Database.find_bulk(structured_data.Database.published_demos,
                                                                 {"demo_id": demo_id}, {"_id": 0})}
        return make_response({
            constants.APIResponse.Fields.STATUS: constants.APIResponse.Statuses.SUCCESS,
            constants.APIResponse.Fields.MESSAGE: "demo playground retrieved",
            "demo": {
                **demo_details,
                "captures": [{**capture,
                              "html_url": unstructured_data.Database.generate_download_url(capture["path_html"]),
                              "image_url": unstructured_data.Database.generate_download_url(capture["path_image"]),
                              "thumbnail_url": unstructured_data.Database.generate_download_url(
                                  (lambda path: path if path else capture["path_image"])(
                                      capture.get("path_thumbnail")))}
                             for capture in captures],
                "connections": connections,
                "redirects": redirects,
                "published": published_versions
            }
        }, 200)

    @staticmethod
    @logging.Funcs.log_func_call("creating payload for unpublished demo view")
    def __create_unpublished_demo_payload(demo_id):
        demo_details = structured_data.Database.find_single(structured_data.Database.demos,
                                                            {"demo_id": demo_id}, {"_id": 0})
        assert demo_details, "invalid demo id"
        captures = structured_data.Database.find_bulk(structured_data.Database.captures,
                                                      {"demo_id": demo_id}, {"_id": 0}).sort([("position", 1)])
        redirects = list(structured_data.Database.find_bulk(structured_data.Database.redirects,
                                                            {"demo_id": demo_id}, {"_id": 0}))
        steps = list(structured_data.Database.find_bulk(structured_data.Database.steps,
                                                        {"demo_id": demo_id}, {"_id": 0}).sort([("position", 1)]))
        structured_data.Database.update_single(structured_data.Database.demos, {"demo_id": demo_id},
                                               {"$set": {"updated_at": general.Time.get_current_time()}})
        voiceovers = structured_data.Database.find_bulk(structured_data.Database.voiceovers,
                                                        {"voiceover_id": {
                                                            "$in": [_['voiceover_id'] for _ in steps if
                                                                    _.get('voiceover_id')]}}, {"_id": 0})

        interactions = [{**item, "edit_state": {**item.get("edit_state"),
            "video_url": unstructured_data.Database.generate_cdn_url(
                item.get("path_video")),
            "events_url": unstructured_data.Database.generate_cdn_url(
                item.get("path_events")),
            "image_url": unstructured_data.Database.generate_cdn_url(item.get("path_image"))}} for item in
            structured_data.Database.find_bulk(structured_data.Database.interactions,
                                               {"demo_id": demo_id}, {"_id": 0})]
        flows_data = Utils.Aggregator.add_steps_to_flows(
            structured_data.Database.find_bulk(structured_data.Database.flows, {"demo_id": demo_id}, {"_id": 0}),
            Utils.Aggregator.group_steps_into_flows(steps, interactions))
        menu = (lambda record: record if record else {})(
            structured_data.Database.find_single(structured_data.Database.menus,
                                                 {"demo_id": demo_id}, {"_id": 0}))
        menu_options = list(structured_data.Database.find_bulk(structured_data.Database.menu_options,
                                                               {"demo_id": demo_id}, {"_id": 0}).sort(
            [("position", 1)]))
        published_versions = {_["type"]: _ for _ in
                              structured_data.Database.find_bulk(structured_data.Database.published_demos,
                                                                 {"demo_id": demo_id}, {"_id": 0})}
        return make_response({
            constants.APIResponse.Fields.STATUS: constants.APIResponse.Statuses.SUCCESS,
            constants.APIResponse.Fields.MESSAGE: "demo retrieved",
            "demo": {
                **demo_details,
                "captures": [{**capture,
                              "html_url": unstructured_data.Database.generate_download_url(capture["path_html"]),
                              "image_url": unstructured_data.Database.generate_download_url(capture["path_image"]),
                              "thumbnail_url": unstructured_data.Database.generate_download_url(
                                  (lambda path: path if path else capture["path_image"])(
                                      capture.get("path_thumbnail")))}
                             for capture in captures],
                "voiceovers": [{**voiceover,
                                "audio_url": unstructured_data.Database.generate_download_url(voiceover["path_audio"])}
                               for voiceover in voiceovers],
                "flows": flows_data,
                "menu": {**menu, "options": menu_options},
                "redirects": redirects,
                "published": published_versions
            }
        }, 200)

    @staticmethod
    @logging.Funcs.log_func_call("fetch single demo -- published -- using public link")
    def fetch_published_using_public_link(link_id):
        try:
            link_details = structured_data.Database.find_single(structured_data.Database.links,
                                                                {"link_id": link_id}, {"_id": 0})
            if link_details.get("is_password_protected"):
                assert request.headers.get(constants.API.Headers.AUTH_FIELD), "password not provided"
                assert request.headers.get(constants.API.Headers.AUTH_FIELD) == link_details.get(
                    "password"), "invalid password"
            assert link_details, "invalid link"
            return Ops.fetch_published_single_opt(link_details["account_id"], link_details["demo_id"])
        except AssertionError as ase:
            logging.Funcs.create_error_log(ase, account_id=None, user_id="published", component_id=link_id)
            return general.APIResponse.Error.get_response(ase, 401)
        except Exception as e:
            logging.Funcs.create_error_log(e, account_id=None, user_id="published", component_id=link_id)
            return general.APIResponse.Error.get_response(constants.APIResponse.Messages.BUSINESS_ERROR, 500)

    @staticmethod
    @logging.Funcs.log_func_call("fetch single demo -- published -- optimized")
    def fetch_published_single_opt(account_id, demo_id):
        try:
            version = Utils.Published.get_version(demo_id)
            cached_results = structured_data.Database.find_single(structured_data.Database.published_demos,
                                                                  {"account_id": account_id, "demo_id": demo_id,
                                                                   "type": version},
                                                                  {"_id": 0})
            assert cached_results, "invalid demo id"
            assert cached_results.get("enable_standard_public_link") is not False, "invalid link"
            if cached_results.get(f"cached_{version}"):
                demo_content = io.BytesIO()
                unstructured_data.Database.download(path=cached_results[f"cached_{version}"],
                                                    file_content=demo_content)
                demo_content.seek(0)
                demo_content = json.load(demo_content)
                return make_response({
                    constants.APIResponse.Fields.STATUS: constants.APIResponse.Statuses.SUCCESS,
                    constants.APIResponse.Fields.MESSAGE: "demo retrieved",
                    "demo_path": unstructured_data.Database.generate_cdn_url(cached_results.get(f"cached_{version}")),
                    **demo_content
                }, 200)

            if request.args.get("type") == constants.Previews.PLAYGROUND:
                demo = Ops.__create_published_playground_payload(account_id, demo_id, version)
            else:
                demo = Ops.__create_published_demo_payload(account_id, demo_id, version)

            cached_results_path = os.path.join(account_id, demo_id, "published",
                                               general.Identifiers.generate(length=10))
            structured_data.Database.update_single(structured_data.Database.published_demos,
                                                   {"demo_id": demo_id, "type": version},
                                                   {"$set": {f"cached_{version}": cached_results_path}})
            unstructured_data.Database.upload(path=cached_results_path,
                                              file_content=io.BytesIO(json.dumps(demo).encode("UTF-8")))
        except AssertionError as ase:
            logging.Funcs.create_error_log(ase, account_id=account_id, user_id="published", component_id=demo_id)
            return general.APIResponse.Error.get_response(ase, 401)
        except Exception as e:
            logging.Funcs.create_error_log(e, account_id=account_id, user_id="published", component_id=demo_id)
            return general.APIResponse.Error.get_response(constants.APIResponse.Messages.BUSINESS_ERROR, 500)
        else:
            return make_response({
                constants.APIResponse.Fields.STATUS: constants.APIResponse.Statuses.SUCCESS,
                constants.APIResponse.Fields.MESSAGE: "demo retrieved",
                "demo_path": unstructured_data.Database.generate_cdn_url(cached_results_path),
                **demo
            }, 200)

    @staticmethod
    @logging.Funcs.log_func_call("creating published playground payload")
    def __create_published_playground_payload(account_id, demo_id, version):
        demo_details = list(structured_data.Database.aggregate(
            structured_data.Database.published_demos,
            [{"$match": {"demo_id": demo_id, "account_id": account_id, "type": version}},
             {"$project": {"_id": 0}},
             {"$lookup": {"from": constants.Data.Structured.PUBLISHED_CAPTURES,
                          "pipeline": [{"$match": {"demo_id": demo_id, "type": version}},
                                       {"$project": {"_id": 0}}],
                          "as": "captures"}},
             {"$lookup": {"from": constants.Data.Structured.PUBLISHED_CONNECTIONS,
                          "pipeline": [{"$match": {"demo_id": demo_id, "type": version}},
                                       {"$project": {"_id": 0}}],
                          "as": "connections"}},
             {"$lookup": {"from": constants.Data.Structured.PUBLISHED_REDIRECTS,
                          "pipeline": [{"$match": {"demo_id": demo_id, "type": version}},
                                       {"$project": {"_id": 0}}],
                          "as": "redirects"}}
             ]))
        assert demo_details, "invalid demo id"
        return {
            "demo": {
                **{key: value for key, value in demo_details[0].items() if
                   key not in ["captures", "interactions", "steps", "menu", "menu_options"]},
                "captures": [{**capture,
                              "html_url": unstructured_data.Database.generate_cdn_url(capture["path_html"]),
                              "image_url": unstructured_data.Database.generate_cdn_url(capture["path_image"])}
                             for capture in demo_details[0].get("captures", [])],
                "connections": [_ for _ in demo_details[0].get("connections", [])],
                "redirects": [_ for _ in demo_details[0].get("redirects", [])]
            }
        }

    @staticmethod
    @logging.Funcs.log_func_call("creating published demo payload")
    def __create_published_demo_payload(account_id, demo_id, version):
        demo_details = list(structured_data.Database.aggregate(
            structured_data.Database.published_demos,
            [{"$match": {"demo_id": demo_id, "account_id": account_id, "type": version}},
             {"$project": {"_id": 0}},
             {"$lookup": {"from": constants.Data.Structured.PUBLISHED_STEPS,
                          "pipeline": [{"$match": {"demo_id": demo_id, "type": version}},
                                       {"$project": {"_id": 0}},
                                       {"$sort": {"position": 1}}],
                          "as": "steps"}},
             {"$lookup": {"from": constants.Data.Structured.PUBLISHED_CAPTURES,
                          "pipeline": [{"$match": {"demo_id": demo_id, "type": version}},
                                       {"$project": {"_id": 0}}],
                          "as": "captures"}},
             {"$lookup": {"from": constants.Data.Structured.PUBLISHED_INTERACTIONS,
                          "pipeline": [{"$match": {"demo_id": demo_id, "type": version}},
                                       {"$project": {"_id": 0}}],
                          "as": "interactions"}},
             {"$lookup": {"from": constants.Data.Structured.PUBLISHED_MENUS,
                          "pipeline": [{"$match": {"demo_id": demo_id, "type": version}},
                                       {"$project": {"_id": 0}}],
                          "as": "menu"}},
             {"$lookup": {"from": constants.Data.Structured.PUBLISHED_MENU_OPTIONS,
                          "pipeline": [{"$match": {"demo_id": demo_id, "type": version}},
                                       {"$project": {"_id": 0}},
                                       {"$sort": {"position": 1}}],
                          "as": "menu_options"}},
             {"$lookup": {"from": constants.Data.Structured.PUBLISHED_FLOWS,
                          "pipeline": [{"$match": {"demo_id": demo_id, "type": version}},
                                       {"$project": {"_id": 0}}],
                          "as": "flows"}},
             {"$lookup": {"from": constants.Data.Structured.PUBLISHED_VOICEOVERS,
                          "pipeline": [{"$match": {"demo_id": demo_id, "type": version}},
                                       {"$project": {"_id": 0}}],
                          "as": "voiceovers"}},
             {"$lookup": {"from": constants.Data.Structured.PUBLISHED_REDIRECTS,
                          "pipeline": [{"$match": {"demo_id": demo_id, "type": version}},
                                       {"$project": {"_id": 0}}],
                          "as": "redirects"}}
             ]))
        assert demo_details, "invalid demo id"
        interactions = [{**item, "edit_state": {**item.get("edit_state"),
            "video_url": unstructured_data.Database.generate_cdn_url(
                item.get("path_video")),
            "events_url": unstructured_data.Database.generate_cdn_url(
                item.get("path_events")),
            "image_url": unstructured_data.Database.generate_cdn_url(item.get("path_image"))}} for item in
            demo_details[0].get("interactions", [])]
        flows_data = Utils.Aggregator.add_steps_to_flows(
            demo_details[0].get("flows", []),
            Utils.Aggregator.group_steps_into_flows(demo_details[0].get("steps", []),
                                                    interactions))
        return {
            "demo": {
                **{key: value for key, value in demo_details[0].items() if
                   key not in ["captures", "interactions", "steps", "menu", "menu_options", "voiceovers"]},
                "captures": [{**capture,
                              "html_url": unstructured_data.Database.generate_cdn_url(capture["path_html"]),
                              "image_url": unstructured_data.Database.generate_cdn_url(capture["path_image"])}
                             for capture in demo_details[0].get("captures", [])],
                "flows": flows_data,
                "menu": (lambda records: {**records[0], "options": demo_details[0]["menu_options"]} if len(
                    records) > 0 else {})(demo_details[0]["menu"]),
                "voiceovers": [{**voiceover,
                                "audio_url": unstructured_data.Database.generate_cdn_url(voiceover["path_audio"])} for
                               voiceover in demo_details[0].get("voiceovers", [])],
                "redirects": [_ for _ in demo_details[0].get("redirects", [])]
            }
        }

    @staticmethod
    @logging.Funcs.log_func_call("fetching demos")
    def fetch(account_id, user_id):
        try:
            if request.args.get("list_only") == "true":
                results = list(structured_data.Database.find_bulk(structured_data.Database.demos,
                                                                  {"account_id": account_id},
                                                                  {"_id": 0, "title": 1, "demo_id": 1}).sort(
                    [("updated_at", -1)]))
            else:
                results = Utils.Aggregator.add_thumbnail_urls(search.Ops.fetch(structured_data.Database.demos,
                                                                               account_id=account_id,
                                                                               page_number=int(
                                                                                   request.args.get("page_number", 0)),
                                                                               date_start=request.args.get(
                                                                                   "date_start"),
                                                                               date_end=request.args.get("date_end"),
                                                                               text_query=request.args.get(
                                                                                   "text_query"),
                                                                               num_results=12))
            count = search.Ops.count(structured_data.Database.demos,
                                     account_id=account_id,
                                     date_start=request.args.get("date_start"),
                                     date_end=request.args.get("date_end"),
                                     text_query=request.args.get("text_query"))
        except AssertionError as ase:
            logging.Funcs.create_error_log(ase, account_id=account_id, user_id=user_id)
            return general.APIResponse.Error.get_response(ase, 401)
        except Exception as e:
            logging.Funcs.create_error_log(e, account_id=account_id, user_id=user_id)
            return general.APIResponse.Error.get_response(constants.APIResponse.Messages.BUSINESS_ERROR, 500)
        else:
            return make_response({
                constants.APIResponse.Fields.STATUS: constants.APIResponse.Statuses.SUCCESS,
                constants.APIResponse.Fields.MESSAGE: f"{len(results)} out of {count} demos retrieved",
                "results": results,
                "count": count
            }, 200)

    @staticmethod
    @logging.Funcs.log_func_call("updating demo")
    def update(account_id, user_id, demo_id):
        try:
            if Utils.Validator.is_stop_demo_requested():
                return Ops.stop(account_id=account_id, user_id=user_id, demo_id=demo_id)
            Utils.Validator.validate_update_demo_request()
            structured_data.Database.update_single(structured_data.Database.demos,
                                                   {"demo_id": demo_id}, {"$set": dict(request.json)})
            if request.json.get("enable_standard_public_link") is not None:
                structured_data.Database.update_single(structured_data.Database.published_demos,
                                                       {"demo_id": demo_id}, {"$set": {
                        "enable_standard_public_link": request.json.get("enable_standard_public_link")}})
        except AssertionError as ase:
            logging.Funcs.create_error_log(ase, account_id=account_id, user_id=user_id, component_id=demo_id)
            return general.APIResponse.Error.get_response(ase, 401)
        except Exception as e:
            logging.Funcs.create_error_log(e, account_id=account_id, user_id=user_id, component_id=demo_id)
            return general.APIResponse.Error.get_response(constants.APIResponse.Messages.BUSINESS_ERROR, 500)
        else:
            return make_response({
                constants.APIResponse.Fields.STATUS: constants.APIResponse.Statuses.SUCCESS,
                constants.APIResponse.Fields.MESSAGE: "demo updated"
            }, 200)

    @staticmethod
    @logging.Funcs.log_func_call("stop demo requested")
    def stop(account_id, user_id, demo_id):
        captures = structured_data.Database.find_bulk(structured_data.Database.captures, {"demo_id": demo_id},
                                                      {"_id": 0})
        for capture in captures:
            logging.Logger.log(constants.Logging.INFO, account=account_id, user=user_id,
                               component=capture["capture_id"], message="sending job for thumbnail creation")
            lambdas.LambdaExecutor.add_job(function_name=configs.AWS.THUMBNAIL_FUNCTION,
                                           message_body={
                                               "capture_id": capture["capture_id"],
                                               "image_path": capture["path_image"]
                                           })

        return make_response({
            constants.APIResponse.Fields.STATUS: constants.APIResponse.Statuses.SUCCESS,
            constants.APIResponse.Fields.MESSAGE: "demo recording stopped"
        }, 200)


class Utils:
    class Validator:
        @staticmethod
        def validate_update_demo_request():
            assert request.json, "request body missing"
            assert len(
                set(list(request.json.keys())) - {"title", "edit_state",
                                                  "master_capture_id",
                                                  "widget_demo_id",
                                                  "enable_standard_public_link",
                                                  "has_htmls", "has_images", "enable_mobile_preview",
                                                  "autoplay_voiceovers",
                                                  "theme_id",
                                                  "incompatible_screen_message",
                                                  "rtl"}) == 0, "invalid update field in request body"
            if request.json.get("master_capture_id"):
                assert structured_data.Database.find_single(structured_data.Database.captures,
                                                            {"capture_id": request.json.get("master_capture_id")},
                                                            {"capture_id": 1}), "capture_id does not exist"
            if request.json.get("enable_standard_public_link") is not None:
                assert isinstance(request.json.get("enable_standard_public_link"),
                                  bool), "invalid value for enable_standard_public_link"
            if request.json.get("has_htmls"):
                assert isinstance(request.json.get("has_htmls"), bool), "invalid value for has_htmls"
            if request.json.get("has_images"):
                assert isinstance(request.json.get("has_images"), bool), "invalid value for has_images"
            if "enable_mobile_preview" in request.json:
                assert isinstance(request.json.get("enable_mobile_preview"),
                                  bool), "invalid value for enable_mobile_preview"
            if "autoplay_voiceovers" in request.json:
                assert isinstance(request.json.get("autoplay_voiceovers"),
                                  bool), "invalid value for autoplay_voiceovers"
            if "rtl" in request.json:
                assert isinstance(request.json.get('rtl'), bool), "invalid value for rtl"
            if "incompatible_screen_message" in request.json:
                assert isinstance(request.json.get('incompatible_screen_message'),
                                  dict), "invalid format of incompatible_screen_message"
                assert len(set(list(request.json.get('incompatible_screen_message', {}).keys())) - {'title',
                                                                                                    'body'}) == 0, "invalid field in incompatible_screen_message"

        @staticmethod
        def is_stop_demo_requested():
            return request.args.get("action", None) == "stop"

    class Published:

        @staticmethod
        def get_version(demo_id):
            if request.args.get("type") == constants.Previews.PLAYGROUND:
                return constants.Previews.PLAYGROUND
            if request.args.get("screenwidth", None):
                demo_details = structured_data.Database.find_single(structured_data.Database.published_demos,
                                                                    {"demo_id": demo_id,
                                                                     "type": constants.Previews.MOBILE},
                                                                    {"_id": 0, "max_screen_width": 1})
                if demo_details and int(demo_details.get("max_screen_width", 0)) > int(request.args.get("screenwidth")):
                    return constants.Previews.MOBILE
            return constants.Previews.WEB

    class Aggregator:
        @staticmethod
        def group_steps_into_flows(steps, interactions):
            return {key: list(value) for key, value in
                    groupby(sorted(Utils.Aggregator.add_interactions_to_steps(steps, interactions),
                                   key=itemgetter("flow_id")), key=itemgetter("flow_id"))}

        @staticmethod
        def add_interactions_to_steps(steps, interactions):
            interactions = {item["step_id"]: [item] for item in interactions}
            return [{**step, "interactions": interactions.get(step["step_id"], [])} for step in steps]

        @staticmethod
        def add_steps_to_flows(flows_data, grouped_steps):
            return [{**flow, "steps": sorted(grouped_steps.get(flow["flow_id"], []), key=itemgetter("position"))} for
                    flow in flows_data]

        @staticmethod
        def add_thumbnail_urls(results):
            return [{**_, "thumbnail_link": unstructured_data.Database.generate_download_url(
                path=_["path_thumbnail"]) if "path_thumbnail" in _ else ""}
                    for _ in results]
