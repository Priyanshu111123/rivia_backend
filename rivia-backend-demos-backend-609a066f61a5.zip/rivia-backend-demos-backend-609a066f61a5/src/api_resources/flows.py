from src.funcs import general
from src.components import flows, logging, constants, structured_data
from flask import request, make_response


class Ops:

    @staticmethod
    @logging.Funcs.log_func_call("creating flow")
    def create(account_id, user_id):
        try:
            Utils.Validators.validate_create_request()
            structured_data.Database.update_bulk(structured_data.Database.flows,
                                                 {"demo_id": request.json.get("demo_id"),
                                                  "position": {"$gte": request.json.get("position")}},
                                                 {"$inc": {"position": 1}})
            flow = flows.FactoryFuncs.create(account_id=account_id, user_id=user_id,
                                             demo_id=request.json.get("demo_id"),
                                             position=request.json.get("position"),
                                             title=request.json.get("title"))
        except AssertionError as ase:
            logging.Funcs.create_error_log(ase, account_id=account_id, user_id=user_id,
                                           component_id=request.json.get("demo_id"))
            return general.APIResponse.Error.get_response(ase, 401)
        except Exception as e:
            logging.Funcs.create_error_log(e, account_id=account_id, user_id=user_id,
                                           component_id=request.json.get("demo_id"))
            return general.APIResponse.Error.get_response(constants.APIResponse.Messages.BUSINESS_ERROR, 500)
        else:
            return make_response({
                constants.APIResponse.Fields.STATUS: constants.APIResponse.Statuses.SUCCESS,
                constants.APIResponse.Fields.MESSAGE: "flow created",
                "flow": {**flow.as_json(), "steps": []}
            }, 200)

    @staticmethod
    @logging.Funcs.log_func_call("updating flow")
    def update(account_id, user_id, flow_id):
        try:
            Utils.Validators.validate_update_request()
            flow_details = structured_data.Database.find_single(structured_data.Database.flows, {"flow_id": flow_id},
                                                                {"_id": 0})
            assert flow_details, "invalid flow id"
            if request.json.get("position") is not None:
                assert 0 <= request.json.get("position") < structured_data.Database.count(
                    structured_data.Database.flows, {"demo_id": flow_details["demo_id"]}), "invalid step position"
                structured_data.Database.update_bulk(structured_data.Database.flows,
                                                     {"demo_id": flow_details["demo_id"],
                                                      "position": {"$gt": flow_details["position"]}},
                                                     {"$inc": {"position": -1}})
                structured_data.Database.update_bulk(structured_data.Database.flows,
                                                     {"demo_id": flow_details["demo_id"],
                                                      "position": {"$gte": request.json.get("position")}},
                                                     {"$inc": {"position": 1}})
            structured_data.Database.update_single(structured_data.Database.flows,
                                                   {"flow_id": flow_id}, {"$set": {**request.json}})
        except AssertionError as ase:
            logging.Funcs.create_error_log(ase, account_id=account_id, user_id=user_id, component_id=flow_id)
            return general.APIResponse.Error.get_response(ase, 401)
        except Exception as e:
            logging.Funcs.create_error_log(e, account_id=account_id, user_id=user_id, component_id=flow_id)
            return general.APIResponse.Error.get_response(constants.APIResponse.Messages.BUSINESS_ERROR, 500)
        else:
            return make_response({
                constants.APIResponse.Fields.STATUS: constants.APIResponse.Statuses.SUCCESS,
                constants.APIResponse.Fields.MESSAGE: "flow updated"
            }, 200)

    @staticmethod
    @logging.Funcs.log_func_call("deleting flow")
    def delete(account_id, user_id, flow_id):
        try:
            flow_details = structured_data.Database.find_single(structured_data.Database.flows, {"flow_id": flow_id},
                                                                {"_id": 0})
            assert flow_details, "invalid flow id"
            flow_usage = structured_data.Database.find_single(structured_data.Database.menu_options,
                                                              {"flow_id": flow_id}, {"_id": 0})
            assert not flow_usage, "Flow exists in menu. Cannot be deleted."
            menu_usage = structured_data.Database.find_single(structured_data.Database.menus,
                                                              {"demo_id": flow_details["demo_id"]}, {"_id": 0})
            if menu_usage:
                assert menu_usage.get("edit_state", {}).get("start_workflow") != flow_id, "Flow in use in menu"
                assert menu_usage.get("edit_state", {}).get("end_workflow") != flow_id, "Flow in use in menu"

            assert not flow_details.get("is_default"), "default flow cannot be deleted"
            structured_data.Database.delete_single(structured_data.Database.flows, {"flow_id": flow_id})
            step_details = structured_data.Database.find_bulk(structured_data.Database.steps, {"flow_id": flow_id},
                                                              {"step_id": 1})
            structured_data.Database.delete_many(structured_data.Database.steps, {"flow_id": flow_id})
            structured_data.Database.delete_many(structured_data.Database.interactions,
                                                 {"step_id": {"$in": [step.get("step_id") for step in step_details]}})
        except AssertionError as ase:
            logging.Funcs.create_error_log(ase, account_id=account_id, user_id=user_id, component_id=flow_id)
            return general.APIResponse.Error.get_response(ase, 401)
        except Exception as e:
            logging.Funcs.create_error_log(e, account_id=account_id, user_id=user_id, component_id=flow_id)
            return general.APIResponse.Error.get_response(constants.APIResponse.Messages.BUSINESS_ERROR, 500)
        else:
            return make_response({
                constants.APIResponse.Fields.STATUS: constants.APIResponse.Statuses.SUCCESS,
                constants.APIResponse.Fields.MESSAGE: "flow deleted"
            }, 200)


class Utils:
    class Validators:

        @staticmethod
        def validate_create_request():
            assert request.json.get("demo_id"), "demo_id missing from the request body"
            assert request.json.get("title"), "title missing from the request body"
            assert len(request.json.get("title")) > 0, "invalid title passed in the request body"
            assert request.json.get("position") is not None, "position missing from the request body"
            assert 0 <= request.json.get("position") <= structured_data.Database.count(
                structured_data.Database.flows, {"demo_id": request.json.get("demo_id")}), "invalid flow position"

        @staticmethod
        def validate_update_request():
            assert len(
                set(list(request.json.keys())) - {"title", "position"}) == 0, "invalid update field in request body"
