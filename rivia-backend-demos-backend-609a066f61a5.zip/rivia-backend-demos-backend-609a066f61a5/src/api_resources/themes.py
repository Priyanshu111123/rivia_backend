from src.funcs import general
from src.components import logging, constants, themes, structured_data
from flask import make_response, request


class Ops:

    @staticmethod
    @logging.Funcs.log_func_call("creating theme")
    def create(account_id, user_id):
        try:
            Utils.Validator.create()
            theme = themes.FactoryFuncs.create(account_id=account_id, user_id=user_id, name=request.json.get('name'),
                                               edit_state=request.json.get('edit_state'))
        except AssertionError as ase:
            logging.Funcs.create_error_log(ase, account_id=account_id, user_id=user_id)
            return general.APIResponse.Error.get_response(ase, 401)
        except Exception as e:
            logging.Funcs.create_error_log(e, account_id=account_id, user_id=user_id)
            return general.APIResponse.Error.get_response(constants.APIResponse.Messages.BUSINESS_ERROR, 500)
        else:
            return make_response({
                constants.APIResponse.Fields.STATUS: constants.APIResponse.Statuses.SUCCESS,
                constants.APIResponse.Fields.MESSAGE: "theme created",
                "theme": theme.as_json()
            }, 200)

    @staticmethod
    @logging.Funcs.log_func_call("fetching single theme for an account")
    def fetch(account_id, user_id, theme_id):
        try:
            theme_details = structured_data.Database.find_single(structured_data.Database.themes,
                                                                 {"theme_id": theme_id},
                                                                 {"_id": 0})
            assert theme_details, "invalid theme_id"
        except AssertionError as ase:
            logging.Funcs.create_error_log(ase, account_id=account_id, user_id=user_id, component_id=theme_id)
            return general.APIResponse.Error.get_response(ase, 401)
        except Exception as e:
            logging.Funcs.create_error_log(e, account_id=account_id, user_id=user_id, component_id=theme_id)
            return general.APIResponse.Error.get_response(constants.APIResponse.Messages.BUSINESS_ERROR, 500)
        else:
            return make_response({
                constants.APIResponse.Fields.STATUS: constants.APIResponse.Statuses.SUCCESS,
                constants.APIResponse.Fields.MESSAGE: f"theme fetched",
                "theme": theme_details
            }, 200)

    @staticmethod
    @logging.Funcs.log_func_call("fetching themes for an account")
    def fetch_all(account_id, user_id):
        try:
            theme_details = list(
                structured_data.Database.find_bulk(structured_data.Database.themes,
                                                   {"account_id": {"$in": [None, account_id]}},
                                                   {"_id": 0, "edit_state": 0}))
        except AssertionError as ase:
            logging.Funcs.create_error_log(ase, account_id=account_id, user_id=user_id)
            return general.APIResponse.Error.get_response(ase, 401)
        except Exception as e:
            logging.Funcs.create_error_log(e, account_id=account_id, user_id=user_id)
            return general.APIResponse.Error.get_response(constants.APIResponse.Messages.BUSINESS_ERROR, 500)
        else:
            return make_response({
                constants.APIResponse.Fields.STATUS: constants.APIResponse.Statuses.SUCCESS,
                constants.APIResponse.Fields.MESSAGE: f"{len(theme_details)} themes fetched",
                "themes": theme_details
            }, 200)

    @staticmethod
    @logging.Funcs.log_func_call("updating theme")
    def update(account_id, user_id, theme_id):
        try:
            Utils.Validator.update()
            structured_data.Database.update_single(structured_data.Database.themes,
                                                   {"theme_id": theme_id},
                                                   {"$set": dict(request.json)})
            theme = structured_data.Database.find_single(structured_data.Database.themes,
                                                         {"theme_id": theme_id}, {"_id": 0})
        except AssertionError as ase:
            logging.Funcs.create_error_log(ase, account_id=account_id, user_id=user_id, component_id=theme_id)
            return general.APIResponse.Error.get_response(ase, 401)
        except Exception as e:
            logging.Funcs.create_error_log(e, account_id=account_id, user_id=user_id, component_id=theme_id)
            return general.APIResponse.Error.get_response(constants.APIResponse.Messages.BUSINESS_ERROR, 500)
        else:
            return make_response({
                constants.APIResponse.Fields.STATUS: constants.APIResponse.Statuses.SUCCESS,
                constants.APIResponse.Fields.MESSAGE: "updated",
                "theme": {
                    **theme
                }
            }, 200)

    @staticmethod
    @logging.Funcs.log_func_call("deleting theme")
    def delete(account_id, user_id, theme_id):
        try:
            structured_data.Database.delete_single(structured_data.Database.themes,
                                                   {"theme_id": theme_id})
        except Exception as e:
            logging.Funcs.create_error_log(e, account_id=account_id, user_id=user_id, component_id=theme_id)
            return general.APIResponse.Error.get_response(constants.APIResponse.Messages.BUSINESS_ERROR, 500)
        else:
            return make_response({
                constants.APIResponse.Fields.STATUS: constants.APIResponse.Statuses.SUCCESS,
                constants.APIResponse.Fields.MESSAGE: "deleted"
            }, 200)


class Utils:
    class Validator:

        @staticmethod
        def create():
            assert request.json.get('edit_state'), 'edit_state missing in the request body'
            assert request.json.get('name'), 'name missing in the request body'

        @staticmethod
        def update():
            assert len(
                set(list(request.json.keys())) - {"name", "edit_state"}) == 0, "invalid update field in request body"
