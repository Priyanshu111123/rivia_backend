from src.components import logging, accounts, authentication, users, constants, structured_data
from flask import request, make_response
from src.funcs import general


class Ops:

    @staticmethod
    @logging.Funcs.log_func_call("sign up via oauth")
    def oauth_sign_in():
        try:
            Utils.Validate.validate_oauth_sign_in()
            if not general.Components.Users.get_details_by_email(email=request.json.get("email")):
                user_id = users.FactoryFuncs.create_user(email=request.json.get("email"),
                                                         user_id=request.json.get("user_id"),
                                                         account_id=accounts.FactoryFuncs.create_account(
                                                             name=request.json.get("account_name",
                                                                                   request.json.get("email")),
                                                             plan=request.json.get("plan",
                                                                                   constants.Accounts.Plans.BASIC)),
                                                         first_name=request.json.get("first_name"),
                                                         last_name="",
                                                         last_logged_in_at=general.Time.get_current_time())
                # slack alert for sso sign up comes here
            session_cookie = authentication.Authenticator.generate_cookie(request.json.get("user_id"))
        except AssertionError as ase:
            logging.Funcs.create_error_log(ase, user_id=request.json.get("email"))
            return general.APIResponse.Error.get_response(ase, 401)
        except Exception as e:
            logging.Funcs.create_error_log(e, user_id=request.json.get("email"))
            return general.APIResponse.Error.get_response(constants.APIResponse.Messages.BUSINESS_ERROR, 500)
        else:
            structured_data.Database.update_single(structured_data.Database.users,
                                                   {"user_id": request.json.get("user_id")},
                                                   {"$set": {"last_logged_in_at": general.Time.get_current_time()}})
            return general.APIResponse.Cookies.add_cookie_to_response(
                session_cookie=session_cookie,
                response=make_response({
                    constants.APIResponse.Fields.STATUS: constants.APIResponse.Statuses.SUCCESS,
                    constants.APIResponse.Fields.MESSAGE: "successfully signed in",
                    "user": {
                        **general.Components.Users.get_details_by_user_id(user_id=request.json.get("user_id")),
                        **general.Components.Accounts.get_details_by_account_id(
                            general.Components.Users.get_details_by_user_id(user_id=request.json.get("user_id"))[
                                "account_id"]),
                        "signature": general.Components.Users.generate_signature(request.json.get("user_id"))
                    }
                }, 200),
                cookie_name="session")

    @staticmethod
    @logging.Funcs.log_func_call("sign up via email")
    def sign_up():
        try:
            Utils.Validate.validate_sign_up_request()
            sign_up_resp = authentication.Authenticator.sign_up(email=request.json.get("email"),
                                                                password=request.json.get("password"))
            assert sign_up_resp.status_code == 200, sign_up_resp.text
            user_id = users.FactoryFuncs.create_user(
                email=request.json.get("email"), user_id=sign_up_resp.json().get("localId"),
                account_id=(lambda value: value if value else accounts.FactoryFuncs.create_account(
                    request.json.get("account_name", request.json.get("email")),
                    plan=request.json.get("plan", constants.Accounts.Plans.BASIC)))(request.json.get("account_id")),
                first_name=request.json.get("first_name"),
                last_name=request.json.get("last_name", ""),
                last_logged_in_at=general.Time.get_current_time())
            if request.json.get("auto_verify_email"):
                authentication.Authenticator.verify_email(user_id=user_id)
            else:
                send_email_resp = authentication.Authenticator.send_verification_email(
                    id_token=sign_up_resp.json().get("idToken"))
                assert send_email_resp.status_code == 200, send_email_resp.text
            # slack alert for email sign up comes here
        except AssertionError as ase:
            logging.Funcs.create_error_log(ase, user_id=request.json.get("email"))
            return general.APIResponse.Error.get_response(ase, 401)
        except Exception as e:
            logging.Funcs.create_error_log(e, user_id=request.json.get("email"))
            return general.APIResponse.Error.get_response(constants.APIResponse.Messages.BUSINESS_ERROR, 500)
        else:
            return make_response({
                constants.APIResponse.Fields.STATUS: constants.APIResponse.Statuses.SUCCESS,
                constants.APIResponse.Fields.MESSAGE: "user created successfully"
            }, 200)

    @staticmethod
    @logging.Funcs.log_func_call("create user via invite")
    def invite_user(account_id, user_id):
        try:
            Utils.Validate.validate_invite_request()
            sign_up_resp = authentication.Authenticator.sign_up(email=request.json.get("email"),
                                                                password=general.Identifiers.generate())
            assert sign_up_resp.status_code == 200, sign_up_resp.text
            user_id = users.FactoryFuncs.create_user(
                email=request.json.get("email"), user_id=sign_up_resp.json().get("localId"),
                account_id=account_id,
                first_name=request.json.get("first_name"),
                last_name=request.json.get("last_name", ""),
                user_type=constants.Users.Types.MEMBER)
            authentication.Authenticator.sign_assist(email=request.json.get("email"))
            # slack alert for email sign up comes here
        except AssertionError as ase:
            logging.Funcs.create_error_log(ase, user_id=user_id)
            return general.APIResponse.Error.get_response(ase, 401)
        except Exception as e:
            logging.Funcs.create_error_log(e, user_id=user_id)
            return general.APIResponse.Error.get_response(constants.APIResponse.Messages.BUSINESS_ERROR, 500)
        else:
            return make_response({
                constants.APIResponse.Fields.STATUS: constants.APIResponse.Statuses.SUCCESS,
                constants.APIResponse.Fields.MESSAGE: "user created successfully",
                "user": structured_data.Database.find_single(structured_data.Database.users,
                                                             {"email": request.json.get("email")}, {"_id": 0})
            }, 200)

    @staticmethod
    @logging.Funcs.log_func_call("sign in")
    def sign_in():
        try:
            Utils.Validate.validate_sign_in_request()
            sign_in_resp = authentication.Authenticator.sign_in(email=request.json.get("email"),
                                                                password=request.json.get("password"))
            assert sign_in_resp.status_code == 200, "invalid credentials"
            assert authentication.Authenticator.is_email_verified(
                user_id=sign_in_resp.json()["localId"]), "please verify the email address to login. " \
                                                         "check the spam folder if you cannot find the verification email"
            session_cookie = authentication.Authenticator.generate_cookie(sign_in_resp.json()["idToken"])
        except AssertionError as ase:
            logging.Funcs.create_error_log(ase, user_id=request.json.get("email"))
            return general.APIResponse.Error.get_response(ase, 401)
        except Exception as e:
            logging.Funcs.create_error_log(e, user_id=request.json.get("email"))
            return general.APIResponse.Error.get_response(constants.APIResponse.Messages.BUSINESS_ERROR, 500)
        else:
            structured_data.Database.update_single(structured_data.Database.users,
                                                   {"user_id": sign_in_resp.json().get("localId")},
                                                   {"$set": {"last_logged_in_at": general.Time.get_current_time()}})
            return general.APIResponse.Cookies.add_cookie_to_response(
                session_cookie=session_cookie,
                response=make_response({
                    constants.APIResponse.Fields.STATUS: constants.APIResponse.Statuses.SUCCESS,
                    constants.APIResponse.Fields.MESSAGE: "successfully signed in",
                    "user": {
                        **general.Components.Users.get_details_by_user_id(user_id=sign_in_resp.json().get("localId")),
                        **general.Components.Accounts.get_details_by_account_id(
                            general.Components.Users.get_details_by_user_id(user_id=sign_in_resp.json().get("localId"))[
                                "account_id"]),
                        "signature": general.Components.Users.generate_signature(
                            user_id=sign_in_resp.json().get("localId"))
                    }
                }, 200),
                cookie_name="session")

    @staticmethod
    @logging.Funcs.log_func_call("sign in with assist")
    def sign_assist():
        try:
            Utils.Validate.validate_sign_assist()
            authentication.Authenticator.sign_assist(email=request.json.get("email"))
        except AssertionError as ase:
            logging.Funcs.create_error_log(ase, user_id=request.json.get("email"))
            return general.APIResponse.Error.get_response(ase, 401)
        except Exception as e:
            logging.Funcs.create_error_log(e, user_id=request.json.get("email"))
            return general.APIResponse.Error.get_response(constants.APIResponse.Messages.BUSINESS_ERROR, 500)
        else:
            return make_response({
                constants.APIResponse.Fields.STATUS: constants.APIResponse.Statuses.SUCCESS,
                constants.APIResponse.Fields.MESSAGE: "password reset email sent"
            }, 200)

    @staticmethod
    @logging.Funcs.log_func_call("sign out")
    def sign_out(user_id, account_id):
        try:
            Utils.Validate.validate_sign_out()
            authentication.Authenticator.sign_out(request.cookies.get("session"))
        except AssertionError as ase:
            logging.Funcs.create_error_log(ase)
            return general.APIResponse.Error.get_response(ase, 401)
        except Exception as e:
            logging.Funcs.create_error_log(e)
            return general.APIResponse.Error.get_response(constants.APIResponse.Messages.BUSINESS_ERROR, 500)
        else:
            return general.APIResponse.Cookies.expire_session_cookie(make_response({
                constants.APIResponse.Fields.STATUS: constants.APIResponse.Statuses.SUCCESS,
                constants.APIResponse.Fields.MESSAGE: f"successfully signed out"
            }, 200), cookie_name="session")

    @staticmethod
    @logging.Funcs.log_func_call("delete user")
    def delete(account_id, user_id, rivia_user_id):
        try:
            user_details = structured_data.Database.find_single(structured_data.Database.users,
                                                                {"user_id": rivia_user_id, "account_id": account_id},
                                                                {"_id": 0})
            assert user_details and user_details.get("account_id") == account_id, "Invalid User"
            assert user_details.get("user_type") == constants.Users.Types.MEMBER, "Admin user cannot be deleted"
            authentication.Authenticator.delete_user(user_id=user_details["user_id"])
            structured_data.Database.delete_single(structured_data.Database.users,
                                                   {"user_id": user_details["user_id"]})
        except AssertionError as ase:
            logging.Funcs.create_error_log(ase, user_id=user_id)
            return general.APIResponse.Error.get_response(ase, 401)
        except Exception as e:
            logging.Funcs.create_error_log(e, user_id=user_id)
            return general.APIResponse.Error.get_response(constants.APIResponse.Messages.BUSINESS_ERROR, 500)
        else:
            return make_response({
                constants.APIResponse.Fields.STATUS: constants.APIResponse.Statuses.SUCCESS,
                constants.APIResponse.Fields.MESSAGE: "user deleted"
            }, 200)

    @staticmethod
    @logging.Funcs.log_func_call("fetch user")
    def fetch(account_id, user_id, rivia_user_id):
        try:
            user_details = structured_data.Database.find_single(structured_data.Database.users,
                                                                {"user_id": rivia_user_id, "account_id": account_id},
                                                                {"_id": 0})
        except AssertionError as ase:
            logging.Funcs.create_error_log(ase, user_id=user_id)
            return general.APIResponse.Error.get_response(ase, 401)
        except Exception as e:
            logging.Funcs.create_error_log(e, user_id=user_id)
            return general.APIResponse.Error.get_response(constants.APIResponse.Messages.BUSINESS_ERROR, 500)
        else:
            return make_response({
                constants.APIResponse.Fields.STATUS: constants.APIResponse.Statuses.SUCCESS,
                constants.APIResponse.Fields.MESSAGE: "fetched user details",
                "user": user_details
            }, 200)

    @staticmethod
    @logging.Funcs.log_func_call("fetch account details")
    def fetch_account(account_id, user_id, rivia_account_id):
        try:
            account_details = structured_data.Database.find_single(structured_data.Database.accounts,
                                                                   {"account_id": account_id},
                                                                   {"_id": 0})
        except AssertionError as ase:
            logging.Funcs.create_error_log(ase, user_id=user_id)
            return general.APIResponse.Error.get_response(ase, 401)
        except Exception as e:
            logging.Funcs.create_error_log(e, user_id=user_id)
            return general.APIResponse.Error.get_response(constants.APIResponse.Messages.BUSINESS_ERROR, 500)
        else:
            return make_response({
                constants.APIResponse.Fields.STATUS: constants.APIResponse.Statuses.SUCCESS,
                constants.APIResponse.Fields.MESSAGE: "fetched account details",
                "account": account_details
            }, 200)

    @staticmethod
    @logging.Funcs.log_func_call("fetch all users within account")
    def fetch_all(account_id, user_id):
        try:
            results = list(structured_data.Database.find_bulk(structured_data.Database.users,
                                                              {"account_id": account_id}, {"_id": 0}))
        except AssertionError as ase:
            logging.Funcs.create_error_log(ase, user_id=user_id)
            return general.APIResponse.Error.get_response(ase, 401)
        except Exception as e:
            logging.Funcs.create_error_log(e, user_id=user_id)
            return general.APIResponse.Error.get_response(constants.APIResponse.Messages.BUSINESS_ERROR, 500)
        else:
            return make_response({
                constants.APIResponse.Fields.STATUS: constants.APIResponse.Statuses.SUCCESS,
                constants.APIResponse.Fields.MESSAGE: f"fetched {len(results)} users",
                "users": results
            }, 200)


class Utils:
    class Validate:

        @staticmethod
        def validate_sign_up_request():
            assert request.json.get("email"), "email missing in request body"
            assert request.json.get("password"), "password missing in request body"
            assert request.json.get("first_name"), "first_name missing in request body"
            assert general.Components.Users.get_details_by_email(
                request.json.get("email")) is None, "User already exists"

        @staticmethod
        def validate_invite_request():
            assert request.json.get("email"), "email missing in request body"
            assert request.json.get("first_name"), "first_name missing in request body"
            assert general.Components.Users.get_details_by_email(
                request.json.get("email")) is None, "User already exists"

        @staticmethod
        def validate_sign_in_request():
            assert request.json.get("email"), "email missing in requests body"
            assert request.json.get("password"), "password missing in request body"
            assert general.Components.Users.get_details_by_email(
                request.json.get("email")), "Invalid credentials"

        @staticmethod
        def validate_sign_assist():
            assert request.json.get("email"), "email missing in request body"

        @staticmethod
        def validate_sign_out():
            assert request.cookies.get("session"), "missing authentication cookie"

        @staticmethod
        def validate_oauth_sign_in():
            assert request.json.get("token"), "missing token in request body"
            assert request.json.get("user_id"), "missing user_id in request body"
            assert request.json.get("first_name"), "missing first_name in request body"
            assert request.json.get("email"), "missing email in request body"
