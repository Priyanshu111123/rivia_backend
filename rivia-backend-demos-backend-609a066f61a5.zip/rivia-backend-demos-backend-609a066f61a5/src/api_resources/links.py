from src.funcs import general
from flask import request, make_response
from src.components import logging, constants, structured_data
from collections import namedtuple
import re

link = namedtuple("personalised_demo", ["link_id", "account_id", "user_id", "demo_id", "name",
                                        "created_at", "updated_at",
                                        "is_password_protected", "password"])


class Ops:

    @staticmethod
    @logging.Funcs.log_func_call("creating link")
    def create(account_id, user_id):
        try:
            Utils.RequestValidator.validate_create()
            link_obj = link(general.Identifiers.generate_link_id(),
                            account_id,
                            user_id,
                            request.json.get("demo_id"),
                            request.json.get("name"),
                            general.Time.get_current_time(),
                            general.Time.get_current_time(),
                            request.json.get("is_password_protected", False),
                            request.json.get("password", None))
            structured_data.Database.add_single(structured_data.Database.links,
                                                link_obj._asdict())
        except AssertionError as ase:
            logging.Funcs.create_error_log(ase, account_id=account_id, user_id=user_id,
                                           component_id=request.json.get("demo_id"))
            return general.APIResponse.Error.get_response(ase, 401)
        except Exception as e:
            logging.Funcs.create_error_log(e, account_id=account_id, user_id=user_id,
                                           component_id=request.json.get("demo_id"))
            return general.APIResponse.Error.get_response(constants.APIResponse.Messages.BUSINESS_ERROR, 500)
        else:
            return make_response({constants.APIResponse.Fields.STATUS: constants.APIResponse.Statuses.SUCCESS,
                                  constants.APIResponse.Fields.MESSAGE: "link created"},
                                 200)

    @staticmethod
    @logging.Funcs.log_func_call("getting link")
    def get(account_id, user_id, link_id):
        try:
            link_obj = structured_data.Database.find_single(structured_data.Database.links,
                                                            {"link_id": link_id}, {"_id": 0})
            assert link_obj, "link not found"
            return make_response({constants.APIResponse.Fields.STATUS: constants.APIResponse.Statuses.SUCCESS,
                                  constants.APIResponse.Fields.MESSAGE: "link found",
                                  "link": link_obj},
                                 200)
        except AssertionError as ase:
            logging.Funcs.create_error_log(ase, account_id=account_id, user_id=user_id, component_id=link_id)
            return general.APIResponse.Error.get_response(ase, 401)
        except Exception as e:
            logging.Funcs.create_error_log(e, account_id=account_id, user_id=user_id, component_id=link_id)
            return general.APIResponse.Error.get_response(constants.APIResponse.Messages.BUSINESS_ERROR, 500)

    @staticmethod
    @logging.Funcs.log_func_call("getting all links")
    def get_all(account_id, user_id):
        try:
            Utils.RequestValidator.validate_get_all()
            links = list(structured_data.Database.find_bulk(structured_data.Database.links,
                                                            {"demo_id": request.args.get("demo_id")}, {"_id": 0}).sort(
                "created_at", -1))
            return make_response({constants.APIResponse.Fields.STATUS: constants.APIResponse.Statuses.SUCCESS,
                                  constants.APIResponse.Fields.MESSAGE: f" {len(links)} links found",
                                  "links": links},
                                 200)
        except AssertionError as ase:
            logging.Funcs.create_error_log(ase, account_id=account_id, user_id=user_id,
                                           component_id=request.args.get("demo_id"))
            return general.APIResponse.Error.get_response(ase, 401)
        except Exception as e:
            logging.Funcs.create_error_log(e, account_id=account_id, user_id=user_id,
                                           component_id=request.args.get("demo_id"))
            return general.APIResponse.Error.get_response(constants.APIResponse.Messages.BUSINESS_ERROR, 500)

    @staticmethod
    @logging.Funcs.log_func_call("deleting link")
    def delete(account_id, user_id, link_id):
        try:
            structured_data.Database.delete_single(structured_data.Database.links, {"link_id": link_id})
        except AssertionError as ase:
            logging.Funcs.create_error_log(ase, account_id=account_id, user_id=user_id, component_id=link_id)
            return general.APIResponse.Error.get_response(ase, 401)
        except Exception as e:
            logging.Funcs.create_error_log(e, account_id=account_id, user_id=user_id, component_id=link_id)
            return general.APIResponse.Error.get_response(constants.APIResponse.Messages.BUSINESS_ERROR, 500)
        else:
            return make_response({constants.APIResponse.Fields.STATUS: constants.APIResponse.Statuses.SUCCESS,
                                  constants.APIResponse.Fields.MESSAGE: "link deleted"},
                                 200)

    @staticmethod
    @logging.Funcs.log_func_call("updating link")
    def update(account_id, user_id, link_id):
        try:
            Utils.RequestValidator.validate_update()
            link_obj = structured_data.Database.find_single(structured_data.Database.links,
                                                            {"link_id": link_id}, {"_id": 0})
            assert link_obj, "link not found"
            structured_data.Database.update_single(structured_data.Database.links, {"link_id": link_id},
                                                   {"$set": {"updated_at": general.Time.get_current_time(),
                                                             **request.json}})
        except AssertionError as ase:
            logging.Funcs.create_error_log(ase, account_id=account_id, user_id=user_id, component_id=link_id)
            return general.APIResponse.Error.get_response(ase, 401)
        except Exception as e:
            logging.Funcs.create_error_log(e, account_id=account_id, user_id=user_id, component_id=link_id)
            return general.APIResponse.Error.get_response(constants.APIResponse.Messages.BUSINESS_ERROR, 500)
        else:
            return make_response({constants.APIResponse.Fields.STATUS: constants.APIResponse.Statuses.SUCCESS,
                                  constants.APIResponse.Fields.MESSAGE: "link updated"},
                                 200)


class Utils:
    class RequestValidator:

        @staticmethod
        def validate_create():
            assert "demo_id" in request.json, "demo_id is required"
            assert "name" in request.json, "name is required"
            Utils.RequestValidator.__validated_password()
            if request.json.get("is_password_protected"):
                assert request.json.get("password"), "password is required if is_password_protected is True"
            if "password" in request.json:
                assert request.json.get(
                    "is_password_protected"), "is_password_protected is required if password is present"

        @staticmethod
        def validate_get_all():
            assert "demo_id" in request.args, "demo_id is required"

        @staticmethod
        def validate_update():
            assert len(
                set(list(request.json.keys())) - {"name", "is_password_protected",
                                                  "password"}) == 0, "invalid update field in request body"
            Utils.RequestValidator.__validated_password()
            if request.json.get("is_password_protected") and "password" not in request.json:
                link_details = structured_data.Database.find_single(structured_data.Database.links,
                                                                    {"link_id": request.json.get("link_id")},
                                                                    {"_id": 0})
                assert link_details, "link not found"
                assert link_details.get("password"), "password is required if is_password_protected is True"

        @staticmethod
        def __validated_password():
            if "is_password_protected" in request.json:
                assert isinstance(request.json.get("is_password_protected"),
                                  bool), "is_password_protected should be a boolean"
            if "password" in request.json:
                assert isinstance(request.json.get("password"), str), "password should be a string"
                assert len(request.json.get("password")) >= 4, "password should be at least 4 characters"
                pattern = re.compile('^[a-zA-Z0-9!@#$%^&*()-_=+[\]{}|;:,.<>?/`~]*$')
                assert pattern.fullmatch(request.json.get("password")), "password contains an invalid character"
