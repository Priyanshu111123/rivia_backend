from src.funcs import general
from src.components import logging, captures, constants, unstructured_data, configs, structured_data, lambdas, cdn, \
    steps
from flask import request, make_response


class Ops:

    @staticmethod
    @logging.Funcs.log_func_call("fetch captures for a demo")
    def fetch_all(account_id, user_id):
        try:
            assert request.args.get("demo_id"), "demo_id missing in the request arguments"
            capture_details = list(structured_data.Database.find_bulk(structured_data.Database.captures,
                                                                      Ops.__create_payload_for_capture_query(),
                                                                      {"_id": 0, "capture_id": 1, "demo_id": 1,
                                                                       "title": 1, "position": 1, "capture_type": 1,
                                                                       "capture_hash": 1}))
        except AssertionError as ase:
            logging.Funcs.create_error_log(ase, account_id=account_id, user_id=user_id,
                                           component_id=request.args.get("demo_id"))
            return general.APIResponse.Error.get_response(ase, 401)
        except Exception as e:
            logging.Funcs.create_error_log(e, account_id=account_id, user_id=user_id,
                                           component_id=request.args.get("demo_id"))
            return general.APIResponse.Error.get_response(constants.APIResponse.Messages.BUSINESS_ERROR, 500)
        else:
            return make_response({
                constants.APIResponse.Fields.STATUS: constants.APIResponse.Statuses.SUCCESS,
                constants.APIResponse.Fields.MESSAGE: f"{len(capture_details)} captures fetched",
                "captures": capture_details
            })

    @staticmethod
    def __create_payload_for_capture_query():
        query = {"demo_id": request.args.get("demo_id")}
        if request.args.get("capture_hash"):
            query = {**query, "capture_hash": request.args.get("capture_hash")}
        return query

    @staticmethod
    @logging.Funcs.log_func_call("creating capture")
    def create(account_id, user_id):
        try:
            Utils.Validator.validate_create_capture_request()
            capture = captures.FactoryFuncs.create(
                account_id=account_id, user_id=user_id,
                demo_id=request.json.get("demo_id"),
                title=request.json.get("title", None),
                capture_type=constants.Captures.CaptureTypes.IMAGE if request.args.get(
                    "type") == "image" else constants.Captures.CaptureTypes.HTML,
                position=structured_data.Database.count(structured_data.Database.captures,
                                                        {"demo_id": request.json.get("demo_id")}),
                screen_interaction=request.json.get("screen_interaction"),
                capture_hash=request.json.get("capture_hash"))
            if request.args.get("create_step") == "true":
                flow_details = structured_data.Database.find_single(structured_data.Database.flows,
                                                                    {"demo_id": request.json.get("demo_id")},
                                                                    {"_id": 0})
                assert flow_details, "flow not found for the demo"
                step_position = structured_data.Database.count(structured_data.Database.steps,
                                                               {"demo_id": request.json.get("demo_id"),
                                                                "flow_id": flow_details["flow_id"]})
                structured_data.Database.update_bulk(structured_data.Database.steps,
                                                     {"demo_id": request.json.get("demo_id"),
                                                      "flow_id": flow_details["flow_id"],
                                                      "position": {"$gte": step_position}},
                                                     {"$inc": {"position": 1}})
                step = steps.FactoryFuncs.create(account_id=account_id, user_id=user_id,
                                                 demo_id=request.json.get("demo_id"),
                                                 flow_id=request.json.get("flow_id"),
                                                 position=step_position,
                                                 capture_id=request.json.get("capture_id"))
        except AssertionError as ase:
            logging.Funcs.create_error_log(ase, account_id=account_id, user_id=user_id,
                                           component_id=request.json.get("demo_id"))
            return general.APIResponse.Error.get_response(ase, 401)
        except Exception as e:
            logging.Funcs.create_error_log(e, account_id=account_id, user_id=user_id,
                                           component_id=request.json.get("demo_id"))
            return general.APIResponse.Error.get_response(constants.APIResponse.Messages.BUSINESS_ERROR, 500)
        else:
            return make_response({
                constants.APIResponse.Fields.STATUS: constants.APIResponse.Statuses.SUCCESS,
                constants.APIResponse.Fields.MESSAGE: "capture created",
                "capture": {
                    **capture.as_json(),
                    "upload_html_url": unstructured_data.Database.generate_upload_url(
                        capture.path_html, bucket_name=configs.AWS.S3_BUCKET),
                    "upload_image_url": unstructured_data.Database.generate_upload_url(
                        capture.path_image, bucket_name=configs.AWS.S3_BUCKET)
                }
            })

    @staticmethod
    @logging.Funcs.log_func_call("duplicate capture")
    def duplicate(account_id, user_id, capture_id):
        try:
            original_capture = structured_data.Database.find_single(structured_data.Database.captures,
                                                                    {"capture_id": capture_id}, {"_id": 0})
            assert original_capture.get(
                "capture_type") != constants.Captures.CaptureTypes.IMAGE, "IMAGE type capture cannot be duplicated"
            assert original_capture, "invalid capture_id"
            if isinstance(original_capture.get('position'), int):
                structured_data.Database.update_bulk(structured_data.Database.captures,
                                                     {"demo_id": original_capture['demo_id'],
                                                      'position': {"$gt": original_capture['position']}},
                                                     {"$inc": {"position": 1}})
            duplicate_capture = captures.FactoryFuncs.create(
                account_id=account_id, user_id=user_id,
                demo_id=original_capture["demo_id"],
                title=f"{original_capture['title']} (Copy)" if original_capture.get("title", None) else None,
                capture_type=original_capture["capture_type"],
                src_capture=original_capture["capture_id"],
                path_image=original_capture.get("path_image"),
                path_thumbnail=original_capture.get("path_thumbnail"),
                position=original_capture.get('position',
                                              structured_data.Database.count(structured_data.Database.captures,
                                                                             {"demo_id": original_capture[
                                                                                 'demo_id']}) - 1) + 1,
                capture_hash=original_capture.get("capture_hash"))
            unstructured_data.Database.copy(src_path=original_capture["path_html"],
                                            dst_path=duplicate_capture.path_html)
        except AssertionError as ase:
            logging.Funcs.create_error_log(ase, account_id=account_id, user_id=user_id,
                                           component_id=capture_id)
            return general.APIResponse.Error.get_response(ase, 401)
        except Exception as e:
            logging.Funcs.create_error_log(e, account_id=account_id, user_id=user_id,
                                           component_id=capture_id)
            return general.APIResponse.Error.get_response(constants.APIResponse.Messages.BUSINESS_ERROR, 500)
        else:
            return make_response({
                constants.APIResponse.Fields.STATUS: constants.APIResponse.Statuses.SUCCESS,
                constants.APIResponse.Fields.MESSAGE: "capture updated",
                "capture": {
                    **duplicate_capture.as_json(),
                    "html_url": unstructured_data.Database.generate_download_url(duplicate_capture.path_html),
                    "image_url": unstructured_data.Database.generate_download_url(duplicate_capture.path_image),
                    "thumbnail_url": unstructured_data.Database.generate_download_url(
                        (lambda path: path if path else duplicate_capture.path_image)(
                            duplicate_capture.path_thumbnail))
                }
            }, 200)

    @staticmethod
    @logging.Funcs.log_func_call("refresh HTML")
    def refresh(account_id, user_id, capture_id):
        try:
            capture_details = structured_data.Database.find_single(structured_data.Database.captures,
                                                                   {"capture_id": capture_id}, {"_id": 0})
            assert capture_details, "invalid capture id"
            invalidation = cdn.CDN.invalidate_cache(paths=[capture_details["path_html"]])
        except AssertionError as ase:
            logging.Funcs.create_error_log(ase, account_id=account_id, user_id=user_id,
                                           component_id=capture_id)
            return general.APIResponse.Error.get_response(ase, 401)
        except Exception as e:
            logging.Funcs.create_error_log(e, account_id=account_id, user_id=user_id,
                                           component_id=capture_id)
            return general.APIResponse.Error.get_response(constants.APIResponse.Messages.BUSINESS_ERROR, 500)
        else:
            return make_response({
                constants.APIResponse.Fields.STATUS: constants.APIResponse.Statuses.SUCCESS,
                constants.APIResponse.Fields.MESSAGE: "capture refreshed",
                "capture": {
                    **capture_details,
                    "html_url": unstructured_data.Database.generate_download_url(capture_details["path_html"]),
                    "image_url": unstructured_data.Database.generate_download_url(capture_details["path_image"]),
                    "thumbnail_url": unstructured_data.Database.generate_download_url(
                        (lambda path: path if path else capture_details["path_image"])(
                            capture_details.get("path_thumbnail")))
                }
            }, 200)

    @staticmethod
    @logging.Funcs.log_func_call("creating thumbnail for capture or update capture payload")
    def update_capture(account_id, user_id, capture_id):
        try:
            if Utils.Validator.is_create_thumbnail_requested():
                capture_details = structured_data.Database.find_single(structured_data.Database.captures,
                                                                       {"capture_id": capture_id},
                                                                       {"_id": 0})
                assert capture_details, "invalid capture id"
                logging.Logger.log(constants.Logging.INFO, account=account_id, user=user_id,
                                   component=capture_details["capture_id"],
                                   message="sending job for thumbnail creation")
                lambdas.LambdaExecutor.add_job(function_name=configs.AWS.THUMBNAIL_FUNCTION,
                                               message_body={
                                                   "capture_id": capture_details["capture_id"],
                                                   "image_path": capture_details["path_image"]
                                               })
            elif Utils.Validator.is_update_html_requested():
                capture_details = structured_data.Database.find_single(structured_data.Database.captures,
                                                                       {"capture_id": capture_id}, {"_id": 0})
                assert capture_details, "invalid capture id"
                logging.Logger.log(constants.Logging.INFO, account=account_id, user=user_id,
                                   component=capture_details["capture_id"],
                                   message="updating capture HTML")
                return make_response({
                    constants.APIResponse.Fields.STATUS: constants.APIResponse.Statuses.SUCCESS,
                    constants.APIResponse.Fields.MESSAGE: "capture updated",
                    "capture": {
                        **capture_details,
                        "upload_html_url": unstructured_data.Database.generate_upload_url(
                            capture_details["path_html"], bucket_name=configs.AWS.S3_BUCKET),
                    }
                }, 200)
            else:
                Utils.Validator.update_capture()
                structured_data.Database.update_single(structured_data.Database.captures, {"capture_id": capture_id},
                                                       {"$set": dict(request.json)})
                capture_details = structured_data.Database.find_single(structured_data.Database.captures,
                                                                       {"capture_id": capture_id}, {"_id": 0})
        except AssertionError as ase:
            logging.Funcs.create_error_log(ase, account_id=account_id, user_id=user_id,
                                           component_id=capture_id)
            return general.APIResponse.Error.get_response(ase, 401)
        except Exception as e:
            logging.Funcs.create_error_log(e, account_id=account_id, user_id=user_id,
                                           component_id=capture_id)
            return general.APIResponse.Error.get_response(constants.APIResponse.Messages.BUSINESS_ERROR, 500)
        else:
            return make_response({
                constants.APIResponse.Fields.STATUS: constants.APIResponse.Statuses.SUCCESS,
                constants.APIResponse.Fields.MESSAGE: "capture updated",
                "capture": capture_details
            }, 200)

    @staticmethod
    @logging.Funcs.log_func_call("creating static capture")
    def create_static_capture(account_id, user_id):
        try:
            Utils.Validator.validate_create_capture_request()
            capture = captures.FactoryFuncs.create_static_content(account_id=account_id,
                                                                  demo_id=request.json.get("demo_id"))
            upload_url = unstructured_data.Database.generate_upload_url(capture.path_storage,
                                                                        bucket_name=configs.AWS.STATIC_CONTENT_BUCKET)
        except AssertionError as ase:
            logging.Funcs.create_error_log(ase, account_id=account_id, user_id=user_id,
                                           component_id=request.json.get("demo_id"))
            return general.APIResponse.Error.get_response(ase, 401)
        except Exception as e:
            logging.Funcs.create_error_log(e, account_id=account_id, user_id=user_id,
                                           component_id=request.json.get("demo_id"))
            return general.APIResponse.Error.get_response(constants.APIResponse.Messages.BUSINESS_ERROR, 500)
        else:
            return make_response({
                constants.APIResponse.Fields.STATUS: constants.APIResponse.Statuses.SUCCESS,
                constants.APIResponse.Fields.MESSAGE: "created",
                "capture": {
                    **capture.as_json(),
                    "upload_url": upload_url
                }
            }, 200)

    @staticmethod
    @logging.Funcs.log_func_call("delete capture")
    def delete_capture(account_id, user_id, capture_id):
        try:
            # check connections: src_capture_id and dst_capture_id
            # check steps: capture_id
            logging.Logger.log("INFO", message=f"Checking if the capture {capture_id} exists")
            capture_details = structured_data.Database.find_single(structured_data.Database.captures,
                                                                   {"capture_id": capture_id}, {"_id": 0})
            assert capture_details, "capture_id does not exist"
            assert structured_data.Database.count(structured_data.Database.captures,
                                                  {"demo_id": capture_details[
                                                      'demo_id']}) > 1, "Please add more screens before deleting " \
                                                                        "this one."
            assert structured_data.Database.count(
                structured_data.Database.connections,
                {"src_capture_id": capture_id}) == 0, "capture being used as source capture in a connection"
            assert structured_data.Database.count(
                structured_data.Database.connections,
                {"dst_capture_id": capture_id}) == 0, "capture being used as source capture in a connection"
            assert structured_data.Database.count(
                structured_data.Database.steps,
                {"capture_id": capture_id}) == 0, "capture being used in a step"
            structured_data.Database.delete_single(structured_data.Database.captures,
                                                   {"capture_id": capture_id})
        except AssertionError as ase:
            logging.Funcs.create_error_log(ase, account_id=account_id, user_id=user_id,
                                           component_id=capture_id)
            return general.APIResponse.Error.get_response(ase, 401)
        except Exception as e:
            logging.Funcs.create_error_log(e, account_id=account_id, user_id=user_id,
                                           component_id=capture_id)
            return general.APIResponse.Error.get_response(constants.APIResponse.Messages.BUSINESS_ERROR, 500)
        else:
            return make_response({
                constants.APIResponse.Fields.STATUS: constants.APIResponse.Statuses.SUCCESS,
                constants.APIResponse.Fields.MESSAGE: "deleted",
            }, 200)


class Utils:
    class Validator:

        @staticmethod
        def validate_create_capture_request():
            assert request.json.get("demo_id"), "demo id missing from request body"
            if request.args.get("type") == "image" and request.args.get("create_step") == "true":
                assert request.json.get("screen_interaction"), "screen_interaction missing from request body"
                Utils.Validator.__validate_screen_interaction_dictionary(
                    request.json.get("screen_interaction"), ["pointer", "screen", "highlight"])

        @staticmethod
        def __validate_screen_interaction_dictionary(input_dict, required_fields):
            for field in required_fields:
                assert field in input_dict, f"{field} missing from request body"

        @staticmethod
        def is_create_thumbnail_requested():
            return request.args.get("action", None) == "create_thumbnail"

        @staticmethod
        def is_update_html_requested():
            return request.args.get("action", None) == "update_html"

        @staticmethod
        def update_capture():
            assert len(
                set(list(request.json.keys())) - {"title"}) == 0, "invalid update field in request body"
