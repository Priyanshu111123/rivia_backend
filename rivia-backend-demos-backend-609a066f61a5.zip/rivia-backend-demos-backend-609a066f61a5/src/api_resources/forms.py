from src.components import forms, logging, constants, structured_data
from src.funcs import general, search
from flask import make_response, request


class Ops:

    @staticmethod
    @logging.Funcs.log_func_call("creating form")
    def create_form(account_id, user_id):
        try:
            Utils.validate_create_form_request()
            form = forms.FactoryFuncs.create_form(account_id=account_id, user_id=user_id,
                                                  edit_state=request.json.get("edit_state"))
        except AssertionError as ase:
            logging.Funcs.create_error_log(ase, account_id=account_id, user_id=user_id)
            return general.APIResponse.Error.get_response(ase, 401)
        except Exception as e:
            logging.Funcs.create_error_log(e, account_id=account_id, user_id=user_id)
            return general.APIResponse.Error.get_response(e, 500)
        else:
            return make_response({
                constants.APIResponse.Fields.STATUS: constants.APIResponse.Statuses.SUCCESS,
                constants.APIResponse.Fields.MESSAGE: "form created",
                "form": {
                    **form.as_json()
                }
            }, 200)

    @staticmethod
    @logging.Funcs.log_func_call("fetching form")
    def get_single_form(account_id, user_id, form_id):
        try:
            form_details = structured_data.Database.find_single(structured_data.Database.forms,
                                                                {"form_id": form_id}, {"_id": 0})
            assert form_details, "invalid form_id"
            form_fields = list(structured_data.Database.find_bulk(structured_data.Database.form_fields,
                                                                  {"form_id": form_id}, {"_id": 0}).sort(
                [("position", 1)]))
            structured_data.Database.update_single(structured_data.Database.forms, {"demo_id": form_id},
                                                   {"$set": {"updated_at": general.Time.get_current_time()}})
        except AssertionError as ase:
            logging.Funcs.create_error_log(ase, account_id=account_id, user_id=user_id, component_id=form_id)
            return general.APIResponse.Error.get_response(ase, 401)
        except Exception as e:
            logging.Funcs.create_error_log(e, account_id=account_id, user_id=user_id, component_id=form_id)
            return general.APIResponse.Error.get_response(e, 500)
        else:
            return make_response({
                constants.APIResponse.Fields.STATUS: constants.APIResponse.Statuses.SUCCESS,
                constants.APIResponse.Fields.MESSAGE: "form retrieved",
                **form_details,
                "fields": form_fields
            }, 200)

    @staticmethod
    @logging.Funcs.log_func_call("fetching forms - bulk")
    def get_bulk_forms(account_id, user_id):
        try:
            results = search.Ops.fetch(structured_data.Database.forms,
                                       account_id=account_id,
                                       page_number=int(request.args.get("page_number", 0)),
                                       date_start=request.args.get("date_start"),
                                       date_end=request.args.get("date_end"),
                                       text_query=request.args.get("text_query"),
                                       num_results=20,
                                       projection={"_id": 0, "edit_state": 0})
            count = search.Ops.count(structured_data.Database.forms,
                                     account_id=account_id,
                                     date_start=request.args.get("date_start"),
                                     date_end=request.args.get("date_end"),
                                     text_query=request.args.get("text_query"))
        except AssertionError as ase:
            logging.Funcs.create_error_log(ase, account_id=account_id, user_id=user_id)
            return general.APIResponse.Error.get_response(ase, 401)
        except Exception as e:
            logging.Funcs.create_error_log(e, account_id=account_id, user_id=user_id)
            return general.APIResponse.Error.get_response(constants.APIResponse.Messages.BUSINESS_ERROR, 500)
        else:
            return make_response({
                constants.APIResponse.Fields.STATUS: constants.APIResponse.Statuses.SUCCESS,
                constants.APIResponse.Fields.MESSAGE: f"{len(results)} out of {count} forms retrieved",
                "results": results,
                "count": count
            }, 200)

    @staticmethod
    @logging.Funcs.log_func_call("deleting form")
    def delete_form(account_id, user_id, form_id):
        try:
            form_usage = structured_data.Database.count(structured_data.Database.steps,
                                                        {"form_id": form_id})
            assert form_usage == 0, "form being used in demos. cannot delete"
            structured_data.Database.delete_single(structured_data.Database.forms, {"form_id": form_id})
            structured_data.Database.delete_many(structured_data.Database.form_fields, {"form_id": form_id})
        except AssertionError as ase:
            logging.Funcs.create_error_log(ase, account_id=account_id, user_id=user_id, component_id=form_id)
            return general.APIResponse.Error.get_response(ase, 401)
        except Exception as e:
            logging.Funcs.create_error_log(e, account_id=account_id, user_id=user_id, component_id=form_id)
            return general.APIResponse.Error.get_response(constants.APIResponse.Messages.BUSINESS_ERROR, 500)
        else:
            return make_response({
                constants.APIResponse.Fields.STATUS: constants.APIResponse.Statuses.SUCCESS,
                constants.APIResponse.Fields.MESSAGE: f"form deleted"
            }, 200)

    @staticmethod
    @logging.Funcs.log_func_call("updating form")
    def update_form(account_id, user_id, form_id):
        try:
            Utils.validate_update_form_request()
            structured_data.Database.update_single(structured_data.Database.forms,
                                                   {"form_id": form_id},
                                                   {"$set": {**request.json,
                                                             "updated_at": general.Time.get_current_time()}})
        except AssertionError as ase:
            logging.Funcs.create_error_log(ase, account_id=account_id, user_id=user_id, component_id=form_id)
            return general.APIResponse.Error.get_response(ase, 401)
        except Exception as e:
            logging.Funcs.create_error_log(e, account_id=account_id, user_id=user_id, component_id=form_id)
            return general.APIResponse.Error.get_response(constants.APIResponse.Messages.BUSINESS_ERROR, 500)
        else:
            return make_response({
                constants.APIResponse.Fields.STATUS: constants.APIResponse.Statuses.SUCCESS,
                constants.APIResponse.Fields.MESSAGE: f"form updated"
            }, 200)

    @staticmethod
    @logging.Funcs.log_func_call("creating a form field")
    def create_form_field(account_id, user_id):
        try:
            Utils.validate_create_form_field_request()
            structured_data.Database.update_bulk(structured_data.Database.form_fields,
                                                 {"form_id": request.json.get("form_id"),
                                                  "position": {"$gte": request.json.get("position")}},
                                                 {"$inc": {"position": 1}})
            form_field = forms.FactoryFuncs.create_form_field(account_id=account_id, user_id=user_id,
                                                              form_id=request.json.get("form_id"),
                                                              field_type=request.json.get("field_type"),
                                                              position=request.json.get("position"),
                                                              edit_state=request.json.get("edit_state"))
        except AssertionError as ase:
            logging.Funcs.create_error_log(ase, account_id=account_id, user_id=user_id,
                                           component_id=request.json.get("form_id"))
            return general.APIResponse.Error.get_response(ase, 401)
        except Exception as e:
            logging.Funcs.create_error_log(e, account_id=account_id, user_id=user_id,
                                           component_id=request.json.get("form_id"))
            return general.APIResponse.Error.get_response(constants.APIResponse.Messages.BUSINESS_ERROR, 500)
        else:
            return make_response({
                constants.APIResponse.Fields.STATUS: constants.APIResponse.Statuses.SUCCESS,
                constants.APIResponse.Fields.MESSAGE: f"form field created",
                "form_field": {
                    **form_field.as_json()
                }
            }, 200)

    @staticmethod
    @logging.Funcs.log_func_call("retrieving a form field")
    def get_single_form_field(account_id, user_id, form_field_id):
        try:
            form_field_details = structured_data.Database.find_single(structured_data.Database.form_fields,
                                                                      {"form_field_id": form_field_id}, {"_id": 0})
            assert form_field_details, "invalid form field id"
        except AssertionError as ase:
            logging.Funcs.create_error_log(ase, account_id=account_id, user_id=user_id,
                                           component_id=form_field_id)
            return general.APIResponse.Error.get_response(ase, 401)
        except Exception as e:
            logging.Funcs.create_error_log(e, account_id=account_id, user_id=user_id,
                                           component_id=form_field_id)
            return general.APIResponse.Error.get_response(constants.APIResponse.Messages.BUSINESS_ERROR, 500)
        else:
            return make_response({
                constants.APIResponse.Fields.STATUS: constants.APIResponse.Statuses.SUCCESS,
                constants.APIResponse.Fields.MESSAGE: f"form field retrieved",
                "form_field": {
                    **form_field_details
                }
            }, 200)

    @staticmethod
    @logging.Funcs.log_func_call("retrieving form fields - bulk")
    def get_bulk_form_fields(account_id, user_id):
        try:
            Utils.validate_retrieve_form_fields_bulk_request()
            form_fields = list(structured_data.Database.find_bulk(structured_data.Database.form_fields,
                                                                  {"form_id": request.json.get("form_id")},
                                                                  {"_id": 0}).sort(
                [("position", 1)]))
        except AssertionError as ase:
            logging.Funcs.create_error_log(ase, account_id=account_id, user_id=user_id,
                                           component_id=request.json.get("form_id"))
            return general.APIResponse.Error.get_response(ase, 401)
        except Exception as e:
            logging.Funcs.create_error_log(e, account_id=account_id, user_id=user_id,
                                           component_id=request.json.get("form_id"))
            return general.APIResponse.Error.get_response(constants.APIResponse.Messages.BUSINESS_ERROR, 500)
        else:
            return make_response({
                constants.APIResponse.Fields.STATUS: constants.APIResponse.Statuses.SUCCESS,
                constants.APIResponse.Fields.MESSAGE: f"{len(form_fields)} form fields retrieved",
                "form_fields": form_fields
            }, 200)

    @staticmethod
    @logging.Funcs.log_func_call("deleting form field")
    def delete_form_field(account_id, user_id, form_field_id):
        try:
            form_field_details = structured_data.Database.find_single(structured_data.Database.form_fields,
                                                                      {"account_id": account_id,
                                                                       "form_field_id": form_field_id},
                                                                      {"_id": 0, "form_id": 1, "position": 1})
            assert form_field_details, "invalid form field id"
            structured_data.Database.delete_single(structured_data.Database.form_fields,
                                                   {"form_field_id": form_field_id})
            structured_data.Database.update_bulk(structured_data.Database.form_fields,
                                                 {"form_id": form_field_details["form_id"],
                                                  "position": {"$gte": form_field_details["position"]}},
                                                 {"$inc": {"position": -1}})
        except AssertionError as ase:
            logging.Funcs.create_error_log(ase, account_id=account_id, user_id=user_id, component_id=form_field_id)
            return general.APIResponse.Error.get_response(ase, 401)
        except Exception as e:
            logging.Funcs.create_error_log(e, account_id=account_id, user_id=user_id, component_id=form_field_id)
            return general.APIResponse.Error.get_response(constants.APIResponse.Messages.BUSINESS_ERROR, 500)
        else:
            return make_response({
                constants.APIResponse.Fields.STATUS: constants.APIResponse.Statuses.SUCCESS,
                constants.APIResponse.Fields.MESSAGE: "form field deleted"
            }, 200)

    @staticmethod
    @logging.Funcs.log_func_call("updating form field")
    def update_form_field(account_id, user_id, form_field_id):
        try:
            Utils.validate_update_form_field_request()
            form_field_details = structured_data.Database.find_single(structured_data.Database.form_fields,
                                                                      {"form_field_id": form_field_id}, {"_id": 0})
            assert form_field_details, "invalid form field id"
            if request.json.get("position") is not None:
                assert 0 <= request.json.get("position") < structured_data.Database.count(
                    structured_data.Database.form_fields,
                    {"form_id": form_field_details["form_id"]}), "invalid form field position"
                structured_data.Database.update_bulk(structured_data.Database.form_fields,
                                                     {"form_id": form_field_details["form_id"],
                                                      "position": {"$gt": form_field_details["position"]}},
                                                     {"$inc": {"position": -1}})
                structured_data.Database.update_bulk(structured_data.Database.form_fields,
                                                     {"form_id": form_field_details["form_id"],
                                                      "position": {"$gte": request.json.get("position")}},
                                                     {"$inc": {"position": 1}})
            structured_data.Database.update_single(structured_data.Database.form_fields,
                                                   {"form_field_id": form_field_id},
                                                   {"$set": {**request.json}})
        except AssertionError as ase:
            logging.Funcs.create_error_log(ase, account_id=account_id, user_id=user_id, component_id=form_field_id)
            return general.APIResponse.Error.get_response(ase, 401)
        except Exception as e:
            logging.Funcs.create_error_log(e, account_id=account_id, user_id=user_id, component_id=form_field_id)
            return general.APIResponse.Error.get_response(constants.APIResponse.Messages.BUSINESS_ERROR, 500)
        else:
            return make_response({
                constants.APIResponse.Fields.STATUS: constants.APIResponse.Statuses.SUCCESS,
                constants.APIResponse.Fields.MESSAGE: "updated"
            }, 200)


class Utils:

    @staticmethod
    def validate_create_form_request():
        assert request.json.get("edit_state"), "edit_state missing from the request body"

    @staticmethod
    def validate_update_form_request():
        assert request.json, "request body missing"
        assert request.json.get("title") or request.json.get("edit_state"), "invalid field in request body"

    @staticmethod
    def validate_create_form_field_request():
        assert request.json.get("form_id"), "form_id missing in request body"
        assert 0 <= request.json.get("position") <= structured_data.Database.count(
            structured_data.Database.form_fields,
            {"form_id": request.json.get("form_id")}), "Invalid form field position"
        assert request.json.get("field_type"), "field_type missing in request body"
        assert request.json.get("field_type") in constants.Data.FormFields.all(), "invalid field_type value"
        assert request.json.get("edit_state"), "edit_state missing in request body"

    @staticmethod
    def validate_retrieve_form_fields_bulk_request():
        assert request.json.get("form_id"), "form_id missing in request body"

    @staticmethod
    def validate_update_form_field_request():
        assert request.json, "update request body missing"
        assert request.json.get("edit_state"), "invalid field to update in request body"
