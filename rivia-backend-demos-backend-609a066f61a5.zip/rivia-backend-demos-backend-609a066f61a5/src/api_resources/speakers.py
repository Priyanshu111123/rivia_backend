from src.funcs import general
from src.components import logging, speakers, constants, structured_data
from flask import request, make_response


class Ops:

    @staticmethod
    @logging.Funcs.log_func_call("creating speaker")
    def create(account_id, user_id):
        try:
            Utils.Validator.create()
            speaker = speakers.FactoryFuncs.create(
                account_id=None if request.json.get("speaker_type") in {constants.Speakers.SpeakerTypes.POLLY,
                                                                        constants.Speakers.SpeakerTypes.ELEVENLABS}
                else account_id,
                external_speaker_id=request.json.get("external_speaker_id"),
                speaker_type=request.json.get("speaker_type"),
                speaker_name=request.json.get("speaker_name"))
            return make_response({
                constants.APIResponse.Fields.STATUS: constants.APIResponse.Statuses.SUCCESS,
                constants.APIResponse.Fields.MESSAGE: "speaker created",
                "speaker": speaker.as_json()})
        except AssertionError as ase:
            logging.Funcs.create_error_log(ase, account_id=account_id, user_id=user_id,
                                           component_id=request.json.get("external_speaker_id"))
            return general.APIResponse.Error.get_response(ase, 401)
        except Exception as e:
            logging.Funcs.create_error_log(e, account_id=account_id, user_id=user_id,
                                           component_id=request.json.get("external_speaker_id"))
            return general.APIResponse.Error.get_response(constants.APIResponse.Messages.BUSINESS_ERROR, 500)

    @staticmethod
    @logging.Funcs.log_func_call("fetch speakers for account")
    def fetch(account_id, user_id):
        try:
            speaker_details = list(structured_data.Database.find_bulk(structured_data.Database.speakers,
                                                                      {"account_id": {"$in": [None, account_id]}},
                                                                      {"_id": 0}))
            return make_response({
                constants.APIResponse.Fields.STATUS: constants.APIResponse.Statuses.SUCCESS,
                constants.APIResponse.Fields.MESSAGE: f"{len(speaker_details)} speakers fetched",
                "speakers": speaker_details})
        except AssertionError as ase:
            logging.Funcs.create_error_log(ase, account_id=account_id, user_id=user_id,
                                           component_id=request.json.get("external_speaker_id"))
            return general.APIResponse.Error.get_response(ase, 401)

        except Exception as e:
            logging.Funcs.create_error_log(e, account_id=account_id, user_id=user_id,
                                           component_id=request.json.get("external_speaker_id"))
        return general.APIResponse.Error.get_response(constants.APIResponse.Messages.BUSINESS_ERROR, 500)


class Utils:
    class Validator:

        @staticmethod
        def create():
            assert request.json.get("speaker_type") in constants.Speakers.SpeakerTypes.all(), "invalid speaker type"
            assert request.json.get("external_speaker_id"), "external_speaker_id missing in request body"
            assert request.json.get("speaker_name"), "speaker_name missing in request body"
            assert not structured_data.Database.find_single(structured_data.Database.speakers,
                                                            {"speaker_name": request.json.get("speaker_name")},
                                                            {"_id": 0}), "speaker_name already exists." \
                                                                         " Choose a different name"
