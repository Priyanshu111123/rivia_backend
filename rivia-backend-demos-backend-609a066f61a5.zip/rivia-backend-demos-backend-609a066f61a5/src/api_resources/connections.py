from src.funcs import general
from src.components import logging, constants, connections, structured_data
from flask import make_response, request


class Ops:

    @staticmethod
    @logging.Funcs.log_func_call("creating connection")
    def create(account_id, user_id):
        try:
            Utils.Validator.create()
            connection = connections.FactoryFuncs.create(account_id=account_id, user_id=user_id,
                                                         demo_id=request.json.get("demo_id"),
                                                         src_capture_id=request.json.get("src_capture_id"),
                                                         dst_capture_id=request.json.get("dst_capture_id"),
                                                         src_rivia_id=request.json.get("src_rivia_id"),
                                                         event_type=request.json.get("event_type"),
                                                         text_input=request.json.get("text_input"),
                                                         negative_interaction=request.json.get("negative_interaction",
                                                                                               False),
                                                         image_target_area=request.json.get("image_target_area", {}),
                                                         new_tab=request.json.get("new_tab", False),
                                                         redirect_url=request.json.get("redirect_url"),
                                                         src_rivia_xpath_id=request.json.get("src_rivia_xpath_id"))
        except AssertionError as ase:
            logging.Funcs.create_error_log(ase, account_id=account_id, user_id=user_id)
            return general.APIResponse.Error.get_response(ase, 401)
        except Exception as e:
            logging.Funcs.create_error_log(e, account_id=account_id, user_id=user_id)
            return general.APIResponse.Error.get_response(constants.APIResponse.Messages.BUSINESS_ERROR, 500)
        else:
            return make_response({
                constants.APIResponse.Fields.STATUS: constants.APIResponse.Statuses.SUCCESS,
                constants.APIResponse.Fields.MESSAGE: "connection created",
                "connection": connection.as_json()
            }, 200)

    @staticmethod
    @logging.Funcs.log_func_call("fetching single connection for a demo")
    def fetch(account_id, user_id, connection_id):
        try:
            connection_details = structured_data.Database.find_single(structured_data.Database.connections,
                                                                      {"connection_id": connection_id},
                                                                      {"_id": 0})
            assert connection_details, "invalid connection_id"
        except AssertionError as ase:
            logging.Funcs.create_error_log(ase, account_id=account_id, user_id=user_id)
            return general.APIResponse.Error.get_response(ase, 401)
        except Exception as e:
            logging.Funcs.create_error_log(e, account_id=account_id, user_id=user_id)
            return general.APIResponse.Error.get_response(constants.APIResponse.Messages.BUSINESS_ERROR, 500)
        else:
            return make_response({
                constants.APIResponse.Fields.STATUS: constants.APIResponse.Statuses.SUCCESS,
                constants.APIResponse.Fields.MESSAGE: f"connections fetched",
                "connection": connection_details
            }, 200)

    @staticmethod
    @logging.Funcs.log_func_call("fetching connections for a demo")
    def fetch_all(account_id, user_id):
        try:
            Utils.Validator.fetch_all()
            connection_details = list(structured_data.Database.find_bulk(structured_data.Database.connections,
                                                                         {"demo_id": request.args.get("demo_id"),
                                                                          **({"src_capture_id": request.args.get(
                                                                              "src_capture_id")} if request.args.get(
                                                                              "src_capture_id") else {}),
                                                                          **({"dst_capture_id": request.args.get(
                                                                              "dst_capture_id")} if request.args.get(
                                                                              "dst_capture_id") else {})},
                                                                         {"_id": 0}))
        except AssertionError as ase:
            logging.Funcs.create_error_log(ase, account_id=account_id, user_id=user_id)
            return general.APIResponse.Error.get_response(ase, 401)
        except Exception as e:
            logging.Funcs.create_error_log(e, account_id=account_id, user_id=user_id)
            return general.APIResponse.Error.get_response(constants.APIResponse.Messages.BUSINESS_ERROR, 500)
        else:
            return make_response({
                constants.APIResponse.Fields.STATUS: constants.APIResponse.Statuses.SUCCESS,
                constants.APIResponse.Fields.MESSAGE: f"{len(connection_details)} connections fetched",
                "connections": connection_details
            }, 200)

    @staticmethod
    @logging.Funcs.log_func_call("updating connection")
    def update(account_id, user_id, connection_id):
        try:
            Utils.Validator.update()
            structured_data.Database.update_single(structured_data.Database.connections,
                                                   {"connection_id": connection_id},
                                                   {"$set": dict(request.json)})
            connection = structured_data.Database.find_single(structured_data.Database.connections,
                                                              {"connection_id": connection_id}, {"_id": 0})
        except AssertionError as ase:
            logging.Funcs.create_error_log(ase, account_id=account_id, user_id=user_id, component_id=connection_id)
            return general.APIResponse.Error.get_response(ase, 401)
        except Exception as e:
            logging.Funcs.create_error_log(e, account_id=account_id, user_id=user_id, component_id=connection_id)
            return general.APIResponse.Error.get_response(constants.APIResponse.Messages.BUSINESS_ERROR, 500)
        else:
            return make_response({
                constants.APIResponse.Fields.STATUS: constants.APIResponse.Statuses.SUCCESS,
                constants.APIResponse.Fields.MESSAGE: "updated",
                "connection": {
                    **connection
                }
            }, 200)

    @staticmethod
    @logging.Funcs.log_func_call("deleting connection")
    def delete(account_id, user_id, connection_id):
        try:
            structured_data.Database.delete_single(structured_data.Database.connections,
                                                   {"connection_id": connection_id})
        except Exception as e:
            logging.Funcs.create_error_log(e, account_id=account_id, user_id=user_id, component_id=connection_id)
            return general.APIResponse.Error.get_response(constants.APIResponse.Messages.BUSINESS_ERROR, 500)
        else:
            return make_response({
                constants.APIResponse.Fields.STATUS: constants.APIResponse.Statuses.SUCCESS,
                constants.APIResponse.Fields.MESSAGE: "deleted"
            }, 200)


class Utils:
    class Validator:
        @staticmethod
        def create():
            assert request.json.get("demo_id"), "demo_id missing from request body"
            assert request.json.get("src_capture_id"), "src_capture_id missing from request body"
            if not request.json.get("redirect_url"):
                assert request.json.get("dst_capture_id"), "dst_capture_id missing from request body"
            assert request.json.get("src_rivia_id"), "src_rivia_id missing from request body"
            assert request.json.get("event_type"), "event_type missing from request body"
            if request.json.get("negative_interaction"):
                assert isinstance(request.json.get("negative_interaction"),
                                  bool), "negative_interaction needs to be a boolean value"
            if request.json.get("new_tab"):
                assert isinstance(request.json.get("new_tab"), bool), "new_tab needs to be a boolean value"
            assert request.json.get("event_type") in {constants.Playgrounds.Events.CLICK,
                                                      constants.Playgrounds.Events.HOVER,
                                                      constants.Playgrounds.Events.TEXTINPUT,
                                                      constants.Playgrounds.Events.NEGATIVE_INTERACTION}, "invalid valid of " \
                                                                                                          "event_type"
            if request.json.get("event_type") == constants.Playgrounds.Events.TEXTINPUT:
                assert "text_input" in request.json, "text_input field is mandatory when the event_type in TEXTINPUT"
            Utils.Validator.__capture_id_exists(request.json.get("src_capture_id"))
            if not request.json.get("redirect_url"):
                Utils.Validator.__capture_id_exists(request.json.get("dst_capture_id"))
            if request.json.get("image_target_area"):
                Utils.Validator.__validate_target_area()

        @staticmethod
        def __capture_id_exists(capture_id):
            assert structured_data.Database.find_single(structured_data.Database.captures, {"capture_id": capture_id},
                                                        {"_id": 0})

        @staticmethod
        def __validate_target_area():
            assert "left" in request.json.get("image_target_area", {}), "left missing from image_target_area field"
            assert isinstance(request.json.get("image_target_area", {})["left"], float), "invalid datatype for left"
            assert "top" in request.json.get("image_target_area", {}), "top missing from image_target_area field"
            assert isinstance(request.json.get("image_target_area", {})["top"], float), "invalid datatype for top"
            assert "width" in request.json.get("image_target_area",
                                               {}), "width missing from image_target_area field"
            assert isinstance(request.json.get("image_target_area", {})["width"],
                              float), "invalid datatype for width"
            assert "height" in request.json.get("image_target_area",
                                                {}), "height missing from image_target_area field"
            assert isinstance(request.json.get("image_target_area", {})["height"],
                              float), "invalid datatype for height"

        @staticmethod
        def update():
            assert len(
                set(list(request.json.keys())) - {"src_capture_id", "dst_capture_id",
                                                  "src_rivia_id", "event_type",
                                                  "text_input",
                                                  "negative_interaction",
                                                  "image_target_area",
                                                  "new_tab",
                                                  "redirect_url",
                                                  "src_rivia_xpath_id"}) == 0, "invalid update field in request body"
            if request.json.get("event_type"):
                assert request.json.get("event_type") in {constants.Playgrounds.Events.CLICK,
                                                          constants.Playgrounds.Events.HOVER,
                                                          constants.Playgrounds.Events.TEXTINPUT,
                                                          constants.Playgrounds.Events.NEGATIVE_INTERACTION}, "invalid valid of " \
                                                                                                              "event_type"
            if request.json.get("negative_interaction"):
                assert isinstance(request.json.get("negative_interaction"),
                                  bool), "negative_interaction needs to be a boolean value"

            if request.json.get("new_tab"):
                assert isinstance(request.json.get("new_tab"), bool), "new_tab needs to be a boolean value"

            if request.json.get("image_target_area"):
                Utils.Validator.__validate_target_area()

        @staticmethod
        def fetch_all():
            assert request.args.get("demo_id"), "demo_id missing from request parameters"
