from src.funcs import general
from flask import request, make_response
from src.components import logging, constants, structured_data
from collections import namedtuple

redirect = namedtuple("redirect", ["redirect_id", "account_id", "user_id", "demo_id", "capture_id",
                                   "created_at", "updated_at",
                                   "data_rivia_id", "url", "open_in_new_tab"])


class Ops:

    @staticmethod
    @logging.Funcs.log_func_call("creating redirect")
    def create(account_id, user_id):
        try:
            Utils.RequestValidator.validate_create()
            redirect_obj = redirect(general.Identifiers.generate_redirect_id(),
                                    account_id,
                                    user_id,
                                    request.json.get("demo_id"),
                                    request.json.get("capture_id"),
                                    general.Time.get_current_time(),
                                    general.Time.get_current_time(),
                                    request.json.get("data_rivia_id"),
                                    request.json.get("open_in_new_tab", True))
            structured_data.Database.add_single(structured_data.Database.redirects,
                                                redirect_obj._asdict())
        except AssertionError as ase:
            logging.Funcs.create_error_log(ase, account_id=account_id, user_id=user_id,
                                           component_id=request.json.get("capture_id"))
            return general.APIResponse.Error.get_response(ase, 401)
        except Exception as e:
            logging.Funcs.create_error_log(e, account_id=account_id, user_id=user_id,
                                           component_id=request.json.get("capture_id"))
            return general.APIResponse.Error.get_response(constants.APIResponse.Messages.BUSINESS_ERROR, 500)
        else:
            return make_response({constants.APIResponse.Fields.STATUS: constants.APIResponse.Statuses.SUCCESS,
                                  constants.APIResponse.Fields.MESSAGE: "redirect created",
                                  "redirect": redirect_obj._asdict()},
                                 200)

    @staticmethod
    @logging.Funcs.log_func_call("getting redirect")
    def get(account_id, user_id, redirect_id):
        try:
            redirect_obj = structured_data.Database.find_single(structured_data.Database.redirects,
                                                                {"redirect_id": redirect_id}, {"_id": 0})
            assert redirect_obj, "redirect not found"
            return make_response({constants.APIResponse.Fields.STATUS: constants.APIResponse.Statuses.SUCCESS,
                                  constants.APIResponse.Fields.MESSAGE: "redirect found",
                                  "redirect": redirect_obj},
                                 200)
        except AssertionError as ase:
            logging.Funcs.create_error_log(ase, account_id=account_id, user_id=user_id, component_id=redirect_id)
            return general.APIResponse.Error.get_response(ase, 401)
        except Exception as e:
            logging.Funcs.create_error_log(e, account_id=account_id, user_id=user_id, component_id=redirect_id)
            return general.APIResponse.Error.get_response(constants.APIResponse.Messages.BUSINESS_ERROR, 500)

    @staticmethod
    @logging.Funcs.log_func_call("getting all redirects for a capture")
    def get_all(account_id, user_id):
        try:
            Utils.RequestValidator.validate_get_all()
            redirects = list(structured_data.Database.find_bulk(structured_data.Database.redirects,
                                                                {"capture_id": request.args.get("capture_id")},
                                                                {"_id": 0}).sort(
                "created_at", -1))
            return make_response({constants.APIResponse.Fields.STATUS: constants.APIResponse.Statuses.SUCCESS,
                                  constants.APIResponse.Fields.MESSAGE: f" {len(redirects)} redirects found",
                                  "redirects": redirects},
                                 200)
        except AssertionError as ase:
            logging.Funcs.create_error_log(ase, account_id=account_id, user_id=user_id,
                                           component_id=request.args.get("capture_id"))
            return general.APIResponse.Error.get_response(ase, 401)
        except Exception as e:
            logging.Funcs.create_error_log(e, account_id=account_id, user_id=user_id,
                                           component_id=request.args.get("capture_id"))
            return general.APIResponse.Error.get_response(constants.APIResponse.Messages.BUSINESS_ERROR, 500)

    @staticmethod
    @logging.Funcs.log_func_call("deleting redirect")
    def delete(account_id, user_id, redirect_id):
        try:
            structured_data.Database.delete_single(structured_data.Database.redirects, {"redirect_id": redirect_id})
        except AssertionError as ase:
            logging.Funcs.create_error_log(ase, account_id=account_id, user_id=user_id, component_id=redirect_id)
            return general.APIResponse.Error.get_response(ase, 401)
        except Exception as e:
            logging.Funcs.create_error_log(e, account_id=account_id, user_id=user_id, component_id=redirect_id)
            return general.APIResponse.Error.get_response(constants.APIResponse.Messages.BUSINESS_ERROR, 500)
        else:
            return make_response({constants.APIResponse.Fields.STATUS: constants.APIResponse.Statuses.SUCCESS,
                                  constants.APIResponse.Fields.MESSAGE: "redirect deleted"},
                                 200)

    @staticmethod
    @logging.Funcs.log_func_call("updating redirect")
    def update(account_id, user_id, redirect_id):
        try:
            Utils.RequestValidator.validate_update()
            redirect_obj = structured_data.Database.find_single(structured_data.Database.redirects,
                                                                {"redirect_id": redirect_id}, {"_id": 0})
            assert redirect_obj, "redirect not found"
            structured_data.Database.update_single(structured_data.Database.redirects, {"redirect_id": redirect_id},
                                                   {"$set": {"updated_at": general.Time.get_current_time(),
                                                             **request.json}})
        except AssertionError as ase:
            logging.Funcs.create_error_log(ase, account_id=account_id, user_id=user_id, component_id=redirect_id)
            return general.APIResponse.Error.get_response(ase, 401)
        except Exception as e:
            logging.Funcs.create_error_log(e, account_id=account_id, user_id=user_id, component_id=redirect_id)
            return general.APIResponse.Error.get_response(constants.APIResponse.Messages.BUSINESS_ERROR, 500)
        else:
            return make_response({constants.APIResponse.Fields.STATUS: constants.APIResponse.Statuses.SUCCESS,
                                  constants.APIResponse.Fields.MESSAGE: "redirect updated"},
                                 200)


class Utils:
    class RequestValidator:

        @staticmethod
        def validate_create():
            assert "demo_id" in request.json, "demo_id is required"
            assert "capture_id" in request.json, "capture_id is required"
            assert "data_rivia_id" in request.json, "data_rivia_id is required"
            assert "url" in request.json, "url is required"
            if "open_in_new_tab" in request.json:
                assert isinstance(request.json.get("open_in_new_tab"), bool), "open_in_new_tab should be a boolean"

        @staticmethod
        def validate_get_all():
            assert "capture_id" in request.args, "capture_id is required"

        @staticmethod
        def validate_update():
            assert len(
                set(list(request.json.keys())) - {"demo_id", "capture_id", "data_rivia_id", "url",
                                                  "open_in_new_tab"}) == 0, "invalid update field in request body"
            if "open_in_new_tab" in request.json:
                assert isinstance(request.json.get("open_in_new_tab"), bool), "open_in_new_tab should be a boolean"
