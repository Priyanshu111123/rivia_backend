from src.components import logging, constants, menus, structured_data
from src.funcs import general
from flask import request, make_response


class MenuOps:

    @staticmethod
    @logging.Funcs.log_func_call("creating a menu")
    def create(account_id, user_id):
        try:
            RequestUtils.Validators.validate_create_menu_request()
            menu = menus.FactoryFuncs.create_menu(account_id=account_id, user_id=user_id,
                                                  demo_id=request.json.get("demo_id"),
                                                  title=request.json.get("title"),
                                                  description=request.json.get("description"),
                                                  edit_state=request.json.get("edit_state"))
        except AssertionError as ase:
            logging.Funcs.create_error_log(ase, account_id=account_id, user_id=user_id,
                                           component_id=request.json.get("demo_id"))
            return general.APIResponse.Error.get_response(ase, 401)
        except Exception as e:
            logging.Funcs.create_error_log(e, account_id=account_id, user_id=user_id,
                                           component_id=request.json.get("demo_id"))
            return general.APIResponse.Error.get_response(constants.APIResponse.Messages.BUSINESS_ERROR, 500)
        else:
            return make_response({constants.APIResponse.Fields.STATUS: constants.APIResponse.Statuses.SUCCESS,
                                  constants.APIResponse.Fields.MESSAGE: "menu created",
                                  "menu": {**menu.as_json(), "options": []}}, 200)

    @staticmethod
    @logging.Funcs.log_func_call("updating a menu")
    def update(account_id, user_id, menu_id):
        try:
            RequestUtils.Validators.validate_update_menu_request()
            structured_data.Database.update_single(structured_data.Database.menus,
                                                   {"menu_id": menu_id}, {"$set": {**request.json}})
        except AssertionError as ase:
            logging.Funcs.create_error_log(ase, account_id=account_id, user_id=user_id, component_id=menu_id)
            return general.APIResponse.Error.get_response(ase, 401)
        except Exception as e:
            logging.Funcs.create_error_log(e, account_id=account_id, user_id=user_id, component_id=menu_id)
            return general.APIResponse.Error.get_response(constants.APIResponse.Messages.BUSINESS_ERROR, 500)
        else:
            return make_response({constants.APIResponse.Fields.STATUS: constants.APIResponse.Statuses.SUCCESS,
                                  constants.APIResponse.Fields.MESSAGE: "menu updated"}, 200)

    @staticmethod
    @logging.Funcs.log_func_call("fetching a menu")
    def fetch(account_id, user_id, menu_id):
        try:
            menu_details = structured_data.Database.find_single(structured_data.Database.menus, {"menu_id": menu_id},
                                                                {"_id": 0})
            menu_options = list(structured_data.Database.find_bulk(structured_data.Database.menu_options,
                                                                   {"menu_id": menu_id},
                                                                   {"_id": 0}).sort([("position", 1)]))
        except AssertionError as ase:
            logging.Funcs.create_error_log(ase, account_id=account_id, user_id=user_id, component_id=menu_id)
            return general.APIResponse.Error.get_response(ase, 401)
        except Exception as e:
            logging.Funcs.create_error_log(e, account_id=account_id, user_id=user_id, component_id=menu_id)
            return general.APIResponse.Error.get_response(constants.APIResponse.Messages.BUSINESS_ERROR, 500)
        else:
            return make_response({constants.APIResponse.Fields.STATUS: constants.APIResponse.Statuses.SUCCESS,
                                  constants.APIResponse.Fields.MESSAGE: "menu retrieved",
                                  "menu": {
                                      **menu_details,
                                      "options": menu_options
                                  }}, 200)


class MenuOptionOps:

    @staticmethod
    @logging.Funcs.log_func_call("fetch menu option")
    def fetch(account_id, user_id, menu_option_id):
        try:
            menu_option = structured_data.Database.find_single(structured_data.Database.menu_options,
                                                               {"menu_option_id": menu_option_id}, {"_id": 0})
            assert menu_option, "invalid menu option"
        except AssertionError as ase:
            logging.Funcs.create_error_log(ase, account_id=account_id, user_id=user_id, component_id=menu_option_id)
            return general.APIResponse.Error.get_response(ase, 401)
        except Exception as e:
            logging.Funcs.create_error_log(e, account_id=account_id, user_id=user_id, component_id=menu_option_id)
            return general.APIResponse.Error.get_response(constants.APIResponse.Messages.BUSINESS_ERROR, 500)
        else:
            return make_response({constants.APIResponse.Fields.STATUS: constants.APIResponse.Statuses.SUCCESS,
                                  constants.APIResponse.Fields.MESSAGE: "menu option retrieved",
                                  "menu_option": menu_option}, 200)

    @staticmethod
    @logging.Funcs.log_func_call("fetch menu options - bulk")
    def fetch_in_bulk(account_id, user_id):
        try:
            RequestUtils.Validators.validate_fetch_menu_options_in_bulk_request()
            results = list(structured_data.Database.find_bulk(structured_data.Database.menu_options,
                                                              {"menu_id": request.args.get("menu_id")},
                                                              {"_id": 0}).sort([("position", 1)]))
        except AssertionError as ase:
            logging.Funcs.create_error_log(ase, account_id=account_id, user_id=user_id,
                                           component_id=request.args.get("menu_id"))
            return general.APIResponse.Error.get_response(ase, 401)
        except Exception as e:
            logging.Funcs.create_error_log(e, account_id=account_id, user_id=user_id,
                                           component_id=request.args.get("menu_id"))
            return general.APIResponse.Error.get_response(constants.APIResponse.Messages.BUSINESS_ERROR, 500)
        else:
            return make_response({constants.APIResponse.Fields.STATUS: constants.APIResponse.Statuses.SUCCESS,
                                  constants.APIResponse.Fields.MESSAGE: "menu options",
                                  "count": len(results), "results": results}, 200)

    @staticmethod
    @logging.Funcs.log_func_call("create menu option")
    def create(account_id, user_id):
        try:
            RequestUtils.Validators.validate_create_menu_option_request()
            structured_data.Database.update_bulk(structured_data.Database.menu_options,
                                                 {"menu_id": request.json.get("menu_id"),
                                                  "position": {"$gte": request.json.get("position")}},
                                                 {"$inc": {"position": 1}})
            menu_option = menus.FactoryFuncs.create_menu_option(account_id=account_id, user_id=user_id,
                                                                menu_id=request.json.get("menu_id"),
                                                                demo_id=request.json.get("demo_id"),
                                                                title=request.json.get("title"),
                                                                position=request.json.get("position"),
                                                                action_type=request.json.get("action_type"),
                                                                flow_id=request.json.get("flow_id"),
                                                                redirect_url=request.json.get("redirect_url"))
        except AssertionError as ase:
            logging.Funcs.create_error_log(ase, account_id=account_id, user_id=user_id,
                                           component_id=request.json.get("menu_id"))
            return general.APIResponse.Error.get_response(ase, 401)
        except Exception as e:
            logging.Funcs.create_error_log(e, account_id=account_id, user_id=user_id,
                                           component_id=request.json.get("menu_id"))
            return general.APIResponse.Error.get_response(constants.APIResponse.Messages.BUSINESS_ERROR, 500)
        else:
            return make_response({constants.APIResponse.Fields.STATUS: constants.APIResponse.Statuses.SUCCESS,
                                  constants.APIResponse.Fields.MESSAGE: "menu option created",
                                  "menu_option": menu_option.as_json()}, 200)

    @staticmethod
    @logging.Funcs.log_func_call("update menu option")
    def update(account_id, user_id, menu_option_id):
        try:
            RequestUtils.Validators.validate_update_menu_option_request()
            menu_option = structured_data.Database.find_single(structured_data.Database.menu_options,
                                                               {"menu_option_id": menu_option_id}, {"_id": 0})
            assert menu_option, "invalid menu option"
            if request.json.get("position") is not None:
                structured_data.Database.update_bulk(structured_data.Database.menu_options,
                                                     {"menu_id": menu_option["menu_id"],
                                                      "position": {"$gt": menu_option["position"]}},
                                                     {"$inc": {"position": -1}})
                structured_data.Database.update_bulk(structured_data.Database.menu_options,
                                                     {"menu_id": menu_option["menu_id"],
                                                      "position": {"$gte": request.json.get("position")}},
                                                     {"$inc": {"position": 1}})
            structured_data.Database.update_single(structured_data.Database.menu_options,
                                                   {"menu_option_id": menu_option_id},
                                                   {"$set": {**request.json}})
        except AssertionError as ase:
            logging.Funcs.create_error_log(ase, account_id=account_id, user_id=user_id, component_id=menu_option_id)
            return general.APIResponse.Error.get_response(ase, 401)
        except Exception as e:
            logging.Funcs.create_error_log(e, account_id=account_id, user_id=user_id, component_id=menu_option_id)
            return general.APIResponse.Error.get_response(constants.APIResponse.Messages.BUSINESS_ERROR, 500)
        else:
            return make_response({constants.APIResponse.Fields.STATUS: constants.APIResponse.Statuses.SUCCESS,
                                  constants.APIResponse.Fields.MESSAGE: "menu option updated"}, 200)

    @staticmethod
    @logging.Funcs.log_func_call("delete menu option")
    def delete(account_id, user_id, menu_option_id):
        try:
            menu_option = structured_data.Database.find_single(structured_data.Database.menu_options,
                                                               {"menu_option_id": menu_option_id}, {"_id": 0})
            assert menu_option, "invalid menu option"
            structured_data.Database.delete_single(structured_data.Database.menu_options,
                                                   {"menu_option_id": menu_option_id})
            structured_data.Database.update_bulk(structured_data.Database.menu_options,
                                                 {"menu_id": menu_option["menu_id"],
                                                  "position": {"$gte": menu_option["position"]}},
                                                 {"$inc": {"position": -1}})
        except AssertionError as ase:
            logging.Funcs.create_error_log(ase, account_id=account_id, user_id=user_id, component_id=menu_option_id)
            return general.APIResponse.Error.get_response(ase, 401)
        except Exception as e:
            logging.Funcs.create_error_log(e, account_id=account_id, user_id=user_id, component_id=menu_option_id)
            return general.APIResponse.Error.get_response(constants.APIResponse.Messages.BUSINESS_ERROR, 500)
        else:
            return make_response({constants.APIResponse.Fields.STATUS: constants.APIResponse.Statuses.SUCCESS,
                                  constants.APIResponse.Fields.MESSAGE: "menu option deleted"}, 200)


class RequestUtils:
    class Validators:

        @staticmethod
        def validate_create_menu_request():
            assert "demo_id" in request.json, "demo_id missing from request body"
            assert not RequestUtils.Validators.__get_existing_menu_id(
                request.json.get("demo_id")), "menu already exists for the demo"
            assert "title" in request.json, "title missing from request body"
            assert "description" in request.json, "description missing from request body"
            assert "edit_state" in request.json, "edit_state missing from request body"

        @staticmethod
        def __get_existing_menu_id(demo_id):
            return (lambda record: record if record else {})(
                structured_data.Database.find_single(structured_data.Database.menus,
                                                     {"demo_id": demo_id}, {"_id": 0, "menu_id": 1})).get("menu_id",
                                                                                                          None)

        @staticmethod
        def validate_update_menu_request():
            assert len(set(list(request.json.keys())) - {"title", "description",
                                                         "edit_state"}) == 0, "invalid update field in request body"

        @staticmethod
        def validate_create_menu_option_request():
            assert "menu_id" in request.json, "menu_id missing from request body"
            assert "demo_id" in request.json, 'demo_id missing from request body'
            assert "title" in request.json, "title missing from request body"
            assert "action_type" in request.json, "action_type missing from request body"
            assert request.json.get(
                "action_type") in constants.MenuOptions.OptionTypes.all(), "invalid value of action_type"
            assert request.json.get("flow_id") or request.json.get("redirect_url"), "add either a flow or a redirection"
            assert 0 <= request.json.get("position") <= structured_data.Database.count(
                structured_data.Database.menu_options, {"menu_id": request.json.get("menu_id")}), "invalid position"

        @staticmethod
        def validate_update_menu_option_request():
            assert len(set(list(request.json.keys())) - {"title", "action_type", "flow_id", "redirect_url",
                                                         "position",
                                                         "menu_id"}) == 0, "invalid update field in request body"
            if request.json.get("position") is not None:
                assert 0 <= request.json.get("position") < structured_data.Database.count(
                    structured_data.Database.menu_options, {"menu_id": request.json.get("menu_id")}), "invalid position"

        @staticmethod
        def validate_fetch_menu_options_in_bulk_request():
            assert "menu_id" in request.args, "menu_id missing in the request arguments"
