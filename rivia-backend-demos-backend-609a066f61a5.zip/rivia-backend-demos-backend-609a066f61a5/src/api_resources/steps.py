from src.funcs import general
from src.components import logging, steps, structured_data, constants, unstructured_data, captures, configs
from flask import make_response, request


class Ops:

    @staticmethod
    @logging.Funcs.log_func_call("creating step")
    def create(account_id, user_id):
        try:
            if Utils.Validator.is_for_mobile_version():
                return Ops.create_for_mobile(account_id=account_id, user_id=user_id)
            Utils.Validator.validate_create_step_request()
            structured_data.Database.update_bulk(structured_data.Database.steps,
                                                 {"demo_id": request.json.get("demo_id"),
                                                  "flow_id": request.json.get("flow_id"),
                                                  "position": {"$gte": request.json.get("position")}},
                                                 {"$inc": {"position": 1}})
            step = steps.FactoryFuncs.create(account_id=account_id, user_id=user_id,
                                             demo_id=request.json.get("demo_id"),
                                             flow_id=request.json.get("flow_id"),
                                             position=request.json.get("position"),
                                             capture_id=request.json.get("capture_id"))
        except AssertionError as ase:
            logging.Funcs.create_error_log(ase, account_id=account_id, user_id=user_id,
                                           component_id=request.json.get("demo_id"))
            return general.APIResponse.Error.get_response(ase, 401)
        except Exception as e:
            logging.Funcs.create_error_log(e, account_id=account_id, user_id=user_id,
                                           component_id=request.json.get("demo_id"))
            return general.APIResponse.Error.get_response(constants.APIResponse.Messages.BUSINESS_ERROR, 500)
        else:
            return make_response({
                constants.APIResponse.Fields.STATUS: constants.APIResponse.Statuses.SUCCESS,
                constants.APIResponse.Fields.MESSAGE: "step created",
                "step": {
                    **step.as_json(),
                    "interactions": []
                }
            })

    @staticmethod
    @logging.Funcs.log_func_call("creating step for mobile version")
    def create_for_mobile(account_id, user_id):
        try:
            Utils.Validator.validate_create_step_mobile_version_request()
            structured_data.Database.update_or_add_single(structured_data.Database.published_steps,
                                                          {"step_id": request.json.get("step_id"),
                                                           "type": constants.Previews.MOBILE},
                                                          {**structured_data.Database.find_single(
                                                              structured_data.Database.steps,
                                                              {"step_id": request.json.get(
                                                                  "step_id")}, {"_id": 0}),
                                                           "type": constants.Previews.MOBILE})
        except AssertionError as ase:
            logging.Funcs.create_error_log(ase, account_id=account_id, user_id=user_id,
                                           component_id=request.json.get("step_id"))
            return general.APIResponse.Error.get_response(ase, 401)
        except Exception as e:
            logging.Funcs.create_error_log(e, account_id=account_id, user_id=user_id,
                                           component_id=request.json.get("step_id"))
            return general.APIResponse.Error.get_response(constants.APIResponse.Messages.BUSINESS_ERROR, 500)
        else:
            return make_response({constants.APIResponse.Fields.STATUS: constants.APIResponse.Statuses.SUCCESS,
                                  constants.APIResponse.Fields.MESSAGE: "step created"}, 200)

    @staticmethod
    @logging.Funcs.log_func_call("fetch single step")
    def fetch_single(account_id, user_id, step_id):
        try:
            step_details = structured_data.Database.find_single(structured_data.Database.steps,
                                                                {"step_id": step_id}, {"_id": 0})
            assert step_details, "invalid step id"
            capture_details = structured_data.Database.find_single(structured_data.Database.captures,
                                                                   {"capture_id": step_details["capture_id"]},
                                                                   {"_id": 0})
            interactions = structured_data.Database.find_bulk(structured_data.Database.interactions,
                                                              {"step_id": step_id}, {"_id": 0})
        except AssertionError as ase:
            logging.Funcs.create_error_log(ase, account_id=account_id, user_id=user_id, component_id=step_id)
            return general.APIResponse.Error.get_response(ase, 401)
        except Exception as e:
            logging.Funcs.create_error_log(e, account_id=account_id, user_id=user_id, component_id=step_id)
            return general.APIResponse.Error.get_response(constants.APIResponse.Messages.BUSINESS_ERROR, 500)
        else:
            return make_response({
                constants.APIResponse.Fields.STATUS: constants.APIResponse.Statuses.SUCCESS,
                constants.APIResponse.Fields.MESSAGE: "step retrieved",
                "step": {
                    **step_details,
                    "interactions": list(interactions),
                    "capture": {
                        **capture_details,
                        "html_url": unstructured_data.Database.generate_cdn_url(capture_details["path_html"]),
                        "image_url": unstructured_data.Database.generate_cdn_url(capture_details["path_image"])
                    }
                }
            }, 200)

    @staticmethod
    @logging.Funcs.log_func_call("deleting step")
    def delete(account_id, user_id, step_id):
        try:
            step_details = structured_data.Database.find_single(structured_data.Database.steps,
                                                                {"account_id": account_id, "step_id": step_id},
                                                                {"_id": 0, "demo_id": 1, "position": 1, "flow_id": 1})
            assert step_details, "invalid step id"
            structured_data.Database.delete_single(structured_data.Database.steps, {"step_id": step_id})
            structured_data.Database.delete_many(structured_data.Database.interactions, {"step_id": step_id})
            structured_data.Database.update_bulk(structured_data.Database.steps,
                                                 {"demo_id": step_details["demo_id"],
                                                  "flow_id": step_details["flow_id"],
                                                  "position": {"$gte": step_details["position"]}},
                                                 {"$inc": {"position": -1}})
        except AssertionError as ase:
            logging.Funcs.create_error_log(ase, account_id=account_id, user_id=user_id, component_id=step_id)
            return general.APIResponse.Error.get_response(ase, 401)
        except Exception as e:
            logging.Funcs.create_error_log(e, account_id=account_id, user_id=user_id, component_id=step_id)
            return general.APIResponse.Error.get_response(constants.APIResponse.Messages.BUSINESS_ERROR, 500)
        else:
            return make_response({
                constants.APIResponse.Fields.STATUS: constants.APIResponse.Statuses.SUCCESS,
                constants.APIResponse.Fields.MESSAGE: "step deleted"
            }, 200)

    @staticmethod
    @logging.Funcs.log_func_call("updating step")
    def update(account_id, user_id, step_id):
        try:
            Utils.Validator.validate_step_update_request()
            step_details = structured_data.Database.find_single(structured_data.Database.steps,
                                                                {"step_id": step_id}, {"_id": 0})
            assert step_details, "invalid step id"
            if request.json.get("position") is not None:
                assert 0 <= request.json.get("position") < structured_data.Database.count(
                    structured_data.Database.steps,
                    {"demo_id": step_details["demo_id"], "flow_id": step_details["flow_id"]}), "invalid step position"
                structured_data.Database.update_bulk(structured_data.Database.steps,
                                                     {"demo_id": step_details["demo_id"],
                                                      "flow_id": step_details["flow_id"],
                                                      "position": {"$gt": step_details["position"]}},
                                                     {"$inc": {"position": -1}})
                structured_data.Database.update_bulk(structured_data.Database.steps,
                                                     {"demo_id": step_details["demo_id"],
                                                      "flow_id": step_details["flow_id"],
                                                      "position": {"$gte": request.json.get("position")}},
                                                     {"$inc": {"position": 1}})
                structured_data.Database.update_single(structured_data.Database.steps,
                                                       {"step_id": step_id},
                                                       {"$set": {"position": request.json.get("position")}})
            if request.json.get("capture_id"):
                assert structured_data.Database.find_single(structured_data.Database.captures,
                                                            {"capture_id": request.json.get("capture_id")},
                                                            {"_id": 0}), "invalid capture id"
                # structured_data.Database.delete_many(structured_data.Database.interactions,
                #                                      {"step_id": step_id})
                # the following logic changes the element id of the interaction to null
                # interactions = list(structured_data.Database.find_bulk(structured_data.Database.interactions,
                #                                                        {"step_id": step_id}, {"_id": 0}))
                # for interaction in interactions:
                #     structured_data.Database.update_single(structured_data.Database.interactions,
                #                                            {"interaction_id": interaction['interaction_id']},
                #                                            {"$set": {"edit_state": {**interaction['edit_state'],
                #                                                                     'element_id': None,
                #                                                                     'element_type': None}}})
                structured_data.Database.update_single(structured_data.Database.steps,
                                                       {"step_id": step_id},
                                                       {"$set": {"capture_id": request.json.get("capture_id")}})
            if request.json.get("voiceover_text"):
                structured_data.Database.update_single(structured_data.Database.steps,
                                                       {"step_id": step_id},
                                                       {"$set": {
                                                           "voiceover_text": general.TextProcessor.remove_html_tags(
                                                               request.json.get("voiceover_text"))}})
            if request.json.get("voiceover_id"):
                structured_data.Database.update_single(structured_data.Database.steps,
                                                       {"step_id": step_id},
                                                       {"$set": {"voiceover_id": request.json.get("voiceover_id")}})
        except AssertionError as ase:
            logging.Funcs.create_error_log(ase, account_id=account_id, user_id=user_id, component_id=step_id)
            return general.APIResponse.Error.get_response(ase, 401)
        except Exception as e:
            logging.Funcs.create_error_log(e, account_id=account_id, user_id=user_id, component_id=step_id)
            return general.APIResponse.Error.get_response(constants.APIResponse.Messages.BUSINESS_ERROR, 500)
        else:
            return make_response({
                constants.APIResponse.Fields.STATUS: constants.APIResponse.Statuses.SUCCESS,
                constants.APIResponse.Fields.MESSAGE: "updated"
            }, 200)


class Utils:
    class Validator:
        @staticmethod
        def validate_create_step_request():
            assert request.json.get("demo_id"), "demo id missing from request body"
            assert request.json.get("flow_id"), "flow id missing from request body"
            assert request.json.get("position") is not None, "position missing from request body"
            assert request.json.get("capture_id"), "capture_id missing from request body"
            assert 0 <= request.json.get("position") <= structured_data.Database.count(
                structured_data.Database.steps, {"demo_id": request.json.get("demo_id"),
                                                 "flow_id": request.json.get("flow_id")}), "Invalid step position"

        @staticmethod
        def validate_step_update_request():
            assert request.json, "update request body missing"
            assert len(
                set(list(request.json.keys())) - {"position",
                                                  "capture_id", "voiceover_text",
                                                  "voiceover_id"}) == 0, "invalid update field in request body"
            if "voiceover_text" in request.json:
                assert request.json.get("voiceover_text"), "voiceover_text cannot be empty"

        @staticmethod
        def is_for_mobile_version():
            return request.args.get("type", None) == constants.Previews.MOBILE

        @staticmethod
        def validate_create_step_mobile_version_request():
            assert request.json.get("step_id"), "step_id missing from request body"
