from src.funcs import general
from src.components import logging, structured_data, constants
from flask import request, make_response


class Ops:

    @staticmethod
    @logging.Funcs.log_func_call("retrieving browser extension config")
    def fetch(account_id, user_id):
        try:
            config = structured_data.Database.find_single(structured_data.Database.browser_extension, {}, {"_id": 0})
        except Exception as e:
            logging.Funcs.create_error_log(e)
            return general.APIResponse.Error.get_response(constants.APIResponse.Messages.BUSINESS_ERROR, 500)
        else:
            return make_response({
                constants.APIResponse.Fields.STATUS: constants.APIResponse.Statuses.SUCCESS,
                constants.APIResponse.Fields.MESSAGE: "config retrieved",
                "config": {
                    **config
                }
            }, 200)
