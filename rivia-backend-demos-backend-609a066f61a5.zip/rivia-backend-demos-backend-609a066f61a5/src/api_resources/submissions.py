from src.funcs import general, search
from flask import request, make_response, Response
from src.components import submissions, logging, constants, structured_data
from io import StringIO
import csv


class Ops:

    @staticmethod
    @logging.Funcs.log_func_call("creating submission")
    def create():
        try:
            Utils.RequestValidator.validate_create()
            submissions.FactoryFuncs.create_submission(session_id=request.json.get("session_id"),
                                                       form_id=request.json.get("form_id"),
                                                       payload=request.json.get("payload"))
        except AssertionError as ase:
            logging.Funcs.create_error_log(ase, component_id=request.json.get("form_id"))
            return general.APIResponse.Error.get_response(ase, 401)
        except Exception as e:
            logging.Funcs.create_error_log(e, component_id=request.json.get("form_id"))
            return general.APIResponse.Error.get_response(constants.APIResponse.Messages.BUSINESS_ERROR, 500)
        else:
            return make_response({constants.APIResponse.Fields.STATUS: constants.APIResponse.Statuses.SUCCESS,
                                  constants.APIResponse.Fields.MESSAGE: "submission created"},
                                 200)

    @staticmethod
    @logging.Funcs.log_func_call("fetch submissions as csv")
    def fetch_as_csv(account_id, user_id):
        try:
            Utils.RequestValidator.validate_fetch()
            count = search.Ops.count(structured_data.Database.sessions,
                                     account_id=account_id,
                                     date_start=request.args.get("date_start"),
                                     date_end=request.args.get("date_end"),
                                     extra_constraints={"has_submission": True, "demo_id": request.args.get("demo_id")})
            session_results = list(search.Ops.fetch(structured_data.Database.sessions,
                                                    account_id=account_id,
                                                    page_number=0,
                                                    date_start=request.args.get("date_start"),
                                                    date_end=request.args.get("date_end"),
                                                    num_results=count,
                                                    extra_constraints={"has_submission": True,
                                                                       "demo_id": request.args.get("demo_id")},
                                                    projection={"_id": 0, "session_id": 1, "created_at": 1}))
            csv_data = Utils.Aggregator.aggregate_submissions_into_csv(
                structured_data.Database.find_bulk(structured_data.Database.submissions,
                                                   {"session_id": {
                                                       "$in": [_["session_id"] for _ in session_results]}},
                                                   {"_id": 0}).sort([("created_at", -1)]))
        except AssertionError as ase:
            logging.Funcs.create_error_log(ase, account_id=account_id, user_id=user_id,
                                           component_id=request.args.get("demo_id"))
            return general.APIResponse.Error.get_response(ase, 401)
        except Exception as e:
            logging.Funcs.create_error_log(e, account_id=account_id, user_id=user_id,
                                           component_id=request.args.get("demo_id"))
            return general.APIResponse.Error.get_response(constants.APIResponse.Messages.BUSINESS_ERROR, 500)
        else:
            return Response(csv_data, mimetype="text/csv",
                            headers={"Content-disposition": "attachment; filename=leads.csv"})

    @staticmethod
    @logging.Funcs.log_func_call("fetching submission")
    def fetch(account_id, user_id):
        if request.args.get("as", None) == "csv":
            return Ops.fetch_as_csv(account_id=account_id, user_id=user_id)
        try:
            Utils.RequestValidator.validate_fetch()
            session_results = list(search.Ops.fetch(structured_data.Database.sessions,
                                                    account_id=account_id,
                                                    page_number=int(request.args.get("page_number", 0)),
                                                    date_start=request.args.get("date_start"),
                                                    date_end=request.args.get("date_end"),
                                                    num_results=20,
                                                    extra_constraints={"has_submission": True,
                                                                       "demo_id": request.args.get("demo_id")},
                                                    projection={"_id": 0, "session_id": 1, "created_at": 1}))
            count = search.Ops.count(structured_data.Database.sessions,
                                     account_id=account_id,
                                     date_start=request.args.get("date_start"),
                                     date_end=request.args.get("date_end"),
                                     extra_constraints={"has_submission": True, "demo_id": request.args.get("demo_id")})
            submission_results, header = Utils.Aggregator.aggregate_submissions(
                structured_data.Database.find_bulk(structured_data.Database.submissions,
                                                   {"session_id": {
                                                       "$in": [_["session_id"] for _ in session_results]}},
                                                   {"_id": 0}).sort([("created_at", -1)]))
        except AssertionError as ase:
            logging.Funcs.create_error_log(ase, account_id=account_id, user_id=user_id,
                                           component_id=request.args.get("demo_id"))
            return general.APIResponse.Error.get_response(ase, 401)
        except Exception as e:
            logging.Funcs.create_error_log(e, account_id=account_id, user_id=user_id,
                                           component_id=request.args.get("demo_id"))
            return general.APIResponse.Error.get_response(constants.APIResponse.Messages.BUSINESS_ERROR, 500)
        else:
            return make_response({constants.APIResponse.Fields.STATUS: constants.APIResponse.Statuses.SUCCESS,
                                  constants.APIResponse.Fields.MESSAGE: "results fetched",
                                  "count": count,
                                  "header": header,
                                  "results": submission_results},
                                 200)


class Utils:
    class RequestValidator:

        @staticmethod
        def validate_create():
            assert request.json.get("session_id"), "session_id missing from request body"
            assert request.json.get("form_id"), "form_id missing from request body"
            assert request.json.get("payload"), "form submission payload missing from request body"

        @staticmethod
        def validate_fetch():
            assert request.args.get("demo_id"), "demo_id missing from argument list"

    class Aggregator:

        @staticmethod
        def aggregate_submissions(results):
            aggregated = {}
            header = {}
            for submission in results:
                if submission["session_id"] in aggregated:
                    aggregated[submission["session_id"]]["fields"] = {**aggregated[submission["session_id"]]["fields"],
                                                                      **{_["form_field_id"]: _ for _ in
                                                                         submission['payload']}}
                    header = {**header,
                              **{_["form_field_id"]: {"form_field_id": _["form_field_id"], "label": _["label"],
                                                      "field_type": _["field_type"]} for _ in
                                 submission['payload']}}
                else:
                    aggregated[submission["session_id"]] = {
                        "created_at": submission["created_at"],
                        "session_id": submission["session_id"],
                        "fields": {_["form_field_id"]: _ for _ in submission['payload']}
                    }
                    header = {**header,
                              **{_["form_field_id"]: {"form_field_id": _["form_field_id"], "label": _["label"],
                                                      "field_type": _["field_type"]} for _ in
                                 submission['payload']}}
            return list(aggregated.values()), list(header.values())

        @staticmethod
        def aggregate_submissions_into_csv(results):
            data, header = Utils.Aggregator.aggregate_submissions(results)
            csv_file = StringIO()
            csv_writer = csv.writer(csv_file, delimiter=",", quotechar="\"", quoting=csv.QUOTE_MINIMAL)
            csv_writer.writerow(["Date"] + [_["label"] for _ in header])
            keys = [_["form_field_id"] for _ in header]
            for row in data:
                csv_writer.writerow(
                    [row["created_at"]] + [row.get("fields", {}).get(key, {}).get("value", "") for key in keys])
            return csv_file.getvalue()
