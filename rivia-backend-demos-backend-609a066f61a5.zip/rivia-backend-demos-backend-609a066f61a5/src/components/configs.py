import os


class AWS:
    REGION_NAME = os.environ["AWS_REGION_NAME"]
    ACCESS_KEY = os.environ["AWS_ACCESS_KEY"]
    SECRET_KEY = os.environ["AWS_SECRET_KEY"]
    S3_BUCKET = os.environ["S3_BUCKET"]
    STATIC_CONTENT_BUCKET = os.environ["S3_STATIC_CONTENT_BUCKET"]
    THUMBNAIL_FUNCTION = os.environ["THUMBNAIL_FUNCTION"]
    CLOUDFRONT_STATIC_CONTENT = os.environ["CLOUDFRONT_STATIC_CONTENT"]
    CLOUDFRONT_DEMOS_BUCKET = os.environ["CLOUDFRONT_DEMOS_BUCKET"]
    CLOUDFRONT_DEMOS_DIST_ID = os.environ["CLOUDFRONT_DEMOS_DIST_ID"]
    CLONE_FILES_LAMBDA = os.environ["CLONE_FILES_LAMBDA"]
    PERSONALISE_DEMO_LAMBDA = os.environ["PERSONALISE_DEMO_LAMBDA"]


class Mongo:
    URI = os.environ["MONGO_URI"]
    DATABASE_NAME = os.environ["MONGO_DATABASE_NAME"]


class Firebase:
    CERTIFICATE_KEY = os.environ["FIREBASE_CERTIFICATE_KEY"]
    API_KEY = os.environ["FIREBASE_API_KEY"]


class Fogbender:
    SECRET_KEY = os.environ["FOGBENDER_SECRET_KEY"]


class Environment:
    TYPE = os.environ["ENV_TYPE"]
    API_URL = os.environ["API_URL"]


class IPData:
    API_KEY = os.environ["IPDATA_API_KEY"]


class Slack:
    ACTIVITY_CHANNEL = os.environ["SLACK_ACTIVITY_CHANNEL"]
    DEMO_CREATION = os.environ["SLACK_DEMO_CREATION"]


class Airtable:
    API_KEY = os.environ["AIRTABLE_API_KEY"]


class ElevenLabs:
    URL = "https://api.elevenlabs.io/v1/text-to-speech"
    MODEL_ID = "eleven_multilingual_v2"
    API_KEY = os.environ["ELEVENLABS_API_KEY"]


class Clearbit:
    URL = "https://logo.clearbit.com"
