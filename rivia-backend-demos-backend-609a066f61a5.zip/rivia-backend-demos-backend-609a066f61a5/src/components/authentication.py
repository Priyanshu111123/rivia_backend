from src.components import singleton, logging, constants, sessions, airtable
from src.funcs import general
from functools import partial, wraps
import requests
from firebase_admin import credentials, auth, initialize_app
import flask
import datetime
import json

CHECK_REVOKED = False
EXPIRES_IN = datetime.timedelta(days=14)
EXPIRES_IN_LONG_TERM = datetime.timedelta(days=3650)


class Authenticator(metaclass=singleton.Singleton):
    http_client = None
    sdk_client = None

    @classmethod
    def initialize(cls, api_key, credentials_payload):
        cls.http_client = FirebaseFuncs.HttpClient.get_client(api_key)
        cls.sdk_client = FirebaseFuncs.SdkClient.get_client(credentials_payload)

    @classmethod
    def sign_in(cls, email, password):
        return FirebaseFuncs.HttpClient.sign_in(cls.http_client, email, password)

    @classmethod
    def is_email_verified(cls, user_id):
        return FirebaseFuncs.SdkClient.is_email_verified(user_id=user_id)

    @classmethod
    def sign_up(cls, email, password):
        return FirebaseFuncs.HttpClient.sign_up(cls.http_client, email, password)

    @classmethod
    def send_verification_email(cls, id_token):
        return FirebaseFuncs.HttpClient.send_verification_email(cls.http_client, id_token=id_token)

    @classmethod
    def sign_out(cls, session_cookie):
        return FirebaseFuncs.SdkClient.sign_out(session_cookie)

    @classmethod
    def sign_assist(cls, email):
        return FirebaseFuncs.HttpClient.sign_assist(cls.http_client, email)

    @classmethod
    def verify_email(cls, user_id):
        return FirebaseFuncs.SdkClient.verify_email(user_id=user_id)

    @classmethod
    def verify_cookie(cls, cookie):
        return FirebaseFuncs.SdkClient.Cookies.verify(cookie)

    @classmethod
    def generate_cookie(cls, id_token):
        return FirebaseFuncs.SdkClient.Cookies.generate(id_token)

    @classmethod
    def delete_user(cls, user_id):
        return FirebaseFuncs.SdkClient.delete_user(user_id=user_id)

    @staticmethod
    def authenticate_api_request(f):
        @wraps(f)
        def wrapper(*args, **kwargs):
            if not flask.request.cookies.get("session"):
                logging.Funcs.create_error_log("missing authentication")
                return general.APIResponse.Error.get_response("missing authentication", 401)
            try:
                user_id = FirebaseFuncs.SdkClient.Cookies.verify(flask.request.cookies.get("session")).get("sub")
                # the following function will only be called when there is a valid user id.
                # the cached function should never be abused.
                account_id = general.Components.Users.get_details_by_user_id(user_id=user_id).get("account_id")
                kwargs["user_id"] = user_id
                kwargs["account_id"] = account_id
            except Exception as e:
                logging.Funcs.create_error_log(e)
                return general.APIResponse.Error.get_response("invalid/expired cookie", 401)
            else:
                return f(*args, **kwargs)

        return wrapper

    @staticmethod
    def add_cors_headers(f):
        @wraps(f)
        def wrapper(*args, **kwargs):
            if flask.request.method == "OPTIONS":
                # preflights
                logging.Logger.log("INFO", flask.request.referrer)
                return general.APIResponse.Headers.add_cors_headers(
                    flask.make_response({constants.APIResponse.Fields.STATUS: constants.APIResponse.Statuses.SUCCESS},
                                        200))
            else:
                # any general request method
                return general.APIResponse.Headers.add_cors_headers(f(*args, **kwargs))

        return wrapper

    @staticmethod
    def check_visitor(f):
        @wraps(f)
        def wrapper(*args, **kwargs):
            response = f(*args, **kwargs)
            session = sessions.FactoryFuncs.create_session(tracking_cookie=flask.request.cookies.get("visitor"),
                                                           account_cookie=flask.request.cookies.get("account"),
                                                           account_id=kwargs.get("account_id"),
                                                           demo_id=kwargs.get("demo_id"),
                                                           link_id=kwargs.get("link_id"),
                                                           ip_address=flask.request.environ.get('HTTP_X_FORWARDED_FOR',
                                                                                                ""),
                                                           email=flask.request.args.get("email", None),
                                                           title=response.get_json().get("demo", {}).get("title"),
                                                           is_session=flask.request.args.get(
                                                               "type") == constants.Previews.PLAYGROUND,
                                                           hubspotutk=flask.request.args.get('hubspotutk', None))
            # if general.Components.Accounts.get_details_by_account_id(session.account_id):
            #     if general.Components.Accounts.get_details_by_account_id(
            #             session.account_id).get("airtable_base_id"):
            #         airtable.Airtable.create_record(base_id=general.Components.Accounts.get_details_by_account_id(
            #             session.account_id).get("airtable_base_id"),
            #                                         table_id=general.Components.Accounts.get_details_by_account_id(
            #                                             session.account_id).get("airtable_sessions_table_id"),
            #                                         payload=session.as_airtable_record())
            response = general.APIResponse.Cookies.add_cookie_to_response(session_cookie=session.tracking_cookie,
                                                                          response=response,
                                                                          long_term=True,
                                                                          cookie_name="visitor")
            response = general.APIResponse.Cookies.add_cookie_to_response(session_cookie=session.account_id,
                                                                          response=response,
                                                                          long_term=True,
                                                                          cookie_name="account")
            response.data = json.dumps({**response.get_json(), "session_id": session.session_id})
            return response

        return wrapper


class FirebaseFuncs:
    class HttpClient:
        @staticmethod
        def get_client(api_key):
            return partial(FirebaseFuncs.HttpClient.__get_rest_api_func, api_key=api_key)

        @staticmethod
        def __get_rest_api_func(base_url, api_key, component, payload):
            return requests.post(f"{base_url}:{component}", params={"key": api_key}, json=payload)

        @staticmethod
        def sign_in(client, email, password):
            return client(base_url="https://identitytoolkit.googleapis.com/v1/accounts",
                          component="signInWithPassword",
                          payload={"email": email, "password": password, "returnSecureToken": True})

        @staticmethod
        def sign_up(client, email, password):
            return client(base_url="https://identitytoolkit.googleapis.com/v1/accounts",
                          component="signUp",
                          payload={"email": email, "password": password, "returnSecureToken": True})

        @staticmethod
        def send_verification_email(client, id_token):
            return client(base_url="https://identitytoolkit.googleapis.com/v1/accounts",
                          component="sendOobCode",
                          payload={"requestType": "VERIFY_EMAIL", "idToken": id_token})

        @staticmethod
        def sign_assist(client, email):
            return client(base_url="https://identitytoolkit.googleapis.com/v1/accounts",
                          component="sendOobCode",
                          payload={"email": email, "requestType": "PASSWORD_RESET"})

    class SdkClient:
        @staticmethod
        def get_client(credentials_payload):
            return FirebaseFuncs.SdkClient.__initialize_sdk_client(
                FirebaseFuncs.SdkClient.__authenticate_sdk_client(credentials_payload))

        @staticmethod
        def __authenticate_sdk_client(credentials_payload):
            return credentials.Certificate(credentials_payload)

        @staticmethod
        def __initialize_sdk_client(creds):
            return initialize_app(creds)

        @staticmethod
        def get_user_details(user_id):
            return auth.get_user(uid=user_id)

        @staticmethod
        def sign_out(session_cookie):
            auth.revoke_refresh_tokens(auth.verify_session_cookie(session_cookie).get("sub"))

        @staticmethod
        def verify_email(user_id):
            auth.update_user(uid=user_id, email_verified=True)

        @staticmethod
        def is_email_verified(user_id):
            return auth.get_user(uid=user_id).email_verified

        @staticmethod
        def delete_user(user_id):
            return auth.delete_user(uid=user_id)

        class Cookies:
            @staticmethod
            def verify(cookie):
                return auth.verify_session_cookie(cookie, check_revoked=CHECK_REVOKED)

            @staticmethod
            def generate(id_token):
                return auth.create_session_cookie(id_token, expires_in=EXPIRES_IN)
