from src.components import singleton, configs
import boto3
import time


class CDN(metaclass=singleton.Singleton):
    client = None

    @classmethod
    def initialize(cls, region_name, access_key, secret_key):
        cls.client = CloudfrontFuncs.get_client(region_name=region_name, access_key=access_key, secret_key=secret_key)

    @classmethod
    def invalidate_cache(cls, paths):
        return CloudfrontFuncs.invalidate_cache(cls.client, [f"/{_}" for _ in paths])


class CloudfrontFuncs:

    @staticmethod
    def get_client(region_name, access_key, secret_key):
        return boto3.client("cloudfront", region_name=region_name, aws_access_key_id=access_key,
                            aws_secret_access_key=secret_key)

    @staticmethod
    def invalidate_cache(client, paths):
        return client.create_invalidation(
            DistributionId=configs.AWS.CLOUDFRONT_DEMOS_DIST_ID,
            InvalidationBatch={
                'Paths': {
                    'Quantity': len(paths),
                    'Items': paths
                },
                'CallerReference': str(time.time()).replace(".", "")
            }
        )
