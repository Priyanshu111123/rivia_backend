from src.components import structured_data
from src.funcs import general


class Menu(object):

    def __init__(self, account_id, user_id, demo_id, title, description, edit_state):
        self.account_id = account_id
        self.user_id = user_id
        self.menu_id = general.Identifiers.generate_menu_id()
        self.demo_id = demo_id
        self.created_at = general.Time.get_current_time()
        self.updated_at = general.Time.get_current_time()
        self.title = title
        self.description = description
        self.edit_state = edit_state

    def as_json(self):
        return {
            "account_id": self.account_id,
            "user_id": self.user_id,
            "menu_id": self.menu_id,
            "demo_id": self.demo_id,
            "created_at": self.created_at,
            "updated_at": self.updated_at,
            "title": self.title,
            "description": self.description,
            "edit_state": self.edit_state
        }


class MenuOption(object):

    def __init__(self, account_id, user_id, menu_id, demo_id, title, position, action_type, flow_id=None,
                 redirect_url=None):
        self.account_id = account_id
        self.user_id = user_id
        self.menu_option_id = general.Identifiers.generate_menu_option_id()
        self.created_at = general.Time.get_current_time()
        self.updated_at = general.Time.get_current_time()
        self.menu_id = menu_id
        self.demo_id = demo_id
        self.title = title
        self.position = position
        self.action_type = action_type
        self.flow_id = flow_id
        self.redirect_url = redirect_url

    def as_json(self):
        return {
            "account_id": self.account_id,
            "user_id": self.user_id,
            "menu_option_id": self.menu_option_id,
            "created_at": self.created_at,
            "updated_at": self.updated_at,
            "menu_id": self.menu_id,
            "demo_id": self.demo_id,
            "title": self.title,
            "position": self.position,
            "action_type": self.action_type,
            "flow_id": self.flow_id,
            "redirect_url": self.redirect_url
        }


class FactoryFuncs:

    @staticmethod
    def create_menu(account_id, user_id, demo_id, title, description, edit_state):
        menu = Menu(account_id=account_id, user_id=user_id, demo_id=demo_id, title=title, description=description,
                    edit_state=edit_state)
        structured_data.Database.add_single(structured_data.Database.menus,
                                            menu.as_json())
        # structured_data.Database.update_single(structured_data.Database.demos, {"demo_id": demo_id},
        #                                        {"$set": {"menu_id": menu.menu_id}})
        return menu

    @staticmethod
    def create_menu_option(account_id, user_id, menu_id, demo_id, title, position, action_type,
                           flow_id=None, redirect_url=None):
        menu_option = MenuOption(account_id=account_id, user_id=user_id, menu_id=menu_id, demo_id=demo_id, title=title,
                                 position=position, action_type=action_type, flow_id=flow_id, redirect_url=redirect_url)
        structured_data.Database.add_single(structured_data.Database.menu_options,
                                            menu_option.as_json())
        return menu_option
