from src.components import singleton
import boto3
import json


class LambdaExecutor(metaclass=singleton.Singleton):
    client = None

    @classmethod
    def initialize(cls, region_name, access_key, secret_key):
        cls.client = AWSFunc.get_connection(region_name=region_name, access_key=access_key, secret_key=secret_key)

    @classmethod
    def add_job(cls, function_name, message_body, sync=False):
        return AWSFunc.add_job(cls.client, function_name=function_name, message_body=message_body, sync=sync)

    @staticmethod
    def get_job_status(response):
        return AWSFunc.get_job_status(response)


class AWSFunc:

    @staticmethod
    def get_connection(region_name, access_key, secret_key):
        return boto3.client("lambda", aws_access_key_id=access_key, aws_secret_access_key=secret_key,
                            region_name=region_name)

    @staticmethod
    def add_job(client, function_name, message_body, sync):
        return client.invoke(FunctionName=function_name,
                             InvocationType="Event" if not sync else "RequestResponse",
                             LogType="None",
                             Payload=json.dumps(message_body))

    @staticmethod
    def get_job_status(response):
        return response.get("ResponseMetadata", {}).get('HTTPStatusCode')
