from src.components import singleton, configs
import boto3
from botocore import config
import os


class Database(metaclass=singleton.Singleton):
    client = None

    @classmethod
    def initialize(cls, region_name, access_key, secret_key):
        cls.client = S3Funcs.get_client(region_name=region_name, access_key=access_key, secret_key=secret_key)

    @classmethod
    def generate_cdn_url(cls, path):
        if path:
            return S3Funcs.generate_cloudfront_url(path)
        else:
            return None

    @classmethod
    def generate_download_url(cls, path):
        if not path:
            return ""
        return S3Funcs.generate_download_pre_signed_url(cls.client, bucket_name=configs.AWS.S3_BUCKET, path=path,
                                                        expires_in=36000)

    @classmethod
    def generate_upload_url(cls, path, bucket_name):
        return S3Funcs.generate_upload_pre_signed_url(cls.client, bucket_name=bucket_name, path=path,
                                                      expires_in=36000)

    @classmethod
    def delete(cls, path):
        return S3Funcs.delete(cls.client, bucket_name=configs.AWS.S3_BUCKET, path=path)

    @classmethod
    def upload(cls, path, file_content, extra_args=None, bucket_name=None):
        return S3Funcs.upload(cls.client, bucket_name=configs.AWS.S3_BUCKET if not bucket_name else bucket_name,
                              path=path, file_content=file_content,
                              extra_args=extra_args)

    @classmethod
    def download(cls, path, file_content, extra_args=None, bucket_name=None):
        return S3Funcs.download(cls.client, bucket_name=configs.AWS.S3_BUCKET if not bucket_name else bucket_name,
                                path=path, file_content=file_content,
                                extra_args=extra_args)

    @classmethod
    def copy(cls, src_path, dst_path):
        return S3Funcs.copy(cls.client, bucket_name=configs.AWS.S3_BUCKET, src_path=src_path, dst_path=dst_path)


class S3Funcs:

    @staticmethod
    def get_client(region_name, access_key, secret_key):
        return boto3.client("s3", region_name=region_name, aws_access_key_id=access_key,
                            aws_secret_access_key=secret_key,
                            config=config.Config(
                                s3={
                                    'use_accelerate_endpoint': True
                                }
                            )
                            )

    @staticmethod
    def generate_cloudfront_url(path):
        return os.path.join(configs.AWS.CLOUDFRONT_DEMOS_BUCKET, path)

    @staticmethod
    def generate_download_pre_signed_url(client, bucket_name, path, expires_in):
        return client.generate_presigned_url("get_object", Params={"Bucket": bucket_name, "Key": path},
                                             ExpiresIn=expires_in)

    @staticmethod
    def generate_upload_pre_signed_url(client, bucket_name, path, expires_in):
        return client.generate_presigned_url("put_object", Params={"Bucket": bucket_name, "Key": path},
                                             ExpiresIn=expires_in)

    @staticmethod
    def delete(client, bucket_name, path):
        return client.delete_object(Bucket=bucket_name, Key=path)

    @staticmethod
    def upload(client, bucket_name, path, file_content, extra_args=None):
        if extra_args:
            return client.upload_fileobj(file_content, bucket_name, Key=path, ExtraArgs=extra_args)
        return client.upload_fileobj(file_content, bucket_name, Key=path)

    @staticmethod
    def download(client, bucket_name, path, file_content, extra_args=None):
        if extra_args:
            return client.download_fileobj(bucket_name, path, file_content, ExtraArgs=extra_args)
        return client.download_fileobj(bucket_name, path, file_content)

    @staticmethod
    def copy(client, bucket_name, src_path, dst_path):
        return client.copy({"Bucket": bucket_name, "Key": src_path}, bucket_name, dst_path)
