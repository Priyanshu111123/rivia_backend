from src.funcs import general
from src.components import structured_data


class Form(object):

    def __init__(self, account_id, user_id, edit_state):
        self.form_id = general.Identifiers.generate_form_id()
        self.account_id = account_id
        self.user_id = user_id
        self.created_at = general.Time.get_current_time()
        self.updated_at = general.Time.get_current_time()
        self.title = "Untitled Form"
        self.edit_state = edit_state

    def as_json(self):
        return {
            "form_id": self.form_id,
            "account_id": self.account_id,
            "user_id": self.user_id,
            "created_at": self.created_at,
            "updated_at": self.updated_at,
            "title": self.title,
            "edit_state": self.edit_state,
        }


class FormField(object):

    def __init__(self, account_id, user_id, form_id, position, field_type, edit_state):
        self.form_field_id = general.Identifiers.generate_form_field_id()
        self.account_id = account_id
        self.user_id = user_id
        self.form_id = form_id
        self.position = position
        self.field_type = field_type
        self.edit_state = edit_state

    def as_json(self):
        return {
            "form_field_id": self.form_field_id,
            "account_id": self.account_id,
            "user_id": self.user_id,
            "form_id": self.form_id,
            "field_type": self.field_type,
            "position": self.position,
            "edit_state": self.edit_state
        }


class FactoryFuncs:

    @staticmethod
    def create_form(account_id, user_id, edit_state):
        form = Form(account_id=account_id, user_id=user_id, edit_state=edit_state)
        structured_data.Database.add_single(structured_data.Database.forms, form.as_json())
        return form

    @staticmethod
    def create_form_field(account_id, user_id, form_id, field_type, edit_state, position):
        form_field = FormField(account_id=account_id, user_id=user_id, form_id=form_id, field_type=field_type,
                               edit_state=edit_state, position=position)
        structured_data.Database.add_single(structured_data.Database.form_fields, form_field.as_json())
        return form_field
