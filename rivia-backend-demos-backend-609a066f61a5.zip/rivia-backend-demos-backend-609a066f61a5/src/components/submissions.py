from src.funcs import general
from src.components import structured_data


class FormSubmission(object):

    def __init__(self, session_id, form_id, payload):
        self.submission_id = general.Identifiers.generate_submission_id()
        self.session_id = session_id
        self.form_id = form_id
        self.payload = payload
        self.created_at = general.Time.get_current_time()

    def as_json(self):
        return {
            "submission_id": self.submission_id,
            "session_id": self.session_id,
            "form_id": self.form_id,
            "payload": self.payload,
            "created_at": self.created_at
        }


class FactoryFuncs:

    @staticmethod
    def create_submission(session_id, form_id, payload):
        structured_data.Database.update_single(structured_data.Database.sessions,
                                               {"session_id": session_id}, {"$set": {"has_submission": True}})
        form_submission = FormSubmission(session_id=session_id, form_id=form_id, payload=payload)
        structured_data.Database.add_single(structured_data.Database.submissions,
                                            form_submission.as_json())
        return form_submission
