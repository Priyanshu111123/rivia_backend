from src.funcs import general
from src.components import structured_data, visitors, iplocator, logging, alerts


class Session(object):

    def __init__(self, account_id, demo_id, link_id, ip_address, tracking_cookie, account_cookie, email=None,
                 is_session=False, hubspotutk=None):
        self.account_id = account_id
        self.demo_id = demo_id
        self.link_id = link_id
        if link_id:
            link_details = Utils.get_link_details(link_id)
            if link_details:
                self.account_id = link_details.get("account_id")
                self.demo_id = link_details.get("demo_id")
        self.ip_address = ip_address
        # if email:
        #     self.add_location()
        self.session_id = general.Identifiers.generate_session_id()
        self.tracking_cookie = tracking_cookie
        self.account_cookie = account_cookie
        self.email = email
        visitor_details = Utils.get_visitor(self.account_id, self.tracking_cookie)
        existing_visitor_details = Utils.get_visitor(self.account_cookie, self.tracking_cookie)
        if not visitor_details:
            visitor = visitors.Visitor(account_id=account_id)
            if existing_visitor_details:
                visitor.tracking_cookie = existing_visitor_details.get("tracking_cookie")
            structured_data.Database.add_single(structured_data.Database.visitors, visitor.as_json())
            self.tracking_cookie = visitor.tracking_cookie
            visitor_details = visitor.as_json()

        # structured_data.Database.update_single(structured_data.Database.demos,
        #                                        {"demo_id": demo_id},
        #                                        {"$inc": {"num_views": 1}})
        # structured_data.Database.update_bulk(structured_data.Database.published_demos,
        #                                      {"demo_id": demo_id},
        #                                      {"$inc": {"num_views": 1}})
        self.visitor_id = visitor_details.get("visitor_id")
        self.created_at = general.Time.get_current_time()
        self.aggregation_status = "PENDING"
        self.log = []
        self.is_session = is_session
        if email:
            self.is_session = True
        self.hubspotutk = hubspotutk

    def add_location(self):
        try:
            self.ip_address = iplocator.Locator.get_location(self.ip_address)
        except Exception as e:
            logging.Funcs.create_error_log(e, account_id=self.account_id, component_id=self.demo_id)

    def as_json(self):
        return {
            "session_id": self.session_id,
            "visitor_id": self.visitor_id,
            "account_id": self.account_id,
            "demo_id": self.demo_id,
            "link_id": self.link_id,
            "email": self.email,
            "ip_address": self.ip_address,
            "created_at": self.created_at,
            "aggregation_status": self.aggregation_status,
            "log": self.log,
            "is_session": self.is_session,
            "hubspotutk": self.hubspotutk
        }

    def as_airtable_record(self):
        return {
            "session_id": self.session_id,
            "visitor_id": self.visitor_id,
            "demo_id": self.demo_id,
            "email": self.email,
            "ip_address": self.ip_address,
            "created_at": self.created_at,
        }


class SessionLog(object):

    def __init__(self, session_id, session_log):
        self.session_id = session_id
        self.session_log = session_log
        self.created_at = general.Time.get_current_time()

    def as_json(self):
        return {
            "session_id": self.session_id,
            "created_at": self.created_at,
            "log": self.session_log
        }

    def as_airtable_record(self):
        return {
            "session_id": self.session_id,
            "created_at": self.created_at,
            "type": self.session_log.get("type"),
            "step": int(self.session_log.get("step")),
            "total_steps": int(self.session_log.get("total_steps"))
        }


class FactoryFuncs:

    @staticmethod
    def create_session(account_id, demo_id, link_id, ip_address, tracking_cookie, account_cookie, email=None,
                       title=None,
                       is_session=False, hubspotutk=None):
        session = Session(account_id=account_id, demo_id=demo_id, link_id=link_id, ip_address=ip_address,
                          tracking_cookie=tracking_cookie, account_cookie=account_cookie, email=email,
                          is_session=is_session, hubspotutk=hubspotutk)
        structured_data.Database.add_single(structured_data.Database.sessions,
                                            session.as_json())
        if email:
            alerts.SlackAlert.demo_view(email=session.email, location=session.ip_address, session_id=session.session_id,
                                        title=title)
        return session


class Utils:
    @staticmethod
    def get_visitor(account_id, tracking_cookie):
        if tracking_cookie and account_id:
            return structured_data.Database.find_single(structured_data.Database.visitors,
                                                        {"account_id": account_id,
                                                         "tracking_cookie": tracking_cookie}, {"_id": 0})
        else:
            return None

    @staticmethod
    def get_link_details(link_id):
        return structured_data.Database.find_single(structured_data.Database.links, {"link_id": link_id}, {"_id": 0})
