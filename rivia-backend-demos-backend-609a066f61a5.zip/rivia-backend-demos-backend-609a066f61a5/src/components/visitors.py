from src.funcs import general


class Visitor(object):

    def __init__(self, account_id):
        self.visitor_id = general.Identifiers.generate_visitor_id()
        self.account_id = account_id
        self.tracking_cookie = general.Identifiers.generate_visitor_tracking_cookie_string()
        self.created_at = general.Time.get_current_time()
        self.details = {}

    def as_json(self):
        return {
            "visitor_id": self.visitor_id,
            "account_id": self.account_id,
            "tracking_cookie": self.tracking_cookie,
            "created_at": self.created_at,
            "details": self.details
        }
