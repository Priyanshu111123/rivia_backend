from src.components import structured_data
from src.funcs import general
import json


class DemoCloner(object):

    def __init__(self, account_id, user_id, source_demo_id):
        self.account_id = account_id
        self.user_id = user_id
        self.demo_id = general.Identifiers.generate_demo_id()
        self.source_demo_id = source_demo_id
        self.source = {}
        self.id_mappings = {}
        self.copy_ops = []

    def set_source(self):
        self.source["demo"] = structured_data.Database.find_single(structured_data.Database.demos,
                                                                   {"demo_id": self.source_demo_id}, {"_id": 0})
        self.source["menu"] = structured_data.Database.find_single(structured_data.Database.menus,
                                                                   {"demo_id": self.source_demo_id}, {"_id": 0})
        self.source["menu_options"] = list(structured_data.Database.find_bulk(structured_data.Database.menu_options,
                                                                              {"demo_id": self.source_demo_id},
                                                                              {"_id": 0}))
        self.source["flows"] = list(structured_data.Database.find_bulk(structured_data.Database.flows,
                                                                       {"demo_id": self.source_demo_id}, {"_id": 0}))
        self.source["steps"] = list(structured_data.Database.find_bulk(structured_data.Database.steps,
                                                                       {"demo_id": self.source_demo_id}, {"_id": 0}))
        self.source["captures"] = list(structured_data.Database.find_bulk(structured_data.Database.captures,
                                                                          {"demo_id": self.source_demo_id}, {"_id": 0}))
        self.source["interactions"] = list(structured_data.Database.find_bulk(structured_data.Database.interactions,
                                                                              {"demo_id": self.source_demo_id},
                                                                              {"_id": 0}))
        self.source["connections"] = list(structured_data.Database.find_bulk(structured_data.Database.connections,
                                                                             {"demo_id": self.source_demo_id},
                                                                             {"_id": 0}))
        self.source["redirects"] = list(structured_data.Database.find_bulk(structured_data.Database.redirects,
                                                                           {"demo_id": self.source_demo_id},
                                                                           {"_id": 0}))

    def update_ids(self):
        self.id_mappings = {**self.__get_menu_mapping(), **self.__get_menu_options_mapping(),
                            **self.__get_flows_mapping(), **self.__get_steps_mapping(),
                            **self.__get_captures_mapping(), **self.__get_interactions_mapping(),
                            **self.__get_connections_mapping(),
                            **self.__get_redirect_mapping()}

    def modify_demo(self):
        if self.source["demo"].get("path_thumbnail"):
            self.copy_ops.append({"src": self.source["demo"].get("path_thumbnail"),
                                  "dst": self.__get_new_object_path(self.source['demo'].get('path_thumbnail'),
                                                                    object_type="thumbnail")})
        self.source["demo"] = {
            **self.source["demo"],
            "demo_id": self.demo_id,
            "title": f"{self.source['demo'].get('title', '')} (Copy)",
            "num_views": 0,
            "average_percentage_completion": 0.0,
            "total_time_spent": 0,
            "user_id": self.user_id,
            "created_at": general.Time.get_current_time(),
            "updated_at": general.Time.get_current_time(),
            "menu_id": self.id_mappings[self.source["demo"].get("menu_id")] if self.source["demo"].get(
                "menu_id") else None,
            "path_thumbnail": self.__get_new_object_path(self.source['demo'].get('path_thumbnail'),
                                                         object_type="thumbnail")
        }

    def modify_menu(self):
        if not self.source["menu"]:
            return
        self.source["menu"] = {
            **self.source["menu"],
            "menu_id": self.id_mappings[self.source['menu'].get("menu_id")],
            "demo_id": self.demo_id,
            "edit_state": {
                **self.source["menu"].get("edit_state", {}),
                "start_workflow": self.id_mappings[self.source["menu"].get("edit_state", {}).get("start_workflow")] if
                self.source["menu"].get("edit_state", {}).get("start_workflow") else None
            }
        }

    def modify_menu_options(self):
        self.source["menu_options"] = [{**_,
                                        "menu_option_id": self.id_mappings[_['menu_option_id']],
                                        "demo_id": self.demo_id,
                                        "flow_id": self.id_mappings[_["flow_id"]] if _["flow_id"] else None} for _
                                       in
                                       self.source["menu_options"]]

    def modify_flows(self):
        self.source["flows"] = [{**_,
                                 "demo_id": self.demo_id,
                                 "flow_id": self.id_mappings[_["flow_id"]]} for _ in self.source["flows"]]

    def modify_steps(self):
        self.source["steps"] = [{**_,
                                 "step_id": self.id_mappings[_["step_id"]],
                                 "demo_id": self.demo_id,
                                 "flow_id": self.id_mappings[_["flow_id"]],
                                 "capture_id": self.id_mappings[_["capture_id"]]} for _ in self.source["steps"]]

    def modify_captures(self):
        self.copy_ops += [{"src": _["path_html"], "dst": self.__get_new_object_path(_["path_html"], object_type="html")}
                          for _ in self.source["captures"] if _["path_html"]]
        self.copy_ops += [
            {"src": _["path_image"], "dst": self.__get_new_object_path(_["path_image"], object_type="image")}
            for _ in self.source["captures"] if _["path_image"]]
        self.copy_ops += [
            {"src": _["path_thumbnail"],
             "dst": self.__get_new_object_path(_["path_thumbnail"], object_type="thumbnail")}
            for _ in self.source["captures"] if _["path_thumbnail"]]
        self.source["captures"] = [{**_,
                                    "capture_id": self.id_mappings[_["capture_id"]],
                                    "demo_id": self.demo_id,
                                    "path_html": self.__get_new_object_path(_["path_html"], object_type="html"),
                                    "path_image": self.__get_new_object_path(_["path_image"], object_type="image"),
                                    "path_thumbnail": self.__get_new_object_path(_["path_thumbnail"],
                                                                                 object_type="thumbnail")} for _
                                   in self.source["captures"]]

    def modify_interactions(self):
        self.source["interactions"] = [{**_,
                                        "interaction_id": self.id_mappings[_["interaction_id"]],
                                        "demo_id": self.demo_id,
                                        "step_id": self.id_mappings[_["step_id"]]} for _ in self.source["interactions"]]

    def modify_connections(self):
        self.source["connections"] = [{**_,
                                       "connection_id": self.id_mappings[_["connection_id"]],
                                       "demo_id": self.demo_id,
                                       "src_capture_id": self.id_mappings[_["src_capture_id"]],
                                       "dst_capture_id": self.id_mappings[_["dst_capture_id"]]} for _ in
                                      self.source["connections"]]

    def modify_redirects(self):
        self.source["redirects"] = [{**_,
                                     "redirect_id": self.id_mappings[_["redirect_id"]],
                                     "demo_id": self.demo_id,
                                     "capture_id": self.id_mappings[_["capture_id"]]} for _ in
                                    self.source["redirects"]]

    def add_to_database(self):
        structured_data.Database.add_single(structured_data.Database.demos, self.source["demo"])
        structured_data.Database.add_single(structured_data.Database.menus, self.source["menu"])
        structured_data.Database.add_bulk(structured_data.Database.menu_options, self.source["menu_options"])
        structured_data.Database.add_bulk(structured_data.Database.flows, self.source["flows"])
        structured_data.Database.add_bulk(structured_data.Database.steps, self.source["steps"])
        structured_data.Database.add_bulk(structured_data.Database.captures, self.source["captures"])
        structured_data.Database.add_bulk(structured_data.Database.interactions, self.source["interactions"])
        structured_data.Database.add_bulk(structured_data.Database.connections, self.source["connections"])
        structured_data.Database.add_bulk(structured_data.Database.redirects, self.source["redirects"])

    def __get_new_object_path(self, path, object_type):
        assert object_type in {"thumbnail", "image", "html"}
        return f"{self.account_id}/{self.demo_id}/{self.id_mappings[path.split('/')[-2]]}/{object_type}" if path else None

    def __get_menu_mapping(self):
        return {self.source.get("menu")["menu_id"]: general.Identifiers.generate_menu_id()} if self.source.get(
            "menu") else {}

    def __get_menu_options_mapping(self):
        return {_["menu_option_id"]: general.Identifiers.generate_menu_option_id() for _ in
                self.source.get("menu_options", [])}

    def __get_flows_mapping(self):
        return {_["flow_id"]: general.Identifiers.generate_flow_id() for _ in self.source.get("flows", [])}

    def __get_steps_mapping(self):
        return {_["step_id"]: general.Identifiers.generate_step_id() for _ in self.source.get("steps", [])}

    def __get_captures_mapping(self):
        return {_["capture_id"]: general.Identifiers.generate_capture_id() for _ in self.source.get("captures", [])}

    def __get_interactions_mapping(self):
        return {_["interaction_id"]: general.Identifiers.generate_interaction_id() for _ in
                self.source.get("interactions", [])}

    def __get_connections_mapping(self):
        return {_["connection_id"]: general.Identifiers.generate_connection_id() for _ in
                self.source.get("connections", [])}

    def __get_redirect_mapping(self):
        return {_["redirect_id"]: general.Identifiers.generate_redirect_id() for _ in
                self.source.get("redirects", [])}
