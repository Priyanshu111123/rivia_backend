class Logging:
    DEBUG = "DEBUG"
    INFO = "INFO"
    WARNING = "WARNING"
    ERROR = "ERROR"
    CRITICAL = "CRITICAL"

    @staticmethod
    def all():
        return {
            Logging.DEBUG, Logging.INFO, Logging.WARNING, Logging.ERROR, Logging.CRITICAL
        }


class Previews:
    WEB = "web"
    MOBILE = "mobile"
    PLAYGROUND = "playground"

    @classmethod
    def all(cls):
        return {
            Previews.WEB, Previews.MOBILE, Previews.PLAYGROUND
        }


class API:
    class Headers:
        AUTH_FIELD = "X-Rivia-Internal-Passcode"


class Demos:
    class DemoTypes:
        LINEAR = "LINEAR"
        PLAYGROUND = "PLAYGROUND"

        @staticmethod
        def all():
            return {Demos.DemoTypes.LINEAR, Demos.DemoTypes.PLAYGROUND}


class Data:
    class Structured:
        ACCOUNTS = "accounts"
        USERS = "users"
        DEMOS = "demos"
        STEPS = "steps"
        CAPTURES = "captures"
        INTERACTIONS = "interactions"
        VISITORS = "visitors"
        SESSIONS = "sessions"
        BROWSER_EXTENSION = "browser_extension"
        FORMS = "forms"
        FORM_FIELDS = "form_fields"
        PUBLISHED_DEMOS = "published_demos"
        PUBLISHED_CAPTURES = "published_captures"
        PUBLISHED_STEPS = "published_steps"
        PUBLISHED_INTERACTIONS = "published_interactions"
        PUBLISHED_MENUS = "published_menus"
        PUBLISHED_MENU_OPTIONS = "published_menu_options"
        SUBMISSIONS = "submissions"
        MENUS = "menus"
        MENU_OPTIONS = "menu_options"
        FLOWS = "flows"
        PUBLISHED_FLOWS = "published_flows"
        CONNECTIONS = "connections"
        PUBLISHED_CONNECTIONS = "published_connections"
        SPEAKERS = "speakers"
        VOICEOVERS = "voiceovers"
        PUBLISHED_VOICEOVERS = "published_voiceovers"
        PERSONALISED_DEMOS = "personalised_demos"
        LINKS = "links"
        REDIRECTS = "redirects"
        PUBLISHED_REDIRECTS = "published_redirects"
        THEMES = "themes"

    class FormFields:
        SHORT_TEXT = "SHORT_TEXT"
        LONG_TEXT = "LONG_TEXT"
        EMAIL = "EMAIL"
        PHONE = "PHONE"
        NUMBER = "NUMBER"
        DATETIME = "DATETIME"
        CHECKBOX = "CHECKBOX"
        SINGLE_SELECT = "SINGLE_SELECT"
        MULTI_SELECT = "MULTI_SELECT"
        DROPDOWN = "DROPDOWN"
        RICH_TEXT = "RICH_TEXT"

        @classmethod
        def all(cls):
            return {
                cls.SHORT_TEXT, cls.LONG_TEXT, cls.EMAIL, cls.PHONE, cls.NUMBER, cls.DATETIME, cls.CHECKBOX,
                cls.SINGLE_SELECT, cls.MULTI_SELECT, cls.DROPDOWN, cls.RICH_TEXT
            }


class APIResponse:
    class Fields:
        STATUS = "status"
        MESSAGE = "message"

    class Statuses:
        SUCCESS = "SUCCESS"
        FAILURE = "FAILURE"

    class Messages:
        BUSINESS_ERROR = "business error"


class Environment:
    PRODUCTION = "production"
    DEVELOPMENT = "development"


class Interactions:
    MODAL = "MODAL"
    TOOLTIP = "TOOLTIP"
    FORM = "FORM"
    IFRAME = "IFRAME"
    RECORDING = "RECORDING"
    IMAGE_MODAL = "IMAGE_MODAL"

    class SubType:
        CLICK = "CLICK"
        KEYUP = "KEYUP"


class MenuOptions:
    class OptionTypes:
        FLOW = "FLOW"
        REDIRECTION = "REDIRECTION"

        @classmethod
        def all(cls):
            return {cls.FLOW, cls.REDIRECTION}


class Captures:
    class CaptureTypes:
        HTML = "HTML"
        IMAGE = "IMAGE"


class Users:
    class Types:
        ADMIN = "ADMIN"
        MEMBER = "MEMBER"


class Accounts:
    class Plans:
        BASIC = "BASIC"
        STARTUP = "STARTUP"
        ENTERPRISE = "ENTERPRISE"
        CUSTOM = "CUSTOM"


class Playgrounds:
    class Events:
        CLICK = "CLICK"
        TEXTINPUT = "TEXTINPUT"
        HOVER = "HOVER"
        NEGATIVE_INTERACTION = "NEGATIVE_INTERACTION"


class Speakers:
    class SpeakerTypes:
        POLLY = "POLLY"
        ELEVENLABS = "ELEVENLABS"
        CUSTOM = "CUSTOM"

        @staticmethod
        def all():
            return {Speakers.SpeakerTypes.POLLY, Speakers.SpeakerTypes.ELEVENLABS, Speakers.SpeakerTypes.CUSTOM}


class Audios:
    class AudioTypes:
        WAV = "WAV"
        MP3 = "MP3"

        @staticmethod
        def all():
            return {Audios.AudioTypes.WAV, Audios.AudioTypes.MP3}


class PersonalisedDemos:
    class Statuses:
        PENDING = "PENDING"
        COMPLETE = "COMPLETE"
        FAILED = "FAILED"


class Messages:
    class IncompatibleScreen:
        class Defaults:
            title = "The demo is not supported for mobile screens."
            body = "Please switch to a larger device to view this demo."
