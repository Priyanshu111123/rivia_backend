from src.components import singleton, constants
from pymongo import MongoClient


class Database(metaclass=singleton.Singleton):
    client = None
    accounts = None
    users = None
    demos = None
    steps = None
    captures = None
    interactions = None
    visitors = None
    sessions = None
    statics = None
    browser_extension = None
    forms = None
    form_fields = None
    published_demos = None
    published_captures = None
    published_steps = None
    published_interactions = None
    published_menus = None
    published_menu_options = None
    submissions = None
    menus = None
    menu_options = None
    flows = None
    published_flows = None
    connections = None
    published_connections = None
    speakers = None
    voiceovers = None
    published_voiceovers = None
    personalised_demos = None
    links = None
    redirects = None
    published_redirects = None
    themes = None

    @classmethod
    def initialize(cls, connection_uri, database_name):
        cls.client = MongoFuncs.get_database(connection_uri, database_name)
        cls.accounts = MongoFuncs.get_table(cls.client, constants.Data.Structured.ACCOUNTS)
        cls.users = MongoFuncs.get_table(cls.client, constants.Data.Structured.USERS)
        cls.demos = MongoFuncs.get_table(cls.client, constants.Data.Structured.DEMOS)
        cls.steps = MongoFuncs.get_table(cls.client, constants.Data.Structured.STEPS)
        cls.captures = MongoFuncs.get_table(cls.client, constants.Data.Structured.CAPTURES)
        cls.interactions = MongoFuncs.get_table(cls.client, constants.Data.Structured.INTERACTIONS)
        cls.visitors = MongoFuncs.get_table(cls.client, constants.Data.Structured.VISITORS)
        cls.sessions = MongoFuncs.get_table(cls.client, constants.Data.Structured.SESSIONS)
        cls.browser_extension = MongoFuncs.get_table(cls.client, constants.Data.Structured.BROWSER_EXTENSION)
        cls.forms = MongoFuncs.get_table(cls.client, constants.Data.Structured.FORMS)
        cls.form_fields = MongoFuncs.get_table(cls.client, constants.Data.Structured.FORM_FIELDS)
        cls.published_demos = MongoFuncs.get_table(cls.client, constants.Data.Structured.PUBLISHED_DEMOS)
        cls.published_captures = MongoFuncs.get_table(cls.client, constants.Data.Structured.PUBLISHED_CAPTURES)
        cls.published_steps = MongoFuncs.get_table(cls.client, constants.Data.Structured.PUBLISHED_STEPS)
        cls.published_interactions = MongoFuncs.get_table(cls.client, constants.Data.Structured.PUBLISHED_INTERACTIONS)
        cls.published_menus = MongoFuncs.get_table(cls.client, constants.Data.Structured.PUBLISHED_MENUS)
        cls.published_menu_options = MongoFuncs.get_table(cls.client, constants.Data.Structured.PUBLISHED_MENU_OPTIONS)
        cls.submissions = MongoFuncs.get_table(cls.client, constants.Data.Structured.SUBMISSIONS)
        cls.menus = MongoFuncs.get_table(cls.client, constants.Data.Structured.MENUS)
        cls.menu_options = MongoFuncs.get_table(cls.client, constants.Data.Structured.MENU_OPTIONS)
        cls.flows = MongoFuncs.get_table(cls.client, constants.Data.Structured.FLOWS)
        cls.published_flows = MongoFuncs.get_table(cls.client, constants.Data.Structured.PUBLISHED_FLOWS)
        cls.connections = MongoFuncs.get_table(cls.client, constants.Data.Structured.CONNECTIONS)
        cls.published_connections = MongoFuncs.get_table(cls.client, constants.Data.Structured.PUBLISHED_CONNECTIONS)
        cls.speakers = MongoFuncs.get_table(cls.client, constants.Data.Structured.SPEAKERS)
        cls.voiceovers = MongoFuncs.get_table(cls.client, constants.Data.Structured.VOICEOVERS)
        cls.published_voiceovers = MongoFuncs.get_table(cls.client, constants.Data.Structured.PUBLISHED_VOICEOVERS)
        cls.personalised_demos = MongoFuncs.get_table(cls.client, constants.Data.Structured.PERSONALISED_DEMOS)
        cls.links = MongoFuncs.get_table(cls.client, constants.Data.Structured.LINKS)
        cls.redirects = MongoFuncs.get_table(cls.client, constants.Data.Structured.REDIRECTS)
        cls.published_redirects = MongoFuncs.get_table(cls.client, constants.Data.Structured.PUBLISHED_REDIRECTS)
        cls.themes = MongoFuncs.get_table(cls.client, constants.Data.Structured.THEMES)

    @classmethod
    def find_single(cls, table, query, projection):
        return MongoFuncs.find_single(table, query, projection)

    @classmethod
    def find_bulk(cls, table, query, projection):
        return MongoFuncs.find_bulk(table, query, projection)

    @classmethod
    def count(cls, table, query):
        return MongoFuncs.count(table, query)

    @classmethod
    def update_single(cls, table, query, update):
        return MongoFuncs.update_single(table, query, update)

    @classmethod
    def update_bulk(cls, table, query, update):
        return MongoFuncs.update_bulk(table, query, update)

    @classmethod
    def add_single(cls, table, document):
        if not document:
            return
        return MongoFuncs.add_single(table, document)

    @classmethod
    def update_or_add_single(cls, table, query, document):
        return MongoFuncs.update_or_add_single(table, query, document)

    @classmethod
    def add_bulk(cls, table, documents):
        if len(documents) == 0:
            return
        return MongoFuncs.add_bulk(table, documents)

    @classmethod
    def delete_single(cls, table, query):
        return MongoFuncs.delete_single(table, query)

    @classmethod
    def delete_many(cls, table, query):
        return MongoFuncs.delete_many(table, query)

    @classmethod
    def aggregate(cls, table, query):
        return MongoFuncs.aggregate(table, query)


class MongoFuncs:

    @staticmethod
    def get_database(connection_uri, database_name):
        return MongoClient(connection_uri)[database_name]

    @staticmethod
    def get_table(client, table_name):
        return client[table_name]

    @staticmethod
    def find_single(table, query, projection):
        return table.find_one(query, projection)

    @staticmethod
    def find_bulk(table, query, projection):
        return table.find(query, projection)

    @staticmethod
    def update_single(table, query, update):
        return table.update_one(query, update)

    @staticmethod
    def update_bulk(table, query, update):
        return table.update_many(query, update)

    @staticmethod
    def add_single(table, document):
        return table.insert_one(document)

    @staticmethod
    def update_or_add_single(table, query, document):
        return table.update_one(query, {"$set": document}, upsert=True)

    @staticmethod
    def add_bulk(table, documents):
        return table.insert_many(documents)

    @staticmethod
    def count(table, query):
        return table.count_documents(query)

    @staticmethod
    def delete_single(table, query):
        return table.delete_one(query)

    @staticmethod
    def delete_many(table, query):
        return table.delete_many(query)

    @staticmethod
    def aggregate(table, query):
        return table.aggregate(query)
