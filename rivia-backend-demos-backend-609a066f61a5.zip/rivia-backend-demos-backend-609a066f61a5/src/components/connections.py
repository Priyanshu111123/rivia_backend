from src.funcs import general
from src.components import structured_data


class Connections(object):

    def __init__(self, account_id, user_id, demo_id, src_capture_id, dst_capture_id, src_rivia_id, event_type,
                 text_input, negative_interaction, image_target_area, new_tab, redirect_url, src_rivia_xpath_id=None):
        self.account_id = account_id
        self.user_id = user_id
        self.connection_id = general.Identifiers.generate_connection_id()
        self.demo_id = demo_id
        self.created_at = general.Time.get_current_time()
        self.updated_at = general.Time.get_current_time()
        self.src_capture_id = src_capture_id
        self.dst_capture_id = dst_capture_id
        self.src_rivia_id = src_rivia_id
        self.event_type = event_type
        self.text_input = text_input
        self.negative_interaction = negative_interaction
        self.image_target_area = image_target_area
        self.new_tab = new_tab
        self.redirect_url = redirect_url
        self.src_rivia_xpath_id = src_rivia_xpath_id

    def as_json(self):
        return {
            "connection_id": self.connection_id,
            "account_id": self.account_id,
            "user_id": self.user_id,
            "demo_id": self.demo_id,
            "created_at": self.created_at,
            "updated_at": self.updated_at,
            "src_capture_id": self.src_capture_id,
            "dst_capture_id": self.dst_capture_id,
            "src_rivia_id": self.src_rivia_id,
            "event_type": self.event_type,
            "text_input": self.text_input,
            "negative_interaction": self.negative_interaction,
            "image_target_area": self.image_target_area,
            "new_tab": self.new_tab,
            "redirect_url": self.redirect_url,
            "src_rivia_xpath_id": self.src_rivia_xpath_id
        }


class FactoryFuncs:

    @staticmethod
    def create(account_id, user_id, demo_id, src_capture_id, dst_capture_id, src_rivia_id, event_type, text_input,
               negative_interaction, image_target_area, new_tab, redirect_url, src_rivia_xpath_id=None):
        connection = Connections(account_id=account_id, user_id=user_id, demo_id=demo_id, src_capture_id=src_capture_id,
                                 dst_capture_id=dst_capture_id, src_rivia_id=src_rivia_id, event_type=event_type,
                                 text_input=text_input, negative_interaction=negative_interaction,
                                 image_target_area=image_target_area, new_tab=new_tab, redirect_url=redirect_url,
                                 src_rivia_xpath_id=src_rivia_xpath_id)
        structured_data.Database.add_single(structured_data.Database.connections,
                                            connection.as_json())
        return connection
