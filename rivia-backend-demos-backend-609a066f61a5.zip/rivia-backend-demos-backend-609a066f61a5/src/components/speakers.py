from src.funcs import general
from src.components import structured_data


class Speakers(object):

    def __init__(self, account_id, external_speaker_id, speaker_type, speaker_name):
        self.account_id = account_id
        self.speaker_id = general.Identifiers.generate_speaker_id()
        self.external_speaker_id = external_speaker_id
        self.speaker_type = speaker_type
        self.speaker_name = speaker_name
        self.created_at = general.Time.get_current_time()
        self.updated_at = general.Time.get_current_time()

    def as_json(self):
        return {
            "account_id": self.account_id,
            "speaker_id": self.speaker_id,
            "external_speaker_id": self.external_speaker_id,
            "speaker_type": self.speaker_type,
            "speaker_name": self.speaker_name,
            "created_at": self.created_at,
            "updated_at": self.updated_at
        }


class FactoryFuncs:

    @staticmethod
    def create(account_id, external_speaker_id, speaker_type, speaker_name):
        speaker = Speakers(account_id=account_id, external_speaker_id=external_speaker_id, speaker_type=speaker_type,
                           speaker_name=speaker_name)
        structured_data.Database.add_single(structured_data.Database.speakers, speaker.as_json())
        return speaker
