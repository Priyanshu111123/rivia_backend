import requests
import json
from src.funcs import general
from src.components import configs


class SlackAlert:

    @staticmethod
    def demo_view(email, location, session_id, title):
        requests.post(
            configs.Slack.ACTIVITY_CHANNEL,
            data=json.dumps({
                "text": f"*{email}* - {title} - {location} - "
                        f"{general.Time.get_current_time()} GMT -> <{Utils.get_session_url(session_id)}|status>"}
            ))

    @staticmethod
    def demo_created(account_id, user_id, demo_id):
        requests.post(
            configs.Slack.DEMO_CREATION,
            data=json.dumps({
                "text": f"*{general.Components.Accounts.get_details_by_account_id(account_id).get('name')} - "
                        f"{general.Components.Users.get_details_by_user_id(user_id).get('email')}* - {demo_id} - "
                        f"DEMO CREATED"}
            ))

    @staticmethod
    def demo_published(account_id, user_id, demo_id, publish_type):
        requests.post(
            configs.Slack.DEMO_CREATION,
            data=json.dumps({
                "text": f"*{general.Components.Accounts.get_details_by_account_id(account_id).get('name')} - "
                        f"{general.Components.Users.get_details_by_user_id(user_id).get('email')}* - {demo_id} - "
                        f"DEMO PUBLISHED - {publish_type} "
                        f"{general.Time.get_current_time()} GMT -> <{Utils.get_public_url(account_id, demo_id)}|link>"}
            ))


class Utils:
    @staticmethod
    def get_session_url(session_id):
        return f"{configs.Environment.API_URL}/sessions/{session_id}"

    @staticmethod
    def get_public_url(account_id, demo_id):
        return f"https://tours.rivia.ai/{account_id}/{demo_id}"
