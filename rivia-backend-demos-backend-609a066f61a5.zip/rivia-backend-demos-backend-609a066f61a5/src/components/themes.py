from src.funcs import general
from src.components import structured_data


class Theme(object):

    def __init__(self, account_id, user_id, name, edit_state):
        self.theme_id = general.Identifiers.get_theme_id()
        self.name = name if name else "Untitled Theme"
        self.account_id = account_id
        self.user_id = user_id
        self.created_at = general.Time.get_current_time()
        self.updated_at = general.Time.get_current_time()
        self.edit_state = edit_state

    def as_json(self):
        return {
            "theme_id": self.theme_id,
            "name": self.name,
            "account_id": self.account_id,
            "user_id": self.user_id,
            "created_at": self.created_at,
            "updated_at": self.updated_at,
            "edit_state": self.edit_state
        }


class FactoryFuncs:

    @staticmethod
    def create(account_id, user_id, name, edit_state):
        theme = Theme(account_id=account_id, user_id=user_id, name=name, edit_state=edit_state)
        structured_data.Database.add_single(structured_data.Database.themes,
                                            theme.as_json())
        return theme
