from src.funcs import general
from src.components import structured_data, constants


class Account(object):

    def __init__(self, name, plan):
        self.account_id = general.Identifiers.generate_account_id()
        self.name = name
        self.plan = plan
        self.created_at = general.Time.get_current_time()

    def as_json(self):
        return {
            "account_id": self.account_id,
            "name": self.name,
            "plan": self.plan,
            "created_at": self.created_at
        }


class FactoryFuncs:

    @staticmethod
    def create_account(name, plan=constants.Accounts.Plans.STARTUP):
        account = Account(name, plan=plan)
        assert structured_data.Database.find_single(structured_data.Database.accounts, {"name": name}, {
            "_id": 0}) is None, "account already exists. Please ask the admin user for an invitation."
        structured_data.Database.add_single(structured_data.Database.accounts,
                                            account.as_json())
        return account.account_id
