import logging
import logging.config
import yaml
import inspect
from src.components import singleton, constants
from functools import wraps
import traceback


class Funcs:

    @staticmethod
    def create_error_log(error_log, account_id=None, user_id=None, component_id=None):
        Logger.log(constants.Logging.ERROR, account=account_id, user=user_id, component=component_id,
                   message=f"{str(error_log)}\n{traceback.format_exc()}")

    @staticmethod
    def log_func_call(message):
        def create(f):
            @wraps(f)
            def wrapper(*args, **kwargs):
                Logger.log(constants.Logging.INFO, account=kwargs.get("account_id"), user=kwargs.get("user_id"),
                           component=kwargs.get("component_id"), message=message)
                return f(*args, **kwargs)

            return wrapper

        return create


class Logger(metaclass=singleton.Singleton):
    logger = None
    appropriate_logging_method = None

    @classmethod
    def initialize(cls, path_to_config: str):
        cls.initialize_logger(path_to_config)
        cls.initialize_logger_method_lookup()

    @classmethod
    def initialize_logger(cls, path_to_config: str):
        with open(path_to_config, 'r') as f:
            config = yaml.safe_load(f.read())
            logging.config.dictConfig(config)
        cls.logger = logging.getLogger(__name__)

    @classmethod
    def initialize_logger_method_lookup(cls):
        cls.appropriate_logging_method = {
            constants.Logging.DEBUG: cls.logger.debug,
            constants.Logging.INFO: cls.logger.info,
            constants.Logging.WARNING: cls.logger.warning,
            constants.Logging.ERROR: cls.logger.error,
            constants.Logging.CRITICAL: cls.logger.critical
        }

    @staticmethod
    def populate_message_for_general(message, account=None, user=None, component=None):
        function_stack = inspect.stack()[2]
        return f"component={function_stack[1]} function={function_stack[3]} account={account} user={user} component={component} message={message}"

    @classmethod
    def log(cls, level, message, account=None, user=None, component=None):
        assert level in constants.Logging.all() and cls.logger, "Either logger is null or an invalid logging level"
        message = cls.populate_message_for_general(message, account, user, component)
        cls.appropriate_logging_method[level](message)
