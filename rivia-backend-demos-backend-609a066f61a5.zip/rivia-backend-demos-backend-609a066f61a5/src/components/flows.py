from src.funcs import general
from src.components import structured_data


class Flows(object):

    def __init__(self, account_id, user_id, demo_id, title, is_default, position):
        self.account_id = account_id
        self.user_id = user_id
        self.flow_id = general.Identifiers.generate_flow_id()
        self.demo_id = demo_id
        self.created_at = general.Time.get_current_time()
        self.updated_at = general.Time.get_current_time()
        self.title = title
        self.is_default = is_default
        self.position = position

    def as_json(self):
        return {
            "flow_id": self.flow_id,
            "account_id": self.account_id,
            "user_id": self.user_id,
            "demo_id": self.demo_id,
            "created_at": self.created_at,
            "updated_at": self.updated_at,
            "title": self.title,
            "is_default": self.is_default,
            "position": self.position
        }


class FactoryFuncs:

    @staticmethod
    def create(account_id, user_id, demo_id, title, position, is_default=False):
        flow = Flows(account_id=account_id, user_id=user_id, demo_id=demo_id, title=title, position=position,
                     is_default=is_default)
        structured_data.Database.add_single(structured_data.Database.flows,
                                            flow.as_json())
        return flow
