from src.components import singleton, configs
import requests
from functools import partial


class TTSClient(metaclass=singleton.Singleton):
    client = None

    @classmethod
    def initialize(cls, api_key):
        cls.client = ElevenLabsFuncs.get_client(api_key)

    @classmethod
    def convert(cls, speaker_id, text):
        assert text, "text value is invalid"
        return ElevenLabsFuncs.convert(cls.client, speaker_id, text)


class ElevenLabsFuncs:

    @staticmethod
    def get_client(api_key):
        return partial(ElevenLabsFuncs.__create_https_client, api_key=api_key)

    @staticmethod
    def __create_https_client(text, speaker_id, api_key):
        return requests.post(f"{configs.ElevenLabs.URL}/{speaker_id}",
                             json={"model_id": configs.ElevenLabs.MODEL_ID, "text": text},
                             headers={"xi-api-key": api_key})

    @staticmethod
    def convert(client, speaker_id, text):
        return client(text=text, speaker_id=speaker_id)
