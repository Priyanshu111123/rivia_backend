import boto3
from src.components import singleton


class Manager(metaclass=singleton.Singleton):
    client = None

    @classmethod
    def initialize(cls, region_name, access_key, secret_key):
        cls.client = AwsFuncs.get_client(region_name=region_name, access_key=access_key, secret_key=secret_key)

    @classmethod
    def retrieve(cls, secret_id):
        return AwsFuncs.get_secret(cls.client, secret_id)


class AwsFuncs:

    @staticmethod
    def get_client(region_name, access_key, secret_key):
        return boto3.client("secretsmanager",
                            region_name=region_name,
                            aws_access_key_id=access_key,
                            aws_secret_access_key=secret_key)

    @staticmethod
    def get_secret(client, secret_id):
        return client.get_secret_value(SecretId=secret_id)
