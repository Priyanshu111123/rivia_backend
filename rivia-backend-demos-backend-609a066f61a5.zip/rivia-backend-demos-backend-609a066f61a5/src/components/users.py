from src.funcs import general
from src.components import structured_data, constants


class User(object):

    def __init__(self, email, user_id, account_id, first_name, last_name, user_type, last_logged_in_at):
        self.user_id = user_id
        self.account_id = account_id
        self.email = email
        self.first_name = first_name
        self.last_name = last_name
        self.user_type = user_type
        self.created_at = general.Time.get_current_time()
        self.last_logged_in_at = last_logged_in_at

    def as_json(self):
        return {
            "user_id": self.user_id,
            "account_id": self.account_id,
            "email": self.email,
            "first_name": self.first_name,
            "last_name": self.last_name,
            "user_type": self.user_type,
            "created_at": self.created_at,
            "last_logged_in_at": self.last_logged_in_at
        }


class FactoryFuncs:

    @staticmethod
    def create_user(email, user_id, account_id, first_name, last_name, user_type=constants.Users.Types.ADMIN,
                    last_logged_in_at=None):
        user = User(email=email, user_id=user_id, account_id=account_id, first_name=first_name, last_name=last_name,
                    user_type=user_type, last_logged_in_at=last_logged_in_at)
        structured_data.Database.add_single(structured_data.Database.users,
                                            user.as_json())
        return user.user_id
