from src.components import singleton
from src.funcs import general
from ipdata import ipdata


class Locator(metaclass=singleton.Singleton):
    client = None

    @classmethod
    def initialize(cls, api_key):
        cls.client = IpDataFuncs.get_client(api_key)

    @classmethod
    @general.ExternalFuncsHandler.timeout(seconds=5, error_message="ip location function timed out")
    def get_location(cls, ip_address):
        return IpDataFuncs.get_location(cls.client, ip_address)


class IpDataFuncs:

    @staticmethod
    def get_client(api_key):
        return ipdata.IPData(api_key)

    @staticmethod
    def get_location(client, ip_address):
        try:
            return IpDataFuncs.__process_location_response(client.lookup(ip_address), ip_address)
        except:
            return ip_address

    @staticmethod
    def __process_location_response(response, ip_address):
        return f"{IpDataFuncs.__get_city(response)}, {IpDataFuncs.__get_region(response)}, " \
               f"{IpDataFuncs.__get_country(response)} ({ip_address})"

    @staticmethod
    def __get_city(response):
        if isinstance(response, dict) and response.get("city"):
            return response.get("city")
        return ""

    @staticmethod
    def __get_region(response):
        if isinstance(response, dict) and response.get("region"):
            return response.get("region")
        return ""

    @staticmethod
    def __get_country(response):
        if isinstance(response, dict) and response.get("country_name"):
            return response.get("country_name")
        return ""
