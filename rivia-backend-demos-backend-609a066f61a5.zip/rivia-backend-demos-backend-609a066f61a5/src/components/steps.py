from src.funcs import general
from src.components import structured_data


class Step(object):

    def __init__(self, account_id, user_id, demo_id, flow_id, position=None, capture_id=None):
        self.step_id = general.Identifiers.generate_step_id()
        self.account_id = account_id
        self.user_id = user_id
        self.demo_id = demo_id
        self.flow_id = flow_id
        self.__set_position(position)
        self.capture_id = capture_id
        self.created_at = general.Time.get_current_time()
        self.updated_at = general.Time.get_current_time()

    def __set_position(self, position):
        self.position = (
            lambda value: value if value is not None else structured_data.Database.count(structured_data.Database.steps,
                                                                                         {"demo_id": self.demo_id}))(
            position)

    def as_json(self):
        return {
            "step_id": self.step_id,
            "account_id": self.account_id,
            "user_id": self.account_id,
            "demo_id": self.demo_id,
            "flow_id": self.flow_id,
            "position": self.position,
            "capture_id": self.capture_id,
            "created_at": self.created_at,
            "updated_at": self.updated_at
        }


class FactoryFuncs:

    @staticmethod
    def create(account_id, user_id, demo_id, flow_id, position=None, capture_id=None):
        step = Step(account_id=account_id, user_id=user_id, demo_id=demo_id, flow_id=flow_id, position=position,
                    capture_id=capture_id)
        structured_data.Database.add_single(structured_data.Database.steps,
                                            step.as_json())
        return step
