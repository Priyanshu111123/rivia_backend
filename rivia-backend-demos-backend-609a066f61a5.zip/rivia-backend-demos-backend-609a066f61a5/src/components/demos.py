from src.funcs import general
from src.components import structured_data, constants


class Demo(object):

    def __init__(self, account_id, user_id, title, demo_type, has_htmls, has_images):
        self.demo_id = general.Identifiers.generate_demo_id()
        self.account_id = account_id
        self.user_id = user_id
        self.created_at = general.Time.get_current_time()
        self.updated_at = general.Time.get_current_time()
        self.title = (lambda value: value if value else "Untitled Demo")(title)
        self.num_views = 0
        self.demo_type = demo_type
        self.has_htmls = has_htmls
        self.has_images = has_images
        self.theme_id = "default"
        self.edit_state = {}
        self.incompatible_screen_message = {
            "title": constants.Messages.IncompatibleScreen.Defaults.title,
            "body": constants.Messages.IncompatibleScreen.Defaults.body
        }

    def as_json(self):
        return {
            "demo_id": self.demo_id,
            "account_id": self.account_id,
            "user_id": self.user_id,
            "created_at": self.created_at,
            "updated_at": self.updated_at,
            "title": self.title,
            "num_views": self.num_views,
            "demo_type": self.demo_type,
            "has_htmls": self.has_htmls,
            "has_images": self.has_images,
            "theme_id": self.theme_id,
            "incompatible_screen_message": self.incompatible_screen_message,
            "edit_state": self.edit_state
        }


class FactoryFuncs:

    @staticmethod
    def create_demo(account_id, user_id, title, demo_type, has_htmls, has_images):
        demo = Demo(account_id=account_id, user_id=user_id, title=title, demo_type=demo_type,
                    has_htmls=has_htmls, has_images=has_images)
        structured_data.Database.add_single(structured_data.Database.demos,
                                            demo.as_json())
        return demo
