from src.funcs import general
from src.components import structured_data, constants


class Voiceovers(object):

    def __init__(self, account_id, user_id, demo_id, step_id, speaker_id, audio_type=constants.Audios.AudioTypes.MP3):
        self.account_id = account_id
        self.user_id = user_id
        self.voiceover_id = general.Identifiers.generate_voiceover_id()
        self.demo_id = demo_id
        self.step_id = step_id
        self.speaker_id = speaker_id
        self.path_audio = f"{account_id}/{demo_id}/{step_id}/{self.voiceover_id}.{audio_type.lower()}"
        self.created_at = general.Time.get_current_time()
        self.updated_at = general.Time.get_current_time()

    def as_json(self):
        return {
            "account_id": self.account_id,
            "user_id": self.user_id,
            "voiceover_id": self.voiceover_id,
            "demo_id": self.demo_id,
            "step_id": self.step_id,
            "path_audio": self.path_audio,
            "speaker_id": self.speaker_id,
            "created_at": self.created_at,
            "updated_at": self.updated_at
        }


class FactoryFuncs:

    @staticmethod
    def create(account_id, user_id, demo_id, step_id, speaker_id, audio_type):
        voiceover = Voiceovers(account_id=account_id, user_id=user_id, demo_id=demo_id, step_id=step_id,
                               speaker_id=speaker_id, audio_type=audio_type)
        structured_data.Database.add_single(structured_data.Database.voiceovers, voiceover.as_json())
        return voiceover
