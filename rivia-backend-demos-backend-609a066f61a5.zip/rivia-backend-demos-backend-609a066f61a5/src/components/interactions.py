from src.components import structured_data, constants
from src.funcs import general
import os


class Interaction(object):

    def __init__(self, account_id, user_id, demo_id, step_id):
        self.interaction_id = general.Identifiers.generate_interaction_id()
        self.account_id = account_id
        self.user_id = user_id
        self.demo_id = demo_id
        self.step_id = step_id
        self.created_at = general.Time.get_current_time()
        self.updated_at = general.Time.get_current_time()

    def as_json(self):
        return {
            "interaction_id": self.interaction_id,
            "account_id": self.account_id,
            "user_id": self.user_id,
            "demo_id": self.demo_id,
            "step_id": self.step_id,
            "created_at": self.created_at,
            "updated_at": self.updated_at
        }


class RecordingInteraction(Interaction):

    def __init__(self, account_id, user_id, demo_id, step_id):
        super().__init__(account_id, user_id, demo_id, step_id)
        self.edit_state = {}
        self.interaction_type = constants.Interactions.RECORDING
        self.path_video = os.path.join(self.account_id, self.demo_id, self.step_id, self.interaction_id, "video")
        self.path_events = os.path.join(self.account_id, self.demo_id, self.step_id, self.interaction_id, "events")

    def as_json(self):
        return {
            **super().as_json(),
            "edit_state": {},
            "interaction_type": self.interaction_type,
            "path_video": self.path_video,
            "path_events": self.path_events
        }


class ModalInteraction(Interaction):

    def __init__(self, account_id, user_id, demo_id, step_id, default_edit_state):
        super().__init__(account_id, user_id, demo_id, step_id)
        self.interaction_type = constants.Interactions.MODAL
        self.edit_state = default_edit_state

    def as_json(self):
        return {
            **super().as_json(),
            "interaction_type": self.interaction_type,
            "edit_state": self.edit_state
        }


class ImageModalInteraction(Interaction):

    def __init__(self, account_id, user_id, demo_id, step_id, default_edit_state, height_image=None, width_image=None):
        super().__init__(account_id, user_id, demo_id, step_id)
        self.path_image = os.path.join(self.account_id, self.demo_id, self.step_id, self.interaction_id,
                                       general.Identifiers.generate_image_id())
        self.height_image = height_image
        self.width_image = width_image
        self.interaction_type = constants.Interactions.IMAGE_MODAL
        self.edit_state = default_edit_state

    def as_json(self):
        return {
            **super().as_json(),
            "interaction_type": self.interaction_type,
            "edit_state": self.edit_state,
            "path_image": self.path_image,
            "height_image": self.height_image,
            "width_image": self.width_image
        }


class TooltipInteraction(Interaction):

    def __init__(self, account_id, user_id, demo_id, step_id, default_edit_state):
        super().__init__(account_id, user_id, demo_id, step_id)
        self.interaction_type = constants.Interactions.TOOLTIP
        self.edit_state = default_edit_state

    def as_json(self):
        return {
            **super().as_json(),
            "interaction_type": self.interaction_type,
            "edit_state": self.edit_state
        }


class FormInteraction(Interaction):

    def __init__(self, account_id, user_id, demo_id, step_id, default_edit_state):
        super().__init__(account_id, user_id, demo_id, step_id)
        self.interaction_type = constants.Interactions.FORM
        self.edit_state = default_edit_state

    def as_json(self):
        return {
            **super().as_json(),
            "interaction_type": self.interaction_type,
            "edit_state": self.edit_state
        }


class IframeInteraction(Interaction):

    def __init__(self, account_id, user_id, demo_id, step_id, default_edit_state):
        super().__init__(account_id, user_id, demo_id, step_id)
        self.interaction_type = constants.Interactions.IFRAME
        self.edit_state = default_edit_state

    def as_json(self):
        return {
            **super().as_json(),
            "interaction_type": self.interaction_type,
            "edit_state": self.edit_state
        }


class FactoryFuncs:

    @staticmethod
    def create(account_id, user_id, demo_id, step_id, default_edit_state, interaction_type,
               height_image=None, width_image=None):
        if interaction_type == constants.Interactions.MODAL:
            interaction = ModalInteraction(account_id=account_id, user_id=user_id, demo_id=demo_id,
                                           step_id=step_id, default_edit_state=default_edit_state)
        elif interaction_type == constants.Interactions.TOOLTIP:
            interaction = TooltipInteraction(account_id=account_id, user_id=user_id, demo_id=demo_id,
                                             step_id=step_id, default_edit_state=default_edit_state)
        elif interaction_type == constants.Interactions.FORM:
            interaction = FormInteraction(account_id=account_id, user_id=user_id, demo_id=demo_id,
                                          step_id=step_id, default_edit_state=default_edit_state)
        elif interaction_type == constants.Interactions.IFRAME:
            interaction = IframeInteraction(account_id=account_id, user_id=user_id, demo_id=demo_id,
                                            step_id=step_id, default_edit_state=default_edit_state)
        elif interaction_type == constants.Interactions.IMAGE_MODAL:
            interaction = ImageModalInteraction(account_id=account_id, user_id=user_id, demo_id=demo_id,
                                                step_id=step_id, default_edit_state=default_edit_state,
                                                height_image=height_image, width_image=width_image)
        else:
            interaction = RecordingInteraction(account_id=account_id, user_id=user_id, demo_id=demo_id,
                                               step_id=step_id)
        structured_data.Database.add_single(structured_data.Database.interactions,
                                            interaction.as_json())
        return interaction
