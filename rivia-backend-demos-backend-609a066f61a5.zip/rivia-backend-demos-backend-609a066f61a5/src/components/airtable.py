from pyairtable import Table
from src.components import singleton
from functools import partial


class Airtable(metaclass=singleton.Singleton):
    connection = None

    @classmethod
    def initialize(cls, api_key):
        cls.connection = partial(Airtable.__get_table_function, api_key=api_key)

    @staticmethod
    def __get_table_function(api_key, base_id, table_id):
        return Table(api_key=api_key, base_id=base_id, table_name=table_id)

    @classmethod
    def create_record(cls, base_id, table_id, payload):
        return cls.connection(base_id=base_id, table_id=table_id).create(payload)
