from src.funcs import general
from src.components import structured_data, configs
import os


class Capture(object):

    def __init__(self, account_id, user_id, demo_id, capture_type, title, src_capture, path_image, path_thumbnail,
                 position, screen_interaction=None, capture_hash=None):
        self.capture_id = general.Identifiers.generate_capture_id()
        self.account_id = account_id
        self.user_id = user_id
        self.demo_id = demo_id
        self.capture_type = capture_type
        self.title = title
        self.src_capture = src_capture
        self.created_at = general.Time.get_current_time()
        self.updated_at = general.Time.get_current_time()
        self.path_html = os.path.join(self.account_id, self.demo_id, self.capture_id, "html")
        self.path_image = os.path.join(self.account_id, self.demo_id, self.capture_id,
                                       "image") if not path_image else path_image
        self.path_thumbnail = path_thumbnail
        self.position = position
        self.screen_interaction = screen_interaction
        self.capture_hash = capture_hash

    def as_json(self):
        return {
            "capture_id": self.capture_id,
            "account_id": self.account_id,
            "user_id": self.user_id,
            "demo_id": self.demo_id,
            "capture_type": self.capture_type,
            "src_capture": self.src_capture,
            "title": self.title,
            "created_at": self.created_at,
            "updated_at": self.updated_at,
            "path_html": self.path_html,
            "path_image": self.path_image,
            "path_thumbnail": self.path_thumbnail,
            "position": self.position,
            "screen_interaction": self.screen_interaction,
            "capture_hash": self.capture_hash
        }


class StaticCaptures(object):

    def __init__(self, account_id, demo_id):
        self.capture_id = general.Identifiers.generate_static_capture_id()
        self.public_url = f"{configs.AWS.CLOUDFRONT_STATIC_CONTENT}/{account_id}/{demo_id}/{self.capture_id}"
        self.path_storage = os.path.join(account_id, demo_id, self.capture_id)

    def as_json(self):
        return {
            "capture_id": self.capture_id,
            "public_url": self.public_url,
            "path_storage": self.path_storage
        }


class FactoryFuncs:

    @staticmethod
    def create(account_id, user_id, demo_id, capture_type, position, title=None, src_capture=None, path_image=None,
               path_thumbnail=None, screen_interaction=None, capture_hash=None):
        capture = Capture(account_id=account_id, user_id=user_id, demo_id=demo_id, capture_type=capture_type,
                          title=title, src_capture=src_capture, path_image=path_image, path_thumbnail=path_thumbnail,
                          position=position,
                          screen_interaction=screen_interaction, capture_hash=capture_hash)
        structured_data.Database.add_single(structured_data.Database.captures,
                                            capture.as_json())
        return capture

    @staticmethod
    def create_static_content(account_id, demo_id):
        capture = StaticCaptures(account_id=account_id, demo_id=demo_id)
        return capture
