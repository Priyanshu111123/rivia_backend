from src.components import structured_data


class Ops:

    @staticmethod
    def fetch(table, account_id, page_number, date_start=None, date_end=None, text_query=None, num_results=20,
              projection=None, extra_constraints=None, sort_by="updated_at"):
        if projection is None:
            projection = {"_id": 0}
        return list(structured_data.Database.find_bulk(
            table,
            Constraints.add_extras(
                Constraints.add_text(Constraints.add_created_at_date({"account_id": account_id}, date_start, date_end),
                                     text_query=text_query), constraints=extra_constraints),
            projection
        ).sort([(sort_by, -1)]).skip(page_number * num_results).limit(num_results))

    @staticmethod
    def count(table, account_id, date_start=None, date_end=None, text_query=None, extra_constraints=None):
        return structured_data.Database.count(
            table,
            Constraints.add_extras(
                Constraints.add_text(Constraints.add_created_at_date({"account_id": account_id}, date_start, date_end),
                                     text_query=text_query), constraints=extra_constraints)
        )


class Constraints:

    @staticmethod
    def add_created_at_date(query, date_start, date_end):
        if date_start and date_end:
            return {
                **query, "created_at": {"$gte": date_start, "$lte": date_end}
            }
        else:
            return query

    @staticmethod
    def add_text(query, text_query):
        if text_query:
            return {
                **query, "$text": {"$search": text_query}
            }
        else:
            return query

    @staticmethod
    def add_extras(query, constraints):
        if constraints:
            return {
                **query, **constraints
            }
        else:
            return query
