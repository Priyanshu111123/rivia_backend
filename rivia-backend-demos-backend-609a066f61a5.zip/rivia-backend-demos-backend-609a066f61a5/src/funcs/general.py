from src.components import structured_data, constants, configs, logging
from flask import make_response, request
import shortuuid
import datetime
from functools import lru_cache, wraps
import hmac
import hashlib
import signal
import errno
import os
import re

EXPIRES_IN = datetime.timedelta(days=14)
EXPIRES_IN_LONG_TERM = datetime.timedelta(days=3650)


class Components:
    class Users:

        @staticmethod
        def get_details_by_email(email):
            return structured_data.Database.find_single(structured_data.Database.users,
                                                        {"email": email}, {"_id": 0})

        @staticmethod
        @lru_cache(maxsize=50)
        def get_details_by_user_id(user_id):
            return structured_data.Database.find_single(structured_data.Database.users,
                                                        {"user_id": user_id}, {"_id": 0})

        @staticmethod
        def generate_signature(user_id):
            return hmac.new(configs.Fogbender.SECRET_KEY.encode("utf-8"), user_id.encode("utf-8"),
                            hashlib.sha256).hexdigest()

    class Accounts:
        @staticmethod
        @lru_cache(maxsize=50)
        def get_details_by_account_id(account_id):
            return structured_data.Database.find_single(structured_data.Database.accounts,
                                                        {"account_id": account_id}, {"_id": 0})


class Identifiers:

    @staticmethod
    def generate(length=10):
        return shortuuid.ShortUUID().random(length=length)

    @staticmethod
    def generate_account_id():
        return f"acc{Identifiers.generate()}"

    @staticmethod
    def generate_demo_id():
        return f"dem{Identifiers.generate()}"

    @staticmethod
    def generate_step_id():
        return f"stp{Identifiers.generate()}"

    @staticmethod
    def generate_capture_id():
        return f"cap{Identifiers.generate()}"

    @staticmethod
    def generate_static_capture_id():
        return f"sta{Identifiers.generate(length=20)}"

    @staticmethod
    def generate_interaction_id():
        return f"int{Identifiers.generate()}"

    @staticmethod
    def generate_visitor_id():
        return f"vis{Identifiers.generate()}"

    @staticmethod
    def generate_session_id():
        return f"ses{Identifiers.generate(length=20)}"

    @staticmethod
    def generate_visitor_tracking_cookie_string():
        return Identifiers.generate(length=50)

    @staticmethod
    def generate_form_id():
        return f"frm{Identifiers.generate()}"

    @staticmethod
    def generate_form_field_id():
        return f"fld{Identifiers.generate()}"

    @staticmethod
    def generate_submission_id():
        return f"sub{Identifiers.generate()}"

    @staticmethod
    def generate_menu_id():
        return f"men{Identifiers.generate()}"

    @staticmethod
    def generate_menu_option_id():
        return f"opt{Identifiers.generate()}"

    @staticmethod
    def generate_flow_id():
        return f"flo{Identifiers.generate()}"

    @staticmethod
    def generate_connection_id():
        return f"con{Identifiers.generate()}"

    @staticmethod
    def generate_speaker_id():
        return f"spe{Identifiers.generate()}"

    @staticmethod
    def generate_voiceover_id():
        return f"voi{Identifiers.generate()}"

    @staticmethod
    def generate_personalised_demo_id():
        return f"pdm{Identifiers.generate()}"

    @staticmethod
    def generate_link_id():
        return f"lnk{Identifiers.generate(length=20)}"

    @staticmethod
    def generate_redirect_id():
        return f"red{Identifiers.generate()}"

    @staticmethod
    def get_theme_id():
        return f"thm{Identifiers.generate()}"

    @staticmethod
    def generate_image_id():
        return f"img{Identifiers.generate()}"


class Time:

    @staticmethod
    def get_current_time(milliseconds=False):
        current_time = datetime.datetime.utcnow()
        if milliseconds:
            return current_time.isoformat().split('+')[0]
        else:
            return current_time.isoformat().split('+')[0].split('.')[0]

    @staticmethod
    def get_current_date():
        current_time = Time.get_current_time()
        return current_time.split("T")[0]

    @staticmethod
    def get_then_time(milliseconds=False, hours=0, minutes=0, seconds=0):
        then_time = datetime.datetime.utcnow() + datetime.timedelta(hours=hours, minutes=minutes, seconds=seconds)
        if milliseconds:
            return then_time.isoformat().split('+')[0]
        else:
            return then_time.isoformat().split('+')[0].split('.')[0]

    # a decorator function to calculate the time taken by a function to execute
    @staticmethod
    def time_taken(func):
        def wrapper(*args, **kwargs):
            start_time = datetime.datetime.now()
            result = func(*args, **kwargs)
            end_time = datetime.datetime.now()
            print(f"Time taken by {func.__name__} to execute: {end_time - start_time}")
            return result

        return wrapper


class APIResponse:
    class Error:
        @staticmethod
        def get_response(message, status_code):
            return APIResponse.Headers.add_cors_headers(
                make_response({constants.APIResponse.Fields.STATUS: constants.APIResponse.Statuses.FAILURE,
                               constants.APIResponse.Fields.MESSAGE: str(message)}, status_code))

    class Headers:
        @staticmethod
        def add_cors_headers(response):
            if request.referrer:
                response.headers['Access-Control-Allow-Origin'] = APIResponse.Headers.process_referrer(request.referrer)
            response.headers["Access-Control-Allow-Credentials"] = "true"
            response.headers["Access-Control-Allow-Headers"] = "content-type,x-rivia-internal-passcode"
            response.headers["Access-Control-Allow-Methods"] = "OPTIONS, GET, POST, DELETE, PUT"
            return response

        @staticmethod
        def process_referrer(referrer):
            return referrer[:-1] if referrer.endswith("/") else referrer

    class Cookies:
        @staticmethod
        def add_cookie_to_response(session_cookie, response, cookie_name, long_term=False):
            response.set_cookie(
                cookie_name, session_cookie,
                expires=datetime.datetime.now() + (lambda term: EXPIRES_IN if not long_term else EXPIRES_IN_LONG_TERM)(
                    long_term), httponly=True,
                secure=(lambda env: True if env == constants.Environment.PRODUCTION else False)(
                    configs.Environment.TYPE)
            )
            return response

        @staticmethod
        def expire_session_cookie(response, cookie_name):
            response.set_cookie(
                cookie_name, expires=0
            )
            return response


class TimeoutError(Exception):
    pass


class ExternalFuncsHandler:

    @staticmethod
    def timeout(seconds=5, error_message=os.strerror(errno.ETIME)):
        def decorator(func):
            def _handle_timeout(signum, frame):
                raise TimeoutError(error_message)

            @wraps(func)
            def wrapper(*args, **kwargs):
                signal.signal(signal.SIGALRM, _handle_timeout)
                signal.alarm(seconds)
                try:
                    result = func(*args, **kwargs)
                finally:
                    signal.alarm(0)
                return result

            return wrapper

        return decorator


class TextProcessor:
    @staticmethod
    def remove_html_tags(text):
        """
        Remove html tags from a string
        """
        clean = re.compile('<.*?>')
        return re.sub(clean, '', text)
