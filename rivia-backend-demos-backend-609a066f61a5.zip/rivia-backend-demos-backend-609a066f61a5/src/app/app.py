import os
import sys
import flask
import json

ROOT_DIR = '/'.join(os.path.dirname(os.path.abspath(__file__)).split('/')[:-2])
sys.path.append(ROOT_DIR)

from src.components import logging, authentication, structured_data, constants, configs, secrets, unstructured_data
from src.components import lambdas, iplocator, airtable, cdn, tts

logger = logging.Logger()
logger.initialize(os.path.join(ROOT_DIR, "configurations", "logging.yml"))

logger.log(constants.Logging.INFO, message="initiating secrets manager client")
secrets.Manager.initialize(region_name=configs.AWS.REGION_NAME, access_key=configs.AWS.ACCESS_KEY,
                           secret_key=configs.AWS.SECRET_KEY)

logger.log(constants.Logging.INFO, message="initiating authentication client")
authentication.Authenticator.initialize(api_key=configs.Firebase.API_KEY,
                                        credentials_payload=json.loads(
                                            secrets.Manager.retrieve(configs.Firebase.CERTIFICATE_KEY)["SecretString"]))

logger.log(constants.Logging.INFO, message="initiating structured database client")
structured_data.Database.initialize(connection_uri=configs.Mongo.URI, database_name=configs.Mongo.DATABASE_NAME)

logger.log(constants.Logging.INFO, message="initiating unstructured database client")
unstructured_data.Database.initialize(region_name=configs.AWS.REGION_NAME, access_key=configs.AWS.ACCESS_KEY,
                                      secret_key=configs.AWS.SECRET_KEY)

logger.log(constants.Logging.INFO, message="initiating cdn client")
cdn.CDN.initialize(region_name=configs.AWS.REGION_NAME, access_key=configs.AWS.ACCESS_KEY,
                   secret_key=configs.AWS.SECRET_KEY)

logger.log(constants.Logging.INFO, message="initiating lambda executors client")
lambdas.LambdaExecutor.initialize(region_name=configs.AWS.REGION_NAME, access_key=configs.AWS.ACCESS_KEY,
                                  secret_key=configs.AWS.SECRET_KEY)

logger.log(constants.Logging.INFO, message="initiating tts client")
tts.TTSClient.initialize(api_key=configs.ElevenLabs.API_KEY)

logger.log(constants.Logging.INFO, message="initiating ip locator client")
iplocator.Locator.initialize(api_key=configs.IPData.API_KEY)

logger.log(constants.Logging.INFO, message="initiating airtable client")
airtable.Airtable.initialize(api_key=configs.Airtable.API_KEY)

from src.api_resources import users, demos, captures, steps, interactions, browser_extension, sessions
from src.api_resources import forms, publish, submissions, menus, flows, connections, speakers, voiceovers, personalise
from src.api_resources import links, logos, redirects, themes
from src.components import authentication

app = flask.Flask(__name__)


@app.route("/sign_validate", methods=["GET", "OPTIONS"])
@authentication.Authenticator.add_cors_headers
@authentication.Authenticator.authenticate_api_request
def validate_sign(user_id=None, account_id=None):
    return flask.make_response("valid", 200)


@app.route("/sign_in", methods=["POST", "OPTIONS"])
@authentication.Authenticator.add_cors_headers
def sign_in():
    return users.Ops.sign_in()


@app.route("/sign_out", methods=["POST", "OPTIONS"])
@authentication.Authenticator.add_cors_headers
@authentication.Authenticator.authenticate_api_request
def sign_out(user_id=None, account_id=None):
    return users.Ops.sign_out(user_id=user_id, account_id=account_id)


@app.route("/oauth_sign_in", methods=["POST", "OPTIONS"])
@authentication.Authenticator.add_cors_headers
def oauth_sign_in():
    return users.Ops.oauth_sign_in()


@app.route("/sign_assist", methods=["POST", "OPTIONS"])
@authentication.Authenticator.add_cors_headers
def sign_assist():
    return users.Ops.sign_assist()


@app.route("/sign_up", methods=["POST", "OPTIONS"])
@authentication.Authenticator.add_cors_headers
def sign_up():
    return users.Ops.sign_up()


@app.route("/users/invite", methods=["POST", "OPTIONS"])
@authentication.Authenticator.add_cors_headers
@authentication.Authenticator.authenticate_api_request
def invite_user(account_id=None, user_id=None):
    return users.Ops.invite_user(account_id=account_id, user_id=user_id)


@app.route("/users/<rivia_user_id>", methods=["DELETE", "OPTIONS"])
@authentication.Authenticator.add_cors_headers
@authentication.Authenticator.authenticate_api_request
def delete_user(rivia_user_id, account_id=None, user_id=None):
    return users.Ops.delete(account_id=account_id, user_id=user_id, rivia_user_id=rivia_user_id)


@app.route("/users/<rivia_user_id>", methods=["GET", "OPTIONS"])
@authentication.Authenticator.add_cors_headers
@authentication.Authenticator.authenticate_api_request
def fetch_user(rivia_user_id, account_id=None, user_id=None):
    return users.Ops.fetch(account_id=account_id, user_id=user_id, rivia_user_id=rivia_user_id)


@app.route("/users", methods=["GET", "OPTIONS"])
@authentication.Authenticator.add_cors_headers
@authentication.Authenticator.authenticate_api_request
def fetch_users(account_id=None, user_id=None):
    return users.Ops.fetch_all(account_id=account_id, user_id=user_id)


@app.route("/accounts/<rivia_account_id>", methods=["GET", "OPTIONS"])
@authentication.Authenticator.add_cors_headers
@authentication.Authenticator.authenticate_api_request
def fetch_account(rivia_account_id, account_id=None, user_id=None):
    return users.Ops.fetch_account(account_id=account_id, user_id=user_id, rivia_account_id=rivia_account_id)


@app.route("/demos", methods=["GET", "OPTIONS"])
@authentication.Authenticator.add_cors_headers
@authentication.Authenticator.authenticate_api_request
def fetch_demos(account_id=None, user_id=None):
    return demos.Ops.fetch(account_id=account_id, user_id=user_id)


@app.route("/demos", methods=["POST", "OPTIONS"])
@authentication.Authenticator.add_cors_headers
@authentication.Authenticator.authenticate_api_request
def create_demo(account_id=None, user_id=None):
    return demos.Ops.create(account_id=account_id, user_id=user_id)


@app.route("/demos/<demo_id>/duplicate", methods=["POST", "OPTIONS"])
@authentication.Authenticator.add_cors_headers
@authentication.Authenticator.authenticate_api_request
def duplicate_demo(demo_id, account_id=None, user_id=None):
    return demos.Ops.duplicate(account_id=account_id, user_id=user_id, demo_id=demo_id)


@app.route("/demos/<demo_id>", methods=["PUT", "OPTIONS"])
@authentication.Authenticator.add_cors_headers
@authentication.Authenticator.authenticate_api_request
def update_demo(demo_id, account_id=None, user_id=None):
    return demos.Ops.update(account_id=account_id, user_id=user_id, demo_id=demo_id)


@app.route("/demos/<demo_id>", methods=["GET", "OPTIONS"])
@authentication.Authenticator.add_cors_headers
@authentication.Authenticator.authenticate_api_request
def fetch_single_demo(demo_id, account_id=None, user_id=None):
    return demos.Ops.fetch_single(account_id=account_id, user_id=user_id, demo_id=demo_id)


@app.route("/demos/<demo_id>", methods=["DELETE", "OPTIONS"])
@authentication.Authenticator.add_cors_headers
@authentication.Authenticator.authenticate_api_request
def delete_demo(demo_id, account_id=None, user_id=None):
    return demos.Ops.delete(account_id=account_id, user_id=user_id, demo_id=demo_id)


# @app.route("/public/demos/<account_id>/<demo_id>", methods=["GET", "OPTIONS"])
# @authentication.Authenticator.add_cors_headers
# @authentication.Authenticator.check_visitor
# def fetch_single_demo_public_view(account_id, demo_id):
#     return demos.Ops.fetch_single_public(account_id=account_id, demo_id=demo_id)


@app.route("/public/forms/<account_id>/<form_id>", methods=["GET", "OPTIONS"])
@authentication.Authenticator.add_cors_headers
def fetch_single_form_public_view(account_id, form_id):
    return forms.Ops.get_single_form(account_id=account_id, user_id="public", form_id=form_id)


@app.route("/session_logs", methods=["POST", "OPTIONS"])
@authentication.Authenticator.add_cors_headers
def create_session_log():
    return sessions.Ops.create_log()


@app.route("/sessions/<session_id>", methods=["GET", "OPTIONS"])
@authentication.Authenticator.add_cors_headers
@authentication.Authenticator.authenticate_api_request
def fetch_single_session(session_id, account_id=None, user_id=None):
    return sessions.Ops.fetch_single(account_id=account_id, user_id=user_id, session_id=session_id)


@app.route("/captures", methods=["GET", "OPTIONS"])
@authentication.Authenticator.add_cors_headers
@authentication.Authenticator.authenticate_api_request
def fetch_all_captures(account_id=None, user_id=None):
    return captures.Ops.fetch_all(account_id=account_id, user_id=user_id)


@app.route("/captures", methods=["POST", "OPTIONS"])
@authentication.Authenticator.add_cors_headers
@authentication.Authenticator.authenticate_api_request
def create_capture(account_id=None, user_id=None):
    return captures.Ops.create(account_id=account_id, user_id=user_id)


@app.route("/captures/<capture_id>", methods=["PUT", "OPTIONS"])
@authentication.Authenticator.add_cors_headers
@authentication.Authenticator.authenticate_api_request
def update_capture(capture_id, account_id=None, user_id=None):
    return captures.Ops.update_capture(account_id=account_id, user_id=user_id, capture_id=capture_id)


@app.route("/captures/<capture_id>", methods=["DELETE", "OPTIONS"])
@authentication.Authenticator.add_cors_headers
@authentication.Authenticator.authenticate_api_request
def delete_capture(capture_id, account_id=None, user_id=None):
    return captures.Ops.delete_capture(account_id=account_id, user_id=user_id, capture_id=capture_id)


@app.route("/static_captures", methods=["POST", "OPTIONS"])
@authentication.Authenticator.add_cors_headers
@authentication.Authenticator.authenticate_api_request
def create_static_capture(account_id=None, user_id=None):
    return captures.Ops.create_static_capture(account_id=account_id, user_id=user_id)


@app.route("/captures/<capture_id>/duplicate", methods=["POST", "OPTIONS"])
@authentication.Authenticator.add_cors_headers
@authentication.Authenticator.authenticate_api_request
def duplicate_capture(capture_id, account_id=None, user_id=None):
    return captures.Ops.duplicate(account_id=account_id, user_id=user_id, capture_id=capture_id)


@app.route("/captures/<capture_id>/refresh", methods=["POST", "OPTIONS"])
@authentication.Authenticator.add_cors_headers
@authentication.Authenticator.authenticate_api_request
def refresh_capture(capture_id, account_id=None, user_id=None):
    return captures.Ops.refresh(account_id=account_id, user_id=user_id, capture_id=capture_id)


@app.route("/steps", methods=["POST", "OPTIONS"])
@authentication.Authenticator.add_cors_headers
@authentication.Authenticator.authenticate_api_request
def create_step(account_id=None, user_id=None):
    return steps.Ops.create(account_id=account_id, user_id=user_id)


@app.route("/steps/<step_id>", methods=["DELETE", "OPTIONS"])
@authentication.Authenticator.add_cors_headers
@authentication.Authenticator.authenticate_api_request
def delete_step(step_id, account_id=None, user_id=None):
    return steps.Ops.delete(account_id=account_id, user_id=user_id, step_id=step_id)


@app.route("/steps/<step_id>", methods=["PUT", "OPTIONS"])
@authentication.Authenticator.add_cors_headers
@authentication.Authenticator.authenticate_api_request
def update_step(step_id, account_id=None, user_id=None):
    return steps.Ops.update(account_id=account_id, user_id=user_id, step_id=step_id)


@app.route("/steps/<step_id>", methods=["GET", "OPTIONS"])
@authentication.Authenticator.add_cors_headers
@authentication.Authenticator.authenticate_api_request
def fetch_single_step(step_id, account_id=None, user_id=None):
    return steps.Ops.fetch_single(account_id=account_id, user_id=user_id, step_id=step_id)


@app.route("/interactions", methods=["POST", "OPTIONS"])
@authentication.Authenticator.add_cors_headers
@authentication.Authenticator.authenticate_api_request
def create_interaction(account_id=None, user_id=None):
    return interactions.Ops.create(account_id=account_id, user_id=user_id)


@app.route("/interactions/<interaction_id>", methods=["PUT", "OPTIONS"])
@authentication.Authenticator.add_cors_headers
@authentication.Authenticator.authenticate_api_request
def update_interaction(interaction_id, account_id=None, user_id=None):
    return interactions.Ops.update(account_id=account_id, user_id=user_id, interaction_id=interaction_id)


@app.route("/interactions/<interaction_id>", methods=["DELETE", "OPTIONS"])
@authentication.Authenticator.add_cors_headers
@authentication.Authenticator.authenticate_api_request
def delete_interaction(interaction_id, account_id=None, user_id=None):
    return interactions.Ops.delete(account_id=account_id, user_id=user_id, interaction_id=interaction_id)


@app.route("/browser_extension_config", methods=["GET", "OPTIONS"])
@authentication.Authenticator.add_cors_headers
@authentication.Authenticator.authenticate_api_request
def fetch_browser_extension_config(account_id=None, user_id=None):
    return browser_extension.Ops.fetch(account_id=account_id, user_id=user_id)


@app.route("/forms", methods=["POST", "OPTIONS"])
@authentication.Authenticator.add_cors_headers
@authentication.Authenticator.authenticate_api_request
def create_form(account_id=None, user_id=None):
    return forms.Ops.create_form(account_id=account_id, user_id=user_id)


@app.route("/forms/<form_id>", methods=["GET", "OPTIONS"])
@authentication.Authenticator.add_cors_headers
@authentication.Authenticator.authenticate_api_request
def fetch_single_form(form_id, account_id=None, user_id=None):
    return forms.Ops.get_single_form(account_id=account_id, user_id=user_id, form_id=form_id)


@app.route("/forms", methods=["GET", "OPTIONS"])
@authentication.Authenticator.add_cors_headers
@authentication.Authenticator.authenticate_api_request
def fetch_bulk_form(account_id=None, user_id=None):
    return forms.Ops.get_bulk_forms(account_id=account_id, user_id=user_id)


@app.route("/forms/<form_id>", methods=["DELETE", "OPTIONS"])
@authentication.Authenticator.add_cors_headers
@authentication.Authenticator.authenticate_api_request
def delete_form(form_id, account_id=None, user_id=None):
    return forms.Ops.delete_form(account_id=account_id, user_id=user_id, form_id=form_id)


@app.route("/forms/<form_id>", methods=["PUT", "OPTIONS"])
@authentication.Authenticator.add_cors_headers
@authentication.Authenticator.authenticate_api_request
def update_form(form_id, account_id=None, user_id=None):
    return forms.Ops.update_form(account_id=account_id, user_id=user_id, form_id=form_id)


@app.route("/formfields", methods=["POST", "OPTIONS"])
@authentication.Authenticator.add_cors_headers
@authentication.Authenticator.authenticate_api_request
def create_form_field(account_id=None, user_id=None):
    return forms.Ops.create_form_field(account_id=account_id, user_id=user_id)


@app.route("/formfields/<form_field_id>", methods=["GET", "OPTIONS"])
@authentication.Authenticator.add_cors_headers
@authentication.Authenticator.authenticate_api_request
def retrieve_single_form_field(form_field_id, account_id=None, user_id=None):
    return forms.Ops.get_single_form_field(account_id=account_id, user_id=user_id, form_field_id=form_field_id)


@app.route("/formfields", methods=["GET", "OPTIONS"])
@authentication.Authenticator.add_cors_headers
@authentication.Authenticator.authenticate_api_request
def retrieve_bulk_form_field(account_id=None, user_id=None):
    return forms.Ops.get_bulk_form_fields(account_id=account_id, user_id=user_id)


@app.route("/formfields/<form_field_id>", methods=["DELETE", "OPTIONS"])
@authentication.Authenticator.add_cors_headers
@authentication.Authenticator.authenticate_api_request
def delete_form_field(form_field_id, account_id=None, user_id=None):
    return forms.Ops.delete_form_field(account_id=account_id, user_id=user_id, form_field_id=form_field_id)


@app.route("/formfields/<form_field_id>", methods=["PUT", "OPTIONS"])
@authentication.Authenticator.add_cors_headers
@authentication.Authenticator.authenticate_api_request
def update_form_field(form_field_id, account_id=None, user_id=None):
    return forms.Ops.update_form_field(account_id=account_id, user_id=user_id, form_field_id=form_field_id)


@app.route("/publish", methods=["POST", "OPTIONS"])
@authentication.Authenticator.add_cors_headers
@authentication.Authenticator.authenticate_api_request
def publish_demo(account_id=None, user_id=None):
    return publish.Ops.create(account_id=account_id, user_id=user_id)


@app.route("/publish", methods=["GET", "OPTIONS"])
@authentication.Authenticator.add_cors_headers
@authentication.Authenticator.authenticate_api_request
def fetch_published_demos(account_id=None, user_id=None):
    return publish.Ops.fetch(account_id=account_id, user_id=user_id)


# @app.route("/publish/<account_id>/<demo_id>", methods=["GET", "OPTIONS"])
# @authentication.Authenticator.add_cors_headers
# @authentication.Authenticator.check_visitor
# def fetch_single_published_demo(account_id, demo_id):
#     return demos.Ops.fetch_published_single(account_id=account_id, demo_id=demo_id)


@app.route("/publish/opt/<account_id>/<demo_id>", methods=["GET", "OPTIONS"])
@authentication.Authenticator.add_cors_headers
@authentication.Authenticator.check_visitor
def fetch_single_published_demo_opt(account_id, demo_id):
    return demos.Ops.fetch_published_single_opt(account_id=account_id, demo_id=demo_id)


@app.route("/publish/opt/<link_id>", methods=["GET", "OPTIONS"])
@authentication.Authenticator.add_cors_headers
@authentication.Authenticator.check_visitor
def fetch_single_published_link_opt(link_id):
    return demos.Ops.fetch_published_using_public_link(link_id=link_id)


@app.route("/submissions", methods=["POST", "OPTIONS"])
@authentication.Authenticator.add_cors_headers
def create_submission():
    return submissions.Ops.create()


@app.route("/submissions", methods=["GET", "OPTIONS"])
@authentication.Authenticator.add_cors_headers
@authentication.Authenticator.authenticate_api_request
def fetch_submissions_bulk(account_id=None, user_id=None):
    return submissions.Ops.fetch(account_id=account_id, user_id=user_id)


@app.route("/menus", methods=["POST", "OPTIONS"])
@authentication.Authenticator.add_cors_headers
@authentication.Authenticator.authenticate_api_request
def create_menu(account_id=None, user_id=None):
    return menus.MenuOps.create(account_id=account_id, user_id=user_id)


@app.route("/menus/<menu_id>", methods=["PUT", "OPTIONS"])
@authentication.Authenticator.add_cors_headers
@authentication.Authenticator.authenticate_api_request
def update_menu(menu_id, account_id=None, user_id=None):
    return menus.MenuOps.update(account_id=account_id, user_id=user_id, menu_id=menu_id)


@app.route("/menus/<menu_id>", methods=["GET", "OPTIONS"])
@authentication.Authenticator.add_cors_headers
@authentication.Authenticator.authenticate_api_request
def fetch_menu(menu_id, account_id=None, user_id=None):
    return menus.MenuOps.fetch(account_id=account_id, user_id=user_id, menu_id=menu_id)


@app.route("/menu_options", methods=["POST", "OPTIONS"])
@authentication.Authenticator.add_cors_headers
@authentication.Authenticator.authenticate_api_request
def create_menu_options(account_id=None, user_id=None):
    return menus.MenuOptionOps.create(account_id=account_id, user_id=user_id)


@app.route("/menu_options", methods=["GET", "OPTIONS"])
@authentication.Authenticator.add_cors_headers
@authentication.Authenticator.authenticate_api_request
def fetch_menu_options_in_bulk(account_id=None, user_id=None):
    return menus.MenuOptionOps.fetch_in_bulk(account_id=account_id, user_id=user_id)


@app.route("/menu_options/<menu_option_id>", methods=["GET", "OPTIONS"])
@authentication.Authenticator.add_cors_headers
@authentication.Authenticator.authenticate_api_request
def fetch_menu_option(menu_option_id, account_id=None, user_id=None):
    return menus.MenuOptionOps.fetch(account_id=account_id, user_id=user_id, menu_option_id=menu_option_id)


@app.route("/menu_options/<menu_option_id>", methods=["PUT", "OPTIONS"])
@authentication.Authenticator.add_cors_headers
@authentication.Authenticator.authenticate_api_request
def update_menu_option(menu_option_id, account_id=None, user_id=None):
    return menus.MenuOptionOps.update(account_id=account_id, user_id=user_id, menu_option_id=menu_option_id)


@app.route("/menu_options/<menu_option_id>", methods=["DELETE", "OPTIONS"])
@authentication.Authenticator.add_cors_headers
@authentication.Authenticator.authenticate_api_request
def delete_menu_option(menu_option_id, account_id=None, user_id=None):
    return menus.MenuOptionOps.delete(account_id=account_id, user_id=user_id, menu_option_id=menu_option_id)


@app.route("/flows", methods=["POST", "OPTIONS"])
@authentication.Authenticator.add_cors_headers
@authentication.Authenticator.authenticate_api_request
def create_flow(account_id=None, user_id=None):
    return flows.Ops.create(account_id=account_id, user_id=user_id)


@app.route("/flows/<flow_id>", methods=["PUT", "OPTIONS"])
@authentication.Authenticator.add_cors_headers
@authentication.Authenticator.authenticate_api_request
def update_flow(flow_id, account_id=None, user_id=None):
    return flows.Ops.update(account_id=account_id, user_id=user_id, flow_id=flow_id)


@app.route("/flows/<flow_id>", methods=["DELETE", "OPTIONS"])
@authentication.Authenticator.add_cors_headers
@authentication.Authenticator.authenticate_api_request
def delete_flow(flow_id, account_id=None, user_id=None):
    return flows.Ops.delete(account_id=account_id, user_id=user_id, flow_id=flow_id)


@app.route("/sessions", methods=["GET", "OPTIONS"])
@authentication.Authenticator.add_cors_headers
@authentication.Authenticator.authenticate_api_request
def fetch_sessions(account_id=None, user_id=None):
    return sessions.Ops.fetch(account_id=account_id, user_id=user_id)


# connections
@app.route("/connections", methods=["POST", "OPTIONS"])
@authentication.Authenticator.add_cors_headers
@authentication.Authenticator.authenticate_api_request
def create_connection(account_id=None, user_id=None):
    return connections.Ops.create(account_id=account_id, user_id=user_id)


@app.route("/connections/<connection_id>", methods=["GET", "OPTIONS"])
@authentication.Authenticator.add_cors_headers
@authentication.Authenticator.authenticate_api_request
def fetch_connection(connection_id, account_id=None, user_id=None):
    return connections.Ops.fetch(account_id=account_id, user_id=user_id, connection_id=connection_id)


@app.route("/connections", methods=["GET", "OPTIONS"])
@authentication.Authenticator.add_cors_headers
@authentication.Authenticator.authenticate_api_request
def fetch_connections_bulk(account_id=None, user_id=None):
    return connections.Ops.fetch_all(account_id=account_id, user_id=user_id)


@app.route("/connections/<connection_id>", methods=["PUT", "OPTIONS"])
@authentication.Authenticator.add_cors_headers
@authentication.Authenticator.authenticate_api_request
def update_connection(connection_id, account_id=None, user_id=None):
    return connections.Ops.update(account_id=account_id, user_id=user_id, connection_id=connection_id)


@app.route("/connections/<connection_id>", methods=["DELETE", "OPTIONS"])
@authentication.Authenticator.add_cors_headers
@authentication.Authenticator.authenticate_api_request
def delete_connection(connection_id, account_id=None, user_id=None):
    return connections.Ops.delete(account_id=account_id, user_id=user_id, connection_id=connection_id)


# speakers
@app.route("/speakers", methods=["POST", "OPTIONS"])
@authentication.Authenticator.add_cors_headers
@authentication.Authenticator.authenticate_api_request
def create_speakers(account_id=None, user_id=None):
    return speakers.Ops.create(account_id=account_id, user_id=user_id)


@app.route("/speakers", methods=["GET", "OPTIONS"])
@authentication.Authenticator.add_cors_headers
@authentication.Authenticator.authenticate_api_request
def fetch_speakers(account_id=None, user_id=None):
    return speakers.Ops.fetch(account_id=account_id, user_id=user_id)


@app.route("/voiceovers", methods=["POST", "OPTIONS"])
@authentication.Authenticator.add_cors_headers
@authentication.Authenticator.authenticate_api_request
def create_voiceover(account_id=None, user_id=None):
    return voiceovers.Ops.create(account_id=account_id, user_id=user_id)


@app.route("/voiceovers/upload", methods=["POST", "OPTIONS"])
@authentication.Authenticator.add_cors_headers
@authentication.Authenticator.authenticate_api_request
def upload_voiceover(account_id=None, user_id=None):
    return voiceovers.Ops.create_uploaded(account_id=account_id, user_id=user_id)


@app.route("/voiceovers/<voiceover_id>", methods=["PUT", "OPTIONS"])
@authentication.Authenticator.add_cors_headers
@authentication.Authenticator.authenticate_api_request
def update_voiceover(voiceover_id, account_id=None, user_id=None):
    return voiceovers.Ops.update(account_id=account_id, user_id=user_id, voiceover_id=voiceover_id)


@app.route("/voiceovers", methods=["GET", "OPTIONS"])
@authentication.Authenticator.add_cors_headers
@authentication.Authenticator.authenticate_api_request
def fetch_voiceovers_for_step(account_id=None, user_id=None):
    return voiceovers.Ops.fetch_all(account_id=account_id, user_id=user_id)


@app.route("/personalised_demos", methods=["POST", "OPTIONS"])
@authentication.Authenticator.add_cors_headers
@authentication.Authenticator.authenticate_api_request
def create_personalised_demo(account_id=None, user_id=None):
    return personalise.Ops.create(account_id=account_id, user_id=user_id)


@app.route("/links", methods=["POST", "OPTIONS"])
@authentication.Authenticator.add_cors_headers
@authentication.Authenticator.authenticate_api_request
def create_link(account_id=None, user_id=None):
    return links.Ops.create(account_id=account_id, user_id=user_id)


@app.route("/links", methods=["GET", "OPTIONS"])
@authentication.Authenticator.add_cors_headers
@authentication.Authenticator.authenticate_api_request
def fetch_links(account_id=None, user_id=None):
    return links.Ops.get_all(account_id=account_id, user_id=user_id)


@app.route("/links/<link_id>", methods=["GET", "OPTIONS"])
@authentication.Authenticator.add_cors_headers
@authentication.Authenticator.authenticate_api_request
def fetch_link(link_id, account_id=None, user_id=None):
    return links.Ops.get(account_id=account_id, user_id=user_id, link_id=link_id)


@app.route("/links/<link_id>", methods=["DELETE", "OPTIONS"])
@authentication.Authenticator.add_cors_headers
@authentication.Authenticator.authenticate_api_request
def delete_link(link_id, account_id=None, user_id=None):
    return links.Ops.delete(account_id=account_id, user_id=user_id, link_id=link_id)


@app.route("/links/<link_id>", methods=["PUT", "OPTIONS"])
@authentication.Authenticator.add_cors_headers
@authentication.Authenticator.authenticate_api_request
def update_link(link_id, account_id=None, user_id=None):
    return links.Ops.update(account_id=account_id, user_id=user_id, link_id=link_id)


@app.route("/logos/<domain>", methods=["GET", "OPTIONS"])
@authentication.Authenticator.add_cors_headers
@authentication.Authenticator.authenticate_api_request
def fetch_logo(domain, account_id=None, user_id=None):
    return logos.Ops.fetch(account_id=account_id, user_id=user_id, domain=domain)


@app.route("/redirects", methods=["POST", "OPTIONS"])
@authentication.Authenticator.add_cors_headers
@authentication.Authenticator.authenticate_api_request
def create_redirect(account_id=None, user_id=None):
    return redirects.Ops.create(account_id=account_id, user_id=user_id)


@app.route("/redirects", methods=["GET", "OPTIONS"])
@authentication.Authenticator.add_cors_headers
@authentication.Authenticator.authenticate_api_request
def fetch_redirects(account_id=None, user_id=None):
    return redirects.Ops.get_all(account_id=account_id, user_id=user_id)


@app.route("/redirects/<redirect_id>", methods=["GET", "OPTIONS"])
@authentication.Authenticator.add_cors_headers
@authentication.Authenticator.authenticate_api_request
def fetch_redirect(redirect_id, account_id=None, user_id=None):
    return redirects.Ops.get(account_id=account_id, user_id=user_id, redirect_id=redirect_id)


@app.route("/redirects/<redirect_id>", methods=["PUT", "OPTIONS"])
@authentication.Authenticator.add_cors_headers
@authentication.Authenticator.authenticate_api_request
def update_redirect(redirect_id, account_id=None, user_id=None):
    return redirects.Ops.update(account_id=account_id, user_id=user_id, redirect_id=redirect_id)


@app.route("/redirects/<redirect_id>", methods=["DELETE", "OPTIONS"])
@authentication.Authenticator.add_cors_headers
@authentication.Authenticator.authenticate_api_request
def delete_redirect(redirect_id, account_id=None, user_id=None):
    return redirects.Ops.delete(account_id=account_id, user_id=user_id, redirect_id=redirect_id)


@app.route("/themes", methods=["POST", "OPTIONS"])
@authentication.Authenticator.add_cors_headers
@authentication.Authenticator.authenticate_api_request
def create_theme(account_id=None, user_id=None):
    return themes.Ops.create(account_id=account_id, user_id=user_id)


@app.route("/themes", methods=["GET", "OPTIONS"])
@authentication.Authenticator.add_cors_headers
@authentication.Authenticator.authenticate_api_request
def fetch_themes(account_id=None, user_id=None):
    return themes.Ops.fetch_all(account_id=account_id, user_id=user_id)


@app.route("/themes/<theme_id>", methods=["GET", "OPTIONS"])
@authentication.Authenticator.add_cors_headers
@authentication.Authenticator.authenticate_api_request
def fetch_theme(theme_id, account_id=None, user_id=None):
    return themes.Ops.fetch(account_id=account_id, user_id=user_id, theme_id=theme_id)


@app.route("/themes/<theme_id>", methods=["PUT", "OPTIONS"])
@authentication.Authenticator.add_cors_headers
@authentication.Authenticator.authenticate_api_request
def update_theme(theme_id, account_id=None, user_id=None):
    return themes.Ops.update(account_id=account_id, user_id=user_id, theme_id=theme_id)


@app.route("/themes/<theme_id>", methods=["DELETE", "OPTIONS"])
@authentication.Authenticator.add_cors_headers
@authentication.Authenticator.authenticate_api_request
def delete_theme(theme_id, account_id=None, user_id=None):
    return themes.Ops.delete(account_id=account_id, user_id=user_id, theme_id=theme_id)


@app.route("/health", methods=["GET", "OPTIONS"])
def check_health():
    return "OK", 200


if __name__ == "__main__":
    app.run()
